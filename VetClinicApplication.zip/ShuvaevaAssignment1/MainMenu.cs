﻿
/*
 * Description: Main Menu form. Allows to navigate between forms and create a report.
 * Author: Elena Shuvaeva
 * Date: 26.08.2014
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


namespace ShuvaevaAssignment1
{
    public partial class MainMenu : Form

    { 
        /// <summary>
        ///  the reference to the form that holds the data components
        /// </summary>
        private DataModule _dm;  
        /// <summary>
        /// the reference to the cat form
        /// </summary>
        private CatForm _frmCat;  
      
        /// <summary>
        /// the reference to the owner form
        /// </summary>
        private OwnerForm _frmOwner;

	 	/// <summary>
        /// the reference to the treatment form
	 	/// </summary>
        private TreatmentForm _frmTreatment; 
     	
	    /// <summary>
        /// the reference to the veterinarian form
	    /// </summary>
        private VeterinarianForm _frmVet; 
        
        /// <summary>
        /// the reference to the visit form
        /// </summary>
        private VisitForm _frmVisit; 
        
        /// <summary>
        /// the reference to the visit treatment form
        /// </summary>
        private VisitTreatmentForm _frmVisitTreatment;  
	

        /// <summary>
        /// visits in pending state for invoices report
        /// </summary>
        private DataRow[] _pendingVisits;

        /// <summary>
        /// Index of a visit that is currently displayed on a page in invoices report
        /// </summary>
        private int _currentVisitIndex = 0;

        /// <summary>
        /// Main Menu constructor
        /// </summary>

        public MainMenu()
        {
            InitializeComponent();
            
        }
        /// <summary>
        /// create the data module and load the dataset
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void MainForm_Load(object sender, EventArgs e)
        {
            _dm = new DataModule();
        }

        /// <summary>
        /// event handler for 'Owner maintenance' button 
        /// if it is clicked - 'Owner maintenance form'  shown
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnOwnMaintenance_Click(object sender, EventArgs e)
        {
            if (_frmOwner == null)
            {
                _frmOwner = new OwnerForm(_dm,this );
            }
            _frmOwner.ShowDialog();
        }

         /// <summary>
         /// event handler for 'Veterinarian maintenance' button 
         /// if it is clicked - 'Veterinarian maintenance form'  shown
         /// </summary>
         /// <param name="sender"></param>
         /// <param name="e"></param>

        private void btnVetMaintenance_Click(object sender, EventArgs e)
        {
            if (_frmVet == null)
            {
                _frmVet = new VeterinarianForm(_dm,this);
            }
            _frmVet.ShowDialog();
        }


        /// <summary>
        /// event handler for 'Cat maintenance' button 
        /// if it is clicked - 'Cat maintenance form'  shown
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCatMaintenance_Click(object sender, EventArgs e)
        {
           if (_frmCat == null)
            {
                _frmCat = new CatForm(_dm, this);
            }
            _frmCat.ShowDialog();
        }

        /// <summary>
        /// event handler for 'Treatment maintenance' button 
        /// if it is clicked - 'Treatment maintenance form'  shown
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnTreatMaintetance_Click(object sender, EventArgs e)
        {
            if (_frmTreatment == null)
            {
                _frmTreatment = new TreatmentForm(_dm,this);

            }
            _frmTreatment.ShowDialog();
        }

        /// <summary>
        /// event handler for 'Visit maintenance' button 
        /// if it is clicked - 'Visit maintenance form'  shown
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnVisitMaintenance_Click(object sender, EventArgs e)
        {
            if (_frmVisit == null)
            {
                _frmVisit = new VisitForm(_dm,this);
            }
            _frmVisit.ShowDialog();
        }

        /// <summary>
        /// event handler for 'Treatment to visit allocation' button 
        /// if it is clicked - 'VisitTreatment maintenance form'  shown
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnTreatVisitAllocation_Click(object sender, EventArgs e)
        {
            if (_frmVisitTreatment == null)
            {
                _frmVisitTreatment = new VisitTreatmentForm(_dm , this);
            }
            _frmVisitTreatment.ShowDialog();
        }

        /// <summary>
        /// event handler for 'Invoices' button 
        /// if it is clicked - 'Invoice form'  shown
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnInvoices_Click(object sender, EventArgs e)
        {
            // get pending visits
            _pendingVisits = _dm.datasetGlendene.VISIT.Select("Status = 'Pending'", "VisitID", DataViewRowState.CurrentRows);
            // if there are no visits to print show warning message
            if (_pendingVisits == null || _pendingVisits.Length == 0)
            {
                MessageBox.Show("No pending visits to print.");
                return;
            }
            _currentVisitIndex = 0;

            FrmPrintPreview frmPreview = new FrmPrintPreview();
            frmPreview.frmMain = this;
            frmPreview.prPreview.Zoom = 1.0;
            frmPreview.prPreview.Document = pdInvoices;
            frmPreview.ShowDialog();
        }

 
        /// <summary>
        /// Print document event. Prints invoices report.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PrintDoc(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            DataRow pendingVisitRow = _pendingVisits[_currentVisitIndex];

            Graphics g = e.Graphics;

            //set the font and boundaries
            int linesSoFar = 1;

            Font titleFont = new Font("Arial", 14, FontStyle.Bold);
            Font headerFont = new Font("Arial", 12, FontStyle.Bold);
            Font printFont = new Font("Arial", 12);
            Font treatmentHeaderFont = new Font("Arial", 12, FontStyle.Bold);


            int lineHeight = printFont.Height;
            int leftMargin = e.MarginBounds.Left;
            int rightMargin = e.MarginBounds.Right;

            Image catLogo = global::ShuvaevaAssignment1.Properties.Resources.cat1;

            g.DrawImage(catLogo, new Point(rightMargin - catLogo.Size.Width/2,1));

            //print the heading and rule off
            g.DrawString("Invoice", titleFont, Brushes.Black, leftMargin, linesSoFar * lineHeight);
            linesSoFar++;
            int ruleOffTop = (linesSoFar * lineHeight) + (int)(lineHeight * 0.25);
            Brush br = new SolidBrush(Color.Black);
            Pen pn = new Pen(br, 2);

            linesSoFar++;

            //print the body of the text
            int topMargin = e.MarginBounds.Top;


            //1. Print invoice number that is visit id
            //2. Print invoice body with all information about the visit - veterinarian, owner, cat and their details
            //3. Print visit details - treatments for this visit
            //4. Check if there is another visit, i.e. check if the next page is to be printed

            double visitTotal = 0;
            CurrencyManager cmOwner = this.BindingContext[_dm.datasetGlendene, "OWNER"] as CurrencyManager;
            CurrencyManager cmVeterinarian = this.BindingContext[_dm.datasetGlendene, "VETERINARIAN"] as CurrencyManager;
            CurrencyManager cmTreatment = this.BindingContext[_dm.datasetGlendene, "TREATMENT"] as CurrencyManager;

            // get the owner record matching the owner ID from the cat record
            int ownerID = Convert.ToInt32(pendingVisitRow["OwnerID"].ToString());
            cmOwner.Position = _dm._ownerView.Find(ownerID);
            DataRow ownerRow = _dm._dtOwner.Rows[cmOwner.Position];

            // get the veterinarian record matching the veterinarian ID from the visit record
            int vetID = Convert.ToInt32(pendingVisitRow["VeterinarianID"].ToString());
            cmVeterinarian.Position = _dm._veterinarianView.Find(vetID);
            DataRow vetRow = _dm._dtVeterinarian.Rows[cmVeterinarian.Position];
            visitTotal = Convert.ToDouble(vetRow["Rate"]);


            g.DrawString("VisitID: " + pendingVisitRow["VisitID"] , headerFont, Brushes.Green, leftMargin, linesSoFar * lineHeight);
            g.DrawString(" Visit Date: " + pendingVisitRow["VisitDate"], headerFont, Brushes.Green, leftMargin+200, linesSoFar * lineHeight);
            linesSoFar++;
            g.DrawLine(pn, new Point(leftMargin, linesSoFar * lineHeight), new Point(rightMargin, linesSoFar * lineHeight));
            linesSoFar++;

            g.DrawString("Veterinarian Name: " + pendingVisitRow["VeterinarianDetails"], headerFont, Brushes.Gray, leftMargin, linesSoFar * lineHeight);
            g.DrawString ("Rate: $" + vetRow["Rate"], headerFont, Brushes.Gray, leftMargin+400, linesSoFar * lineHeight);
            linesSoFar++;
            linesSoFar++;
            g.DrawString("Owner ID: " + pendingVisitRow["OwnerID"], headerFont, Brushes.Gray, leftMargin, linesSoFar * lineHeight);
            linesSoFar++;
            g.DrawString("Owner Full Name: " + pendingVisitRow["OwnerDetails"], headerFont, Brushes.Gray, leftMargin, linesSoFar * lineHeight);
            linesSoFar++;
            g.DrawString("Owner Street Address: " + ownerRow["StreetAddress"] + " " + ownerRow["Suburb"], headerFont, Brushes.Gray, leftMargin, linesSoFar * lineHeight);
            linesSoFar++;
            linesSoFar++;
            g.DrawString("Cat Name: " + pendingVisitRow["Name"], headerFont, Brushes.Gray, leftMargin, linesSoFar * lineHeight);
            linesSoFar++;
            linesSoFar++;

            // get all visit treatment records for current visit
            DataRow[] treatmentsPerVisitRows = pendingVisitRow.GetChildRows(_dm.datasetGlendene.VISIT.ChildRelations["VISIT_VISITTREATMENT"]);
            g.DrawLine(Pens.Gray, new Point(leftMargin,linesSoFar*lineHeight),new Point( rightMargin,linesSoFar*lineHeight));
            int treatmentNumber = 0;

            int printWidth = rightMargin - leftMargin;

            int numberPoistion = Convert.ToInt32(printWidth*0.05);
            int descriptionPoistion = Convert.ToInt32(printWidth * 0.15);
            int quantityPosition = Convert.ToInt32(printWidth * 0.55);
            int costPosition = Convert.ToInt32(printWidth * 0.75);
            int totalPosition = Convert.ToInt32(printWidth * 0.65);

            g.DrawString("№", treatmentHeaderFont, Brushes.Gray, leftMargin + numberPoistion, linesSoFar * lineHeight);
            g.DrawString("Treatment", treatmentHeaderFont, Brushes.Gray, leftMargin + descriptionPoistion, linesSoFar * lineHeight);
            g.DrawString("Quantity", treatmentHeaderFont, Brushes.Gray, leftMargin + quantityPosition, linesSoFar * lineHeight);
            g.DrawString("Treatment Cost", treatmentHeaderFont, Brushes.Gray, leftMargin + costPosition, linesSoFar * lineHeight);
            
            g.DrawLine(Pens.Gray, new Point(leftMargin, (linesSoFar + 1) * lineHeight), new Point(rightMargin, (linesSoFar + 1) * lineHeight));
            linesSoFar++;

            foreach (DataRow visitTreatmentRow in treatmentsPerVisitRows)
            {
                treatmentNumber++;
                int treatmentID = Convert.ToInt32(visitTreatmentRow["TreatmentID"].ToString());
                cmTreatment.Position = _dm._treatmentView.Find(treatmentID);
                DataRow treatmentRow = _dm._dtTreatment.Rows[cmTreatment.Position];

                double treatmentCost = Convert.ToDouble(treatmentRow["Cost"]) * Convert.ToInt32(visitTreatmentRow["Quantity"]);
                visitTotal += treatmentCost;
                
                g.DrawString(treatmentNumber.ToString(), printFont, Brushes.Gray, leftMargin + numberPoistion, linesSoFar * lineHeight);
                g.DrawString(treatmentRow["Description"].ToString(), printFont, Brushes.Gray, leftMargin + descriptionPoistion, linesSoFar * lineHeight);
                g.DrawString(visitTreatmentRow["Quantity"].ToString(), printFont, Brushes.Gray, leftMargin + quantityPosition, linesSoFar * lineHeight);

                string treatmentCostStr = "$" + treatmentCost.ToString();
                g.DrawString(treatmentCostStr, printFont, Brushes.Gray, leftMargin + costPosition, linesSoFar * lineHeight);
                
                linesSoFar++;

            }
            linesSoFar++;
            g.DrawLine(pn,new Point(leftMargin,linesSoFar*lineHeight),new Point(rightMargin,linesSoFar*lineHeight));
            linesSoFar++;
            g.DrawString("Gross Due: " + "$" +  Convert.ToString(visitTotal), headerFont, br, leftMargin + totalPosition, linesSoFar * lineHeight);

            _currentVisitIndex++;
            //check if there is another visit to print
            if (_currentVisitIndex < _pendingVisits.Length)
            {
                e.HasMorePages = true;
            }
            else
            {
                e.HasMorePages = false;
            }


        }

        /// <summary>
        /// event handler for 'Exit' button 
        /// Click closes MainMenu form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }
    
    }
}
