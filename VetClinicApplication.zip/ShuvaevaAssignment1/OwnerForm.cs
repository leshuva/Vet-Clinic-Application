﻿/*
 * Description: Owner maintenance form. Allows to read, add, modify ,delete owners.
 * Author: Elena Shuvaeva
 * Date: 26.08.2014
 */


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ShuvaevaAssignment1
{
    public partial class OwnerForm : Form
    {
        /// <summary>
        /// Declare a shared data source 
        /// add reference to DataModul
        /// </summary>
        /// 
        private DataModule _dm;
        /// <summary>
        ///  add reference to MainMenu object
        /// </summary>
        private MainMenu _mmenu;
        /// <summary>
        /// add reference to CurrencyManager object
        /// </summary>
        private CurrencyManager _currencyManager;


        /// <summary>
        ///  Changing the constructor to accept Datamodul and MainMenu references
        /// </summary>
        /// <param name="dm"></param>
        /// <param name="mmenu"></param>
        
        public OwnerForm(DataModule dm, MainMenu mmenu)
        {
            // Create and set values for the controls
            InitializeComponent();

            //Store the location of the data modul
            _dm = dm;

            // Store the location of the menu form
            _mmenu = mmenu;

            //Run the code for binding the controls on the form
            BindControls();

            //Adding panel hidden
          
            pnlAddOwner.Visible = false;
            pnlAddOwner.Enabled = false;

        }
        
        /// <summary>
        /// Binds controls to the data source (bind the data to listbox and textboxes)
        /// </summary>

        public void BindControls()
        {
            //datasource for the listbox
            lstOwners.DataSource = _dm.datasetGlendene.OWNER;
            lstOwners.DisplayMember = "Details";
            lstOwners.ValueMember = "OwnerID";

            //binding data for label and textboxes
            lblOwnerId.DataBindings.Add("Text", _dm.datasetGlendene, "Owner.OwnerID");
            tbOwnerFirstName.DataBindings.Add("Text", _dm.datasetGlendene, "OWNER.FirstName");
            tbOwnerLastName.DataBindings.Add("Text", _dm.datasetGlendene, "OWNER.LastName");
            tbOwnerAddress.DataBindings.Add("Text",_dm.datasetGlendene,"OWNER.StreetAddress");
            tbOwnerPhoneNum.DataBindings.Add("Text",_dm.datasetGlendene,"OWNER.PhoneNumber");  
            tbOwnerSuburb.DataBindings.Add("Text",_dm.datasetGlendene,"OWNER.Suburb");
          
            //define current position in the datatable "Owner"
            _currencyManager = (CurrencyManager)this.BindingContext[_dm.datasetGlendene, "OWNER"];
            
            lstOwners.SelectedIndexChanged += new EventHandler(OwnersIndexChanged);


        }

         
        /// <summary>
        /// Event handler for  navigating between owners in the listbox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// 
        
        private void OwnersIndexChanged(object sender, EventArgs e)
        {

            if (lstOwners.SelectedIndex >= 0 && lstOwners.SelectedIndex < _currencyManager.Count)
            {
                _currencyManager.Position = lstOwners.SelectedIndex;
            }
        }
        
           
      
        /// <summary>
        /// Event Handler for 'Previous Owner' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            if (_currencyManager.Position > 0)
            {
                --_currencyManager.Position;
                lstOwners.SelectedIndex = _currencyManager.Position;
            }

        }


        /// <summary>
        /// Event Handler for 'Next Owner' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (_currencyManager.Position < _currencyManager.Count - 1)
            {
                ++_currencyManager.Position;
                lstOwners.SelectedIndex = _currencyManager.Position;
            }

        }


        /// <summary>
        /// Event handler to add new owner (buttons 'modify owner' and 'delete owner' are disabled
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAddOwner_Click(object sender, EventArgs e)
        {
            // Empty textboxes in the AddOwner panel

            tbOwnerAddFirstN.Text = "";
            tbOwnerAddLastN.Text = "";
            maskTbOwnerNumber.Text = "";
            tbOwnerAddSuburb.Text = "";
            tbOwnerAddAddress.Text = "";
            

            //Disable unneeded buttons

            btnDeleteOwner.Enabled = false;
            btnModifyOwner.Enabled = false;
          
           
            //hide update owner button
            btnUpdateOwner.Enabled = false;
            btnUpdateOwner.Visible = false;
            

            // AddOwner Panel and 'Save Owner' button are visible and enabled
            pnlAddOwner.Visible = true;
            pnlAddOwner.Enabled = true;
            btnSaveOwner.Enabled = true;
            btnSaveOwner.Visible = true;
            
        }

        /// <summary>
        /// Event handler for 'Save Owner' button on the "AddOwner Panel"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// 

        private void btnSaveOwner_Click(object sender, EventArgs e)
           {
              
            //Create a new row that the variables will be added into
            DataRow newOwnerRow = _dm._dtOwner.NewRow();

            //If any of the text areas are empty then do not write data and return

            if ((tbOwnerAddLastN.Text == "") || (tbOwnerAddFirstN.Text == "") ||
               (tbOwnerAddAddress.Text == "") || (tbOwnerAddSuburb.Text == ""))
            {
                MessageBox.Show("You must enter a value for each of the text fields. However phone number is not required", "Error");
                return;
            }

         else
           
           {
                newOwnerRow["LastName"] = tbOwnerAddLastN.Text;
                newOwnerRow["FirstName"] = tbOwnerAddFirstN.Text;
                newOwnerRow["StreetAddress"] = tbOwnerAddAddress.Text;
                newOwnerRow["Suburb"] = tbOwnerAddSuburb.Text;
                newOwnerRow["PhoneNumber"] = maskTbOwnerNumber.Text;
                newOwnerRow["Details"] = tbOwnerAddFirstN.Text + " " + tbOwnerAddLastN.Text;

                //Add the new row to the Table

                _dm._dtOwner.Rows.Add(newOwnerRow);
                _dm.UpdateOwner();
                
                //Give the user a success message
                MessageBox.Show("Owner added successfully", "Success");
                
           }
            // Going back to OwnerMaintenance form (close the panel)
            this.btnReturnToOwnerF_Click(this, new EventArgs());
            return;
        }

        /// <summary>
        /// Event handler for 'delete owner' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        ///

       private void btnDeleteOwner_Click(object sender, EventArgs e)
        {
            DataRow DeleteOwnerRow = _dm._dtOwner.Rows[_currencyManager.Position];
            DataRow[] CatRow = _dm._dtCat.Select("OwnerID = " + lblOwnerId.Text);
            if (CatRow.Length != 0)
            {
                MessageBox.Show("You may only delete owners who do not have cats", "Error");
                return;
            }

            else
            {
                if (MessageBox.Show("Are you sure you want to delete this record?", "Warning",
                                    MessageBoxButtons.OKCancel) == DialogResult.OK)
                {
                    DeleteOwnerRow.Delete();
                  
                }
                _dm.UpdateOwner();

            }

            return;

        }


        /// <summary>
        /// Event Handler for Modifying Owner
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// 

       private void btnModifyOwner_Click(object sender, EventArgs e)
       {
           //show panel and disable unneeded buttons
           pnlAddOwner.Visible = true;
           pnlAddOwner.Enabled = true;
           btnAddOwner.Enabled = false;
           btnDeleteOwner.Enabled = false;
           btnSaveOwner.Visible = false;
           btnSaveOwner.Enabled = false;
           //show update owner button
           btnUpdateOwner.Visible = true;
           btnUpdateOwner.Enabled = true;

           //show textdata of the chosen owner  in textboxes 
           tbOwnerAddFirstN.Text = _dm.datasetGlendene.OWNER.Rows[_currencyManager.Position]["FirstName"].ToString();
           tbOwnerAddLastN.Text = _dm.datasetGlendene.OWNER.Rows[_currencyManager.Position]["LastName"].ToString();
           tbOwnerAddAddress.Text = _dm.datasetGlendene.OWNER.Rows[_currencyManager.Position]["StreetAddress"].ToString();
           tbOwnerAddSuburb.Text = _dm.datasetGlendene.OWNER.Rows[_currencyManager.Position]["Suburb"].ToString();
           maskTbOwnerNumber.Text = _dm.datasetGlendene.OWNER.Rows[_currencyManager.Position]["PhoneNumber"].ToString();
           return;
       }


        /// <summary>
        /// Event handler for "Update Owner" button 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

       private void btnUpdateOwner_Click(object sender, EventArgs e)
       {
           // The row of the chosen owner
    
           DataRow updateOwnerRow = _dm._dtOwner.Rows[_currencyManager.Position];

          // Condition, if text boxes are empty- error
           if ((tbOwnerAddLastN.Text =="") || (tbOwnerAddFirstN.Text =="") ||
              (tbOwnerAddAddress.Text =="") || (tbOwnerAddSuburb.Text ==""))
           {
               MessageBox.Show("You must enter a value for each of the text fields. However phone number is not required", "Error");
               return;
           }
           else
           {
               //Add the text areas
               updateOwnerRow["LastName"] = tbOwnerAddLastN.Text;
               updateOwnerRow["FirstName"] = tbOwnerAddFirstN.Text;
               updateOwnerRow["StreetAddress"] = tbOwnerAddAddress.Text;
               updateOwnerRow["Suburb"] = tbOwnerAddSuburb.Text;
               updateOwnerRow["PhoneNumber"] = maskTbOwnerNumber.Text;

               //Update the database

               _currencyManager.EndCurrentEdit();
               _dm.UpdateOwner();

               //Give the user a success message
               MessageBox.Show("Owner updated successfully", "Success");
           }
           
           this.btnReturnToOwnerF_Click(this, new EventArgs());
           return;
       }


       /// <summary>
       /// Event handler for "Cancel" button on the Add Owner Panel
       /// </summary>
       /// <param name="sender"></param>
       /// <param name="e"></param>

       private void btnReturnToOwnerF_Click(object sender, EventArgs e)
       {
           pnlAddOwner.Hide();
           
           btnDeleteOwner.Enabled = true;
           btnModifyOwner.Enabled = true;
           btnOwnerReturn.Enabled = true;
           btnAddOwner.Enabled = true;
       }


       /// <summary>
       ///  Close 'Owner Maintenance Form' and return to the MainMenu form
       /// </summary>
       /// <param name="sender"></param>
       /// <param name="e"></param>
       /// 

       private void btnReturn_Click(object sender, EventArgs e)
       {
           Close();
       }

      

      

    
     

     
       
     
    }
}
