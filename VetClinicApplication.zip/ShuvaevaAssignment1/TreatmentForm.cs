﻿/*
 * Description: Treatment maintenance form. Allows to read, add, modify ,delete treatments.
 * Author: Elena Shuvaeva
 * Date: 26.08.2014
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ShuvaevaAssignment1
{
    public partial class TreatmentForm : Form
    {
         /// <summary>
        ///  Declare a shared data source (add references to DataModul ,MainMenu and CurrencyManager objects)
         /// </summary>

        private DataModule _dm;
        private MainMenu _mmenu;
        private CurrencyManager _currencyManager;

        //Error message provider (here for the textbox "Cost")
        private ErrorProvider _ep = new ErrorProvider();

        /// <summary>
        /// Changing the constructor to accept Datamodul and Main menu references
        /// </summary>
        /// <param name="dm"></param>
        /// <param name="mmenu"></param>

        public TreatmentForm(DataModule dm,MainMenu mmenu)
        {
            // Create and set values for the controls
            InitializeComponent();

            //Store the location of the data modul
            _dm = dm;

            // Store the location of the menu form
            _mmenu = mmenu;

            //Run the code for binding the controls on the form
            BindControls();

            //Hide adding panel
           
            pnlAddTreat.Visible = false;
            pnlAddTreat.Enabled = false;

        }

        
        /// <summary>
        /// Binds controls to the data source (bind the data to listbox and textboxes)
        /// </summary>
        public void BindControls()
        {
            lstTreatments.DataSource = _dm.datasetGlendene.TREATMENT;
            lstTreatments.DisplayMember = "Description";
            lstTreatments.ValueMember = "TreatmentID";

            lblTreatId.DataBindings.Add("Text", _dm.datasetGlendene, "TREATMENT.TreatmentID");
            tbTreatDesc.DataBindings.Add("Text", _dm.datasetGlendene, "TREATMENT.Description");
            tbTreatCost.DataBindings.Add("Text", _dm.datasetGlendene, "TREATMENT.Cost");

            _currencyManager = (CurrencyManager)this.BindingContext[_dm.datasetGlendene, "TREATMENT"];
            lstTreatments.SelectedIndexChanged += new EventHandler(TreatmentsIndexChanged);
        }


        /// <summary>
        /// Event handler for  navigating between treatments in the listbox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TreatmentsIndexChanged(Object sender, EventArgs e)
        {
            if (lstTreatments.SelectedIndex >= 0 && lstTreatments.SelectedIndex < _currencyManager.Count)
            {
                _currencyManager.Position = lstTreatments.SelectedIndex;
            }
           
        }


        /// <summary>
        /// Event Handler for 'Previous Treatment' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnPreviousTreat_Click(object sender, EventArgs e)
        {
            if (_currencyManager.Position > 0)
            {
                --_currencyManager.Position;
                lstTreatments.SelectedIndex = _currencyManager.Position;
            }
        }


        /// <summary>
        /// Event Handler for 'Next Treatment' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnNextTreat_Click(object sender, EventArgs e)
        {
            if (_currencyManager.Position < _currencyManager.Count-1)
            {
                ++_currencyManager.Position;
                lstTreatments.SelectedIndex = _currencyManager.Position;
            }
        }

        /// <summary>
        /// Event Handler for 'Add Treatment' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void btnAddTreat_Click(object sender, EventArgs e)
        {
            // Empty textboxes in the AddTreatment panel

            tbTreatAddDescr.Text = "";
            tbTreatAddCost.Text = "";
                 
         
            //Disable unneeded buttons
            btnDeleteTreat.Enabled = false;
            btnModifyTreat.Enabled = false;
       
            //Hide update Treatment button
            btnUpdateTreat.Enabled = false;
            btnUpdateTreat.Visible = false;
           

            // AddTreat Panel and 'Save' button is visible and enabled
            pnlAddTreat.Visible = true;
            pnlAddTreat.Enabled = true;
            btnSaveTreat.Enabled = true;
            btnSaveTreat.Visible = true;
        }

        /// <summary>
        /// Event Handler for 'Save Treatment' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void btnSaveTreat_Click(object sender, EventArgs e)
        {
            //Create a new row that the variables will be added into
            DataRow newTreatRow = _dm._dtTreatment.NewRow();

            //If any of the text areas for required fields are empty then do not write data

            if ((tbTreatAddDescr.Text == "") || (tbTreatAddCost.Text == ""))
            {
                MessageBox.Show("You must enter a value for each of the text fields", "Error");
                return;
            }
            else
            {
                newTreatRow["Description"] = tbTreatAddDescr.Text;
                newTreatRow["Cost"] = Convert.ToDouble(tbTreatAddCost.Text);
                

                //Add the new row to the Table
                _dm._dtTreatment.Rows.Add(newTreatRow);
                _dm.UpdateTreatment();

                //Give the user a success message
                MessageBox.Show("Treatment added successfully", "Success");
            }

            this.btnReturnToTreatF_Click(this, new EventArgs());

            return;

        }


        /// <summary>
        /// Event Handler for 'Cancel' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnReturnToTreatF_Click(object sender, EventArgs e)
        {
            pnlAddTreat.Enabled = false;
            pnlAddTreat.Visible = false;
            btnModifyTreat.Enabled = true;
            btnDeleteTreat.Enabled = true;
            btnAddTreat.Enabled = true;

        }

        /// <summary>
        /// Event Handler for 'Modify Treatment' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnModifyTreat_Click(object sender, EventArgs e)
        {
            pnlAddTreat.Enabled = true;
            pnlAddTreat.Visible = true;
            btnSaveTreat.Enabled = false;
            btnSaveTreat.Visible = false;
            btnUpdateTreat.Enabled = true;
            btnUpdateTreat.Visible = true;
            btnAddTreat.Enabled = false;
            btnDeleteTreat.Enabled = false;

            //in the panel textboxes user can see the chosen treatment and cost to modify
            tbTreatAddDescr.Text = _dm.datasetGlendene.TREATMENT.Rows[_currencyManager.Position]["Description"].ToString();
            tbTreatAddCost.Text = _dm.datasetGlendene.TREATMENT.Rows[_currencyManager.Position]["Cost"].ToString();


        }

        /// <summary>
        /// Event Handler for 'Update Treatment' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void btnUpdateTreat_Click(object sender, EventArgs e)


        {
            DataRow UpdateTreatRow = _dm._dtTreatment.Rows[_currencyManager.Position];
            if (tbTreatAddDescr.Text == "" || tbTreatAddCost.Text == "")
            {
                MessageBox.Show("You must enter a value for each of the text fields", "Error");
                return;
            }
            else
            {
                UpdateTreatRow["Description"] = tbTreatAddDescr.Text;
                UpdateTreatRow["Cost"] = Convert.ToDouble(tbTreatAddCost.Text);

                _currencyManager.EndCurrentEdit();
                _dm.UpdateTreatment();

                //Give the user a success message

                MessageBox.Show("Treatment updated successfully", "Success");
            }
            return;

        }

        /// <summary>
        /// Event Handler for 'Delete Treatment' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDeleteTreat_Click(object sender, EventArgs e)
        {
            DataRow DeleteRow = _dm._dtTreatment.Rows[_currencyManager.Position];
            DataRow[] VisitTreatRow = _dm._dtVisitTreatment.Select("TreatmentID = " + lblTreatId.Text);

            if (VisitTreatRow.Length != 0)
            {
                MessageBox.Show("You may only delete treatments that are not allocated to visits", "Error");
                return;
            }
            else
            {
                if (MessageBox.Show("Are you sure you want to delete this record?", "Warning!",
                                 MessageBoxButtons.OKCancel) == DialogResult.OK)
                    DeleteRow.Delete();
                _dm.UpdateTreatment();
            }
        }



        /// <summary>
        /// Event Handler for 'Return To Main Menu' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnTreatReturn_Click(object sender, EventArgs e)
        {
            Close();

        }
        /// <summary>
        /// Check if the user enter valid data in the textbox "Cost"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void AddCostTextChange(object sender, EventArgs e)
        {
            double cost;

            if (double.TryParse(tbTreatAddCost.Text, out cost) &&(cost >=0))
            {
                btnSaveTreat.Enabled = true;
                btnUpdateTreat.Enabled = true;

                _ep.SetError(tbTreatAddCost, "");

            }
            else
            {
                btnSaveTreat.Enabled = false;
                btnUpdateTreat.Enabled = false;
                _ep.SetError(tbTreatAddCost, "Please enter a positive number here");
            }
        }

       












    }
}
