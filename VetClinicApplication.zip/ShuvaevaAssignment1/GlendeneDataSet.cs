﻿namespace ShuvaevaAssignment1 {
    
    
    public partial class GlendeneDataSet {




       
    }
}
