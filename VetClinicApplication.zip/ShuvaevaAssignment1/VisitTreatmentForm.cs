﻿/*
 * Description: VisitTreatment form. Allows to read,allocate,modify,delete treatments for a visit.
 * Author: Elena Shuvaeva
 * Date: 26.08.2014
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ShuvaevaAssignment1
{

    /// <summary>
    /// Declare a shared data source (add references to DataModul ,MainMenu , CurrencyManager and BindingSource objects)
    /// </summary>
    public partial class VisitTreatmentForm : Form
    {

        private DataModule _dm;
        private MainMenu _mmenu;
        private CurrencyManager _currencyManager;

        //bindingsource is created to filtr visitTreatments by visitId and to populate datagridview

        private BindingSource _visitTreatmentSource = new BindingSource();

        /// <summary>
        /// Changing the constructor to accept Datamodul and Main menu references
        /// </summary>
        /// <param name="dm"></param>
        /// <param name="mmenu"></param>
        public VisitTreatmentForm(DataModule dm, MainMenu mmenu)
        {
            // Create and set values for the controls
            InitializeComponent();

            //Store the location of the data modul
            _dm = dm;

            // Store the location of the menu form
            _mmenu = mmenu;


            //Run the code for binding the controls on the form
            BindControls();

            //panel is hidden
            pnlVisitTreatAddTreat.Enabled = false;
            pnlVisitTreatAddTreat.Visible = false;


        }

        /// <summary>
        /// Binds controls to the data source (bind the data to listbox and textboxes)
        /// </summary>
        public void BindControls()
        {

            // datasource for listbox
            lstVisitTreatVisitsId.DataSource = _dm.datasetGlendene.VISIT;
            lstVisitTreatVisitsId.DisplayMember = "VisitID";
            lstVisitTreatVisitsId.ValueMember = "VisitID";

            //bind the data for textboxes
            tbVisitTreatCatName.DataBindings.Add ("Text",_dm.datasetGlendene,"VISIT.Name");
            tbVisitTreatOwnerName.DataBindings.Add ("Text",_dm.datasetGlendene,"VISIT.OwnerDetails");
            tbVisitTreatVetName.DataBindings.Add("Text",_dm.datasetGlendene,"VISIT.VeterinarianDetails");
            tbVisitTreatStatus.DataBindings.Add("Text", _dm.datasetGlendene, "VISIT.Status");

            //datasource for combobox
            cmbVisitTreatAddDescr.DataSource = _dm.datasetGlendene.TREATMENT;
            cmbVisitTreatAddDescr.DisplayMember = "Description";
            cmbVisitTreatAddDescr.ValueMember = "TreatmentID";

             _currencyManager = (CurrencyManager)this.BindingContext[_dm.datasetGlendene, "VISIT"];
             lstVisitTreatVisitsId.SelectedIndexChanged += new EventHandler(VisitsIndexChanged);

            //source for bindingsource
             _visitTreatmentSource.DataSource = _dm.datasetGlendene;
             _visitTreatmentSource.DataMember = "VISITTREATMENT";

            //source for datagridview
             dgvVisitTreatments.DataSource = _visitTreatmentSource;

            //hide unneeded columns in th datagridview
             dgvVisitTreatments.Columns["TreatmentID"].Visible = false;
             dgvVisitTreatments.Columns["CatID"].Visible = false;
             dgvVisitTreatments.Columns["OwnerID"].Visible = false;
             dgvVisitTreatments.Columns["VeterinarianID"].Visible = false;
             dgvVisitTreatments.Columns["VetDetails"].Visible = false;
             dgvVisitTreatments.Columns["OwnerDetails"].Visible =false;
             dgvVisitTreatments.Columns["Name"].Visible = false;
             

            
            _currencyManager.PositionChanged += new EventHandler(PositionChanged);


            this.PositionChanged(this, new EventArgs());
        }



        /// <summary>
        /// Event handler for  showing visittreatments in the datagridview during the navigating between visitId
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void PositionChanged(object sender, EventArgs e)
        {

            if (_currencyManager.Position >= 0)
            {
                _visitTreatmentSource.Filter = "VisitID = " + _dm.datasetGlendene.VISIT.Rows[_currencyManager.Position]["VisitID"].ToString();
            }
           
        }

         /// <summary>
        /// Event handler for  navigating between visits in the listbox
         /// </summary>
         /// <param name="sender"></param>
         /// <param name="e"></param>
        private void VisitsIndexChanged(object sender, EventArgs e)
        {
            if (lstVisitTreatVisitsId.SelectedIndex >= 0 && lstVisitTreatVisitsId.SelectedIndex < _currencyManager.Count)
            {
                 _currencyManager.Position = lstVisitTreatVisitsId.SelectedIndex;
            }

        }

        /// <summary>
        /// Event Handler for 'Previous Visit' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnVisitTreatPreviousVisit_Click(object sender, EventArgs e)
        {
            if (lstVisitTreatVisitsId.SelectedIndex > 0)
            {
                --_currencyManager.Position;
                lstVisitTreatVisitsId.SelectedIndex= _currencyManager.Position;
            }
        }

        /// <summary>
        /// Event Handler for 'Next Visit' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnVisitTreatNextVisit_Click(object sender, EventArgs e)
        {
            if (lstVisitTreatVisitsId.SelectedIndex < _currencyManager.Count - 1)
            {
                ++_currencyManager.Position;
                lstVisitTreatVisitsId.SelectedIndex = _currencyManager.Position;
            }
        }

        /// <summary>
        /// Event Handler for 'Allocate Treatment' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAllocateTreat_Click(object sender, EventArgs e)
        
        {
            
           //Condition -treatment can be allocated if the visit status is pending
            string currentStatus = _dm.datasetGlendene.VISIT.Rows[_currencyManager.Position]["Status"].ToString();
            if (currentStatus == DataModule.STATUS_PENDING)
            {
                //unable modify and delete buttons
                btnVisitTreatModifyTreat.Enabled = false;
                btnVisitTreatRemoveTreat.Enabled = false;
                //the panel shown
                pnlVisitTreatAddTreat.Enabled = true;
                pnlVisitTreatAddTreat.Visible = true;
                
                //fiels on the adding panel (update button is hidden)
                maskTbVisitTreatQuantity.Text = "";
                btnVisitTreatUpdate.Visible = false;
                btnVisitTreatUpdate.Enabled = false;
                cmbVisitTreatAddDescr.Enabled = true;
                cmbVisitTreatAddDescr.Text = "";
                btnVisitTreatSave.Enabled = true;
                btnVisitTreatSave.Visible = true;
                lblVisitTreathint.Visible = true;
                lblVisitTreathint.Enabled = true;


            }
            else 
            {
                MessageBox.Show("Cannot allocate treatments to paid visits","Error");
            }

        }

        /// <summary>
        /// Event Handler for 'Modify Treatment' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void btnVisitTreatModifyTreat_Click(object sender, EventArgs e)

        {

            // the visit status must be pending 
            string currentStatus = _dm.datasetGlendene.VISIT.Rows[_currencyManager.Position]["Status"].ToString();
            if (currentStatus == DataModule.STATUS_PENDING)
            {
                //unable allocate and remove treatment buttons
                btnAllocateTreat.Enabled = false;
                btnVisitTreatRemoveTreat.Enabled = false;
                //show panel
                pnlVisitTreatAddTreat.Enabled = true;
                pnlVisitTreatAddTreat.Visible = true;
                //combobox is readonly
                cmbVisitTreatAddDescr.Enabled = false;
                //save button hidden
                btnVisitTreatSave.Enabled = false;
                btnVisitTreatSave.Visible = false;
                btnVisitTreatUpdate.Enabled = true;
                btnVisitTreatUpdate.Visible = true;
                


                if (dgvVisitTreatments.SelectedRows == null
                    ||
                    dgvVisitTreatments.SelectedRows.Count == 0
                    ||
                    dgvVisitTreatments.SelectedRows.Count > 1)
                    
                {
                    MessageBox.Show("No treatment to update is chosen. Please choose one.","Error");
                    pnlVisitTreatAddTreat.Visible = false;
                    pnlVisitTreatAddTreat.Enabled = false;
                    btnAllocateTreat.Enabled = true;
                    btnVisitTreatRemoveTreat.Enabled = true;
                    return;
                }

                // the Row of the chosen visit
                DataRow updateVisitTreatRow = (dgvVisitTreatments.SelectedRows[0].DataBoundItem as DataRowView).Row;

                cmbVisitTreatAddDescr.SelectedValue = updateVisitTreatRow["TreatmentID"].ToString();

                maskTbVisitTreatQuantity.Text = updateVisitTreatRow["Quantity"].ToString();



            }
            else 
            {
                MessageBox.Show("Cannot modify treatments on a paid visit", "Error");
            }

        }


        /// <summary>
        /// Event Handler for 'Remove Treatment' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void btnVisitTreatRemoveTreat_Click(object sender, EventArgs e)
        {
            //Condition - only treatments with pending status can be removed
            string currentStatus = _dm.datasetGlendene.VISIT.Rows[_currencyManager.Position]["Status"].ToString();
            if (currentStatus == DataModule.STATUS_PENDING )
            {
                if (dgvVisitTreatments.Rows.Count == 0)
                {
                    MessageBox.Show("No treatments to remove");
                }
                else
                {
                    
                    DataRow deleteVisitTreatRow = (dgvVisitTreatments.SelectedRows[0].DataBoundItem as DataRowView).Row;

                    if (MessageBox.Show("Are you sure you want to delete this record?", "Warning!",
                                       MessageBoxButtons.OKCancel) == DialogResult.OK)
                    {
                        deleteVisitTreatRow.Delete();
                        _dm.UpdateVisitTreatment();
                    }

                    else
                    {
                        MessageBox.Show("You may only remove treatments from pending visits", "Error");
                    }
                }
                }
            
        }


        /// <summary>
        /// Event Handler for 'Save' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnVisitTreatSave_Click(object sender, EventArgs e)
        {
            DataRow NewAllocatedTreatmentRow = _dm._dtVisitTreatment.NewRow();
            if (cmbVisitTreatAddDescr.SelectedValue == null || maskTbVisitTreatQuantity.Text == "")
            {
                MessageBox.Show("Enter please all values for all fields","Error");
                return;
            }


            else
            {
                try
                {
                    NewAllocatedTreatmentRow["Description"] = cmbVisitTreatAddDescr.Text;
                    NewAllocatedTreatmentRow["Quantity"] = maskTbVisitTreatQuantity.Text;
                    NewAllocatedTreatmentRow["VisitID"] = lstVisitTreatVisitsId.SelectedValue;

                    NewAllocatedTreatmentRow["TreatmentID"] = cmbVisitTreatAddDescr.SelectedValue;

                    _dm._dtVisitTreatment.Rows.Add(NewAllocatedTreatmentRow);
                    _dm.UpdateVisitTreatment();

                    //Give successfull message to the user
                    MessageBox.Show("Treatment added successfully","Success");
                }

                catch (ConstraintException)
                {
                    MessageBox.Show("You cannot add treatment which is already in the list. Use modify button to change the quantity.","Error");
                    return;
                }

                //close panel
                pnlVisitTreatAddTreat.Enabled = false;
                pnlVisitTreatAddTreat.Visible = false;
                //enable Modify button
                btnVisitTreatModifyTreat.Enabled = true;
                btnVisitTreatRemoveTreat.Enabled = true;
                //hide hint
                lblVisitTreathint.Enabled = false;
                lblVisitTreathint.Visible = false;
            }

        }

        /// <summary>
        /// Event Handler for 'Cancel' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnReturnToVisitF_Click(object sender, EventArgs e)
        {
            //close panel
            pnlVisitTreatAddTreat.Enabled = false;
            pnlVisitTreatAddTreat.Visible = false;
            //allocae treatment,modify treatment and remove treatment buttons- enable
            btnAllocateTreat.Enabled = true;
            btnVisitTreatRemoveTreat.Enabled = true;
            btnVisitTreatModifyTreat.Enabled = true;



        }

        /// <summary>
        /// Event Handler for 'Update' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void btnVisitTreatUpdate_Click(object sender, EventArgs e)
        {


            // the Row of the chosen visit
            DataRow updateVisitTreatRow = (dgvVisitTreatments.SelectedRows[0].DataBoundItem as DataRowView).Row;


            //Condition if the values are empty

            if (maskTbVisitTreatQuantity.Text == "")
               
            {
                MessageBox.Show("You should enter the quantity","Error");
                return;

            }
            else

                //update row
                updateVisitTreatRow["Quantity"] = maskTbVisitTreatQuantity.Text;
                //close panel
                pnlVisitTreatAddTreat.Enabled = false;
                pnlVisitTreatAddTreat.Visible = false;
                //Allocate treatment,remove and modify buttons are enabled
                btnAllocateTreat.Enabled = true;
                btnVisitTreatRemoveTreat.Enabled = true;
                btnVisitTreatModifyTreat.Enabled = true;
                _dm.UpdateVisitTreatment();



        }


        /// <summary>
        /// Event Handler for 'Return to main form' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnVisitTreatReturn_Click(object sender, EventArgs e)
        {
            Close();
        }

       

      



    }
}
