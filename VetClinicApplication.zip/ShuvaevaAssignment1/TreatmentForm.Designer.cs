﻿namespace ShuvaevaAssignment1
{
    partial class TreatmentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.grpTreatMaintenance = new System.Windows.Forms.GroupBox();
            this.btnTreatReturn = new System.Windows.Forms.Button();
            this.btnDeleteTreat = new System.Windows.Forms.Button();
            this.btnPreviousTreat = new System.Windows.Forms.Button();
            this.btnNextTreat = new System.Windows.Forms.Button();
            this.btnModifyTreat = new System.Windows.Forms.Button();
            this.btnAddTreat = new System.Windows.Forms.Button();
            this.lstTreatments = new System.Windows.Forms.ListBox();
            this.lblTreatIdname = new System.Windows.Forms.Label();
            this.lblTreatDescription = new System.Windows.Forms.Label();
            this.grpTreatDetails = new System.Windows.Forms.GroupBox();
            this.tbTreatCost = new System.Windows.Forms.TextBox();
            this.lblTreatId = new System.Windows.Forms.Label();
            this.tbTreatDesc = new System.Windows.Forms.TextBox();
            this.lblTreatCost = new System.Windows.Forms.Label();
            this.btnUpdateTreat = new System.Windows.Forms.Button();
            this.btnReturnToTreatF = new System.Windows.Forms.Button();
            this.btnSaveTreat = new System.Windows.Forms.Button();
            this.pnlAddTreat = new System.Windows.Forms.Panel();
            this.lblTreathint = new System.Windows.Forms.Label();
            this.tbTreatAddDescr = new System.Windows.Forms.TextBox();
            this.lblTreatAddCost = new System.Windows.Forms.Label();
            this.lblTreatAddDescr = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tbTreatAddCost = new System.Windows.Forms.TextBox();
            this.grpTreatMaintenance.SuspendLayout();
            this.grpTreatDetails.SuspendLayout();
            this.pnlAddTreat.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpTreatMaintenance
            // 
            this.grpTreatMaintenance.Controls.Add(this.btnTreatReturn);
            this.grpTreatMaintenance.Controls.Add(this.btnDeleteTreat);
            this.grpTreatMaintenance.Controls.Add(this.btnPreviousTreat);
            this.grpTreatMaintenance.Controls.Add(this.btnNextTreat);
            this.grpTreatMaintenance.Controls.Add(this.btnModifyTreat);
            this.grpTreatMaintenance.Controls.Add(this.btnAddTreat);
            this.grpTreatMaintenance.Controls.Add(this.lstTreatments);
            this.grpTreatMaintenance.Font = new System.Drawing.Font("Vivaldi", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpTreatMaintenance.Location = new System.Drawing.Point(12, 12);
            this.grpTreatMaintenance.Name = "grpTreatMaintenance";
            this.grpTreatMaintenance.Size = new System.Drawing.Size(426, 478);
            this.grpTreatMaintenance.TabIndex = 33;
            this.grpTreatMaintenance.TabStop = false;
            this.grpTreatMaintenance.Text = "Treatment Maintenance";
            // 
            // btnTreatReturn
            // 
            this.btnTreatReturn.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTreatReturn.Location = new System.Drawing.Point(8, 331);
            this.btnTreatReturn.Name = "btnTreatReturn";
            this.btnTreatReturn.Size = new System.Drawing.Size(354, 50);
            this.btnTreatReturn.TabIndex = 6;
            this.btnTreatReturn.Text = "Return to Main Menu";
            this.btnTreatReturn.UseVisualStyleBackColor = true;
            this.btnTreatReturn.Click += new System.EventHandler(this.btnTreatReturn_Click);
            // 
            // btnDeleteTreat
            // 
            this.btnDeleteTreat.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnDeleteTreat.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnDeleteTreat.Location = new System.Drawing.Point(8, 414);
            this.btnDeleteTreat.Name = "btnDeleteTreat";
            this.btnDeleteTreat.Size = new System.Drawing.Size(354, 49);
            this.btnDeleteTreat.TabIndex = 7;
            this.btnDeleteTreat.Text = "Delete Treatment";
            this.btnDeleteTreat.UseVisualStyleBackColor = true;
            this.btnDeleteTreat.Click += new System.EventHandler(this.btnDeleteTreat_Click);
            // 
            // btnPreviousTreat
            // 
            this.btnPreviousTreat.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnPreviousTreat.Location = new System.Drawing.Point(17, 153);
            this.btnPreviousTreat.Name = "btnPreviousTreat";
            this.btnPreviousTreat.Size = new System.Drawing.Size(176, 37);
            this.btnPreviousTreat.TabIndex = 2;
            this.btnPreviousTreat.Text = "Previous Treatment";
            this.btnPreviousTreat.UseVisualStyleBackColor = true;
            this.btnPreviousTreat.Click += new System.EventHandler(this.btnPreviousTreat_Click);
            // 
            // btnNextTreat
            // 
            this.btnNextTreat.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnNextTreat.Location = new System.Drawing.Point(199, 153);
            this.btnNextTreat.Name = "btnNextTreat";
            this.btnNextTreat.Size = new System.Drawing.Size(178, 37);
            this.btnNextTreat.TabIndex = 3;
            this.btnNextTreat.Text = "Next Treatment";
            this.btnNextTreat.UseVisualStyleBackColor = true;
            this.btnNextTreat.Click += new System.EventHandler(this.btnNextTreat_Click);
            // 
            // btnModifyTreat
            // 
            this.btnModifyTreat.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnModifyTreat.Location = new System.Drawing.Point(8, 260);
            this.btnModifyTreat.Name = "btnModifyTreat";
            this.btnModifyTreat.Size = new System.Drawing.Size(354, 42);
            this.btnModifyTreat.TabIndex = 5;
            this.btnModifyTreat.Text = "Modify Treatment";
            this.btnModifyTreat.UseVisualStyleBackColor = true;
            this.btnModifyTreat.Click += new System.EventHandler(this.btnModifyTreat_Click);
            // 
            // btnAddTreat
            // 
            this.btnAddTreat.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnAddTreat.ForeColor = System.Drawing.Color.Green;
            this.btnAddTreat.Location = new System.Drawing.Point(8, 206);
            this.btnAddTreat.Name = "btnAddTreat";
            this.btnAddTreat.Size = new System.Drawing.Size(354, 41);
            this.btnAddTreat.TabIndex = 4;
            this.btnAddTreat.Text = "Add Treatment";
            this.btnAddTreat.UseVisualStyleBackColor = true;
            this.btnAddTreat.Click += new System.EventHandler(this.btnAddTreat_Click);
            // 
            // lstTreatments
            // 
            this.lstTreatments.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lstTreatments.FormattingEnabled = true;
            this.lstTreatments.ItemHeight = 21;
            this.lstTreatments.Location = new System.Drawing.Point(23, 46);
            this.lstTreatments.Name = "lstTreatments";
            this.lstTreatments.Size = new System.Drawing.Size(354, 88);
            this.lstTreatments.TabIndex = 1;
            // 
            // lblTreatIdname
            // 
            this.lblTreatIdname.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTreatIdname.BackColor = System.Drawing.SystemColors.Control;
            this.lblTreatIdname.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblTreatIdname.ForeColor = System.Drawing.Color.Black;
            this.lblTreatIdname.Location = new System.Drawing.Point(32, 32);
            this.lblTreatIdname.Name = "lblTreatIdname";
            this.lblTreatIdname.Size = new System.Drawing.Size(106, 23);
            this.lblTreatIdname.TabIndex = 21;
            this.lblTreatIdname.Text = "Treatment ID";
            // 
            // lblTreatDescription
            // 
            this.lblTreatDescription.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTreatDescription.BackColor = System.Drawing.SystemColors.Control;
            this.lblTreatDescription.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblTreatDescription.ForeColor = System.Drawing.Color.Black;
            this.lblTreatDescription.Location = new System.Drawing.Point(30, 74);
            this.lblTreatDescription.Name = "lblTreatDescription";
            this.lblTreatDescription.Size = new System.Drawing.Size(171, 22);
            this.lblTreatDescription.TabIndex = 2;
            this.lblTreatDescription.Text = "Description";
            // 
            // grpTreatDetails
            // 
            this.grpTreatDetails.Controls.Add(this.tbTreatCost);
            this.grpTreatDetails.Controls.Add(this.lblTreatIdname);
            this.grpTreatDetails.Controls.Add(this.lblTreatId);
            this.grpTreatDetails.Controls.Add(this.tbTreatDesc);
            this.grpTreatDetails.Controls.Add(this.lblTreatCost);
            this.grpTreatDetails.Controls.Add(this.lblTreatDescription);
            this.grpTreatDetails.Location = new System.Drawing.Point(454, 16);
            this.grpTreatDetails.Name = "grpTreatDetails";
            this.grpTreatDetails.Size = new System.Drawing.Size(432, 500);
            this.grpTreatDetails.TabIndex = 34;
            this.grpTreatDetails.TabStop = false;
            // 
            // tbTreatCost
            // 
            this.tbTreatCost.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tbTreatCost.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbTreatCost.Location = new System.Drawing.Point(226, 114);
            this.tbTreatCost.Name = "tbTreatCost";
            this.tbTreatCost.ReadOnly = true;
            this.tbTreatCost.Size = new System.Drawing.Size(173, 29);
            this.tbTreatCost.TabIndex = 22;
            // 
            // lblTreatId
            // 
            this.lblTreatId.AutoSize = true;
            this.lblTreatId.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblTreatId.Location = new System.Drawing.Point(222, 30);
            this.lblTreatId.Name = "lblTreatId";
            this.lblTreatId.Size = new System.Drawing.Size(29, 23);
            this.lblTreatId.TabIndex = 20;
            this.lblTreatId.Text = "ID";
            // 
            // tbTreatDesc
            // 
            this.tbTreatDesc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tbTreatDesc.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbTreatDesc.Location = new System.Drawing.Point(226, 76);
            this.tbTreatDesc.Name = "tbTreatDesc";
            this.tbTreatDesc.ReadOnly = true;
            this.tbTreatDesc.Size = new System.Drawing.Size(173, 29);
            this.tbTreatDesc.TabIndex = 5;
            // 
            // lblTreatCost
            // 
            this.lblTreatCost.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTreatCost.BackColor = System.Drawing.SystemColors.Control;
            this.lblTreatCost.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblTreatCost.ForeColor = System.Drawing.Color.Black;
            this.lblTreatCost.Location = new System.Drawing.Point(30, 121);
            this.lblTreatCost.Name = "lblTreatCost";
            this.lblTreatCost.Size = new System.Drawing.Size(110, 28);
            this.lblTreatCost.TabIndex = 7;
            this.lblTreatCost.Text = "Cost";
            // 
            // btnUpdateTreat
            // 
            this.btnUpdateTreat.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnUpdateTreat.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnUpdateTreat.ForeColor = System.Drawing.Color.Green;
            this.btnUpdateTreat.Location = new System.Drawing.Point(232, 223);
            this.btnUpdateTreat.Name = "btnUpdateTreat";
            this.btnUpdateTreat.Size = new System.Drawing.Size(242, 47);
            this.btnUpdateTreat.TabIndex = 10;
            this.btnUpdateTreat.Text = "Update Treatment";
            this.btnUpdateTreat.UseVisualStyleBackColor = true;
            this.btnUpdateTreat.Click += new System.EventHandler(this.btnUpdateTreat_Click);
            // 
            // btnReturnToTreatF
            // 
            this.btnReturnToTreatF.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnReturnToTreatF.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnReturnToTreatF.Location = new System.Drawing.Point(232, 294);
            this.btnReturnToTreatF.Name = "btnReturnToTreatF";
            this.btnReturnToTreatF.Size = new System.Drawing.Size(242, 47);
            this.btnReturnToTreatF.TabIndex = 12;
            this.btnReturnToTreatF.Text = "Cancel";
            this.btnReturnToTreatF.UseVisualStyleBackColor = true;
            this.btnReturnToTreatF.Click += new System.EventHandler(this.btnReturnToTreatF_Click);
            // 
            // btnSaveTreat
            // 
            this.btnSaveTreat.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSaveTreat.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnSaveTreat.ForeColor = System.Drawing.Color.DarkGreen;
            this.btnSaveTreat.Location = new System.Drawing.Point(232, 222);
            this.btnSaveTreat.Name = "btnSaveTreat";
            this.btnSaveTreat.Size = new System.Drawing.Size(242, 48);
            this.btnSaveTreat.TabIndex = 11;
            this.btnSaveTreat.Text = "Save Treatment";
            this.btnSaveTreat.UseVisualStyleBackColor = true;
            this.btnSaveTreat.Click += new System.EventHandler(this.btnSaveTreat_Click);
            // 
            // pnlAddTreat
            // 
            this.pnlAddTreat.BackColor = System.Drawing.Color.Silver;
            this.pnlAddTreat.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlAddTreat.Controls.Add(this.tbTreatAddCost);
            this.pnlAddTreat.Controls.Add(this.lblTreathint);
            this.pnlAddTreat.Controls.Add(this.tbTreatAddDescr);
            this.pnlAddTreat.Controls.Add(this.lblTreatAddCost);
            this.pnlAddTreat.Controls.Add(this.lblTreatAddDescr);
            this.pnlAddTreat.Controls.Add(this.btnUpdateTreat);
            this.pnlAddTreat.Controls.Add(this.btnReturnToTreatF);
            this.pnlAddTreat.Controls.Add(this.btnSaveTreat);
            this.pnlAddTreat.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.pnlAddTreat.Location = new System.Drawing.Point(147, 12);
            this.pnlAddTreat.MaximumSize = new System.Drawing.Size(739, 408);
            this.pnlAddTreat.MinimumSize = new System.Drawing.Size(739, 408);
            this.pnlAddTreat.Name = "pnlAddTreat";
            this.pnlAddTreat.Size = new System.Drawing.Size(739, 408);
            this.pnlAddTreat.TabIndex = 32;
            // 
            // lblTreathint
            // 
            this.lblTreathint.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTreathint.AutoSize = true;
            this.lblTreathint.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblTreathint.ForeColor = System.Drawing.Color.Navy;
            this.lblTreathint.Location = new System.Drawing.Point(366, 124);
            this.lblTreathint.Name = "lblTreathint";
            this.lblTreathint.Size = new System.Drawing.Size(141, 19);
            this.lblTreathint.TabIndex = 31;
            this.lblTreathint.Text = "Enter a number here";
            // 
            // tbTreatAddDescr
            // 
            this.tbTreatAddDescr.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tbTreatAddDescr.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbTreatAddDescr.Location = new System.Drawing.Point(232, 76);
            this.tbTreatAddDescr.MaxLength = 40;
            this.tbTreatAddDescr.Name = "tbTreatAddDescr";
            this.tbTreatAddDescr.Size = new System.Drawing.Size(389, 29);
            this.tbTreatAddDescr.TabIndex = 8;
            // 
            // lblTreatAddCost
            // 
            this.lblTreatAddCost.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTreatAddCost.BackColor = System.Drawing.Color.Silver;
            this.lblTreatAddCost.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblTreatAddCost.ForeColor = System.Drawing.Color.Black;
            this.lblTreatAddCost.Location = new System.Drawing.Point(166, 118);
            this.lblTreatAddCost.Name = "lblTreatAddCost";
            this.lblTreatAddCost.Size = new System.Drawing.Size(60, 28);
            this.lblTreatAddCost.TabIndex = 27;
            this.lblTreatAddCost.Text = "Cost $";
            this.lblTreatAddCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTreatAddDescr
            // 
            this.lblTreatAddDescr.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTreatAddDescr.BackColor = System.Drawing.Color.Silver;
            this.lblTreatAddDescr.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblTreatAddDescr.ForeColor = System.Drawing.Color.Black;
            this.lblTreatAddDescr.Location = new System.Drawing.Point(125, 77);
            this.lblTreatAddDescr.Name = "lblTreatAddDescr";
            this.lblTreatAddDescr.Size = new System.Drawing.Size(101, 22);
            this.lblTreatAddDescr.TabIndex = 25;
            this.lblTreatAddDescr.Text = "Description";
            this.lblTreatAddDescr.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // tbTreatAddCost
            // 
            this.tbTreatAddCost.Location = new System.Drawing.Point(233, 121);
            this.tbTreatAddCost.Name = "tbTreatAddCost";
            this.tbTreatAddCost.Size = new System.Drawing.Size(100, 26);
            this.tbTreatAddCost.TabIndex = 32;
            this.tbTreatAddCost.TextChanged += new System.EventHandler(this.AddCostTextChange);
            // 
            // TreatmentForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(898, 532);
            this.Controls.Add(this.pnlAddTreat);
            this.Controls.Add(this.grpTreatMaintenance);
            this.Controls.Add(this.grpTreatDetails);
            this.Name = "TreatmentForm";
            this.Text = "Treatment_Maintenance";
            this.grpTreatMaintenance.ResumeLayout(false);
            this.grpTreatDetails.ResumeLayout(false);
            this.grpTreatDetails.PerformLayout();
            this.pnlAddTreat.ResumeLayout(false);
            this.pnlAddTreat.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpTreatMaintenance;
        private System.Windows.Forms.Button btnTreatReturn;
        private System.Windows.Forms.Button btnDeleteTreat;
        private System.Windows.Forms.Button btnPreviousTreat;
        private System.Windows.Forms.Button btnNextTreat;
        private System.Windows.Forms.Button btnModifyTreat;
        private System.Windows.Forms.Button btnAddTreat;
        private System.Windows.Forms.ListBox lstTreatments;
        private System.Windows.Forms.Label lblTreatIdname;
        private System.Windows.Forms.Label lblTreatDescription;
        private System.Windows.Forms.GroupBox grpTreatDetails;
        private System.Windows.Forms.Label lblTreatId;
        private System.Windows.Forms.TextBox tbTreatDesc;
        private System.Windows.Forms.Label lblTreatCost;
        private System.Windows.Forms.Button btnUpdateTreat;
        private System.Windows.Forms.Button btnReturnToTreatF;
        private System.Windows.Forms.Button btnSaveTreat;
        private System.Windows.Forms.Panel pnlAddTreat;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.TextBox tbTreatCost;
        private System.Windows.Forms.TextBox tbTreatAddDescr;
        private System.Windows.Forms.Label lblTreatAddCost;
        private System.Windows.Forms.Label lblTreatAddDescr;
        private System.Windows.Forms.Label lblTreathint;
        private System.Windows.Forms.TextBox tbTreatAddCost;
    }
}