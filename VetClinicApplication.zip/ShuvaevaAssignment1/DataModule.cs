﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data.Common;
namespace ShuvaevaAssignment1
   

{
    public partial class DataModule : Form
    {
        /// <summary>
        /// Static value for cat gender -male
        /// </summary>
        public static readonly string GENDER_MALE = "Male";
        /// <summary>
        /// static value for cat gender -female
        /// </summary>
        public static readonly string GENDER_FEMALE = "Female";

        /// <summary>
        /// static value for visit status - paid
        /// </summary>
        public static readonly string STATUS_PAID = "Paid";
        /// <summary>
        /// static value for visit status -pending
        /// </summary>
        public static readonly string STATUS_PENDING = "Pending";


        /// <summary>
        /// Cat's table
        /// </summary>
        public DataTable _dtCat;
        /// <summary>
        /// Owner's table
        /// </summary>
        public DataTable _dtOwner;
        /// <summary>
        /// Veterinarian's table
        /// </summary>
        public DataTable _dtVeterinarian;
        /// <summary>
        /// Treatment's table
        /// </summary>
        public DataTable _dtTreatment;
        /// <summary>
        /// Visit's table
        /// </summary>
        public DataTable _dtVisit;
        /// <summary>
        /// VisitTreatment''s table
        /// </summary>
        public DataTable _dtVisitTreatment;

        /// <summary>
        /// Cat's dataview
        /// </summary>
        public DataView _catView;
        /// <summary>
        /// Treatment's dataview
        /// </summary>
        public DataView _treatmentView;
        /// <summary>
        /// Owner's dataview
        /// </summary>
        public DataView _ownerView;
        /// <summary>
        /// Veterinarian dataview
        /// </summary>
        public DataView _veterinarianView;
        /// <summary>
        /// Visit's dataview
        /// </summary>
        public DataView _visitView;
        /// <summary>
        /// VisitTreatment's dataview
        /// </summary>
        public DataView _visitTreatmentView;
        
        /// <summary>
        /// DataModul constructor
        /// </summary>
        public DataModule()
        {
            InitializeComponent();
            try
            {
                //Before fiiling data in order to avoid relationship between tables issues, we switch off cotstraints

                datasetGlendene.EnforceConstraints = false;

                //Fill dataset
                daCat.Fill(datasetGlendene);
                daTreatment.Fill(datasetGlendene);
                daOwner.Fill(datasetGlendene);
                daVisit.Fill(datasetGlendene);
                daVeterinarian.Fill(datasetGlendene);
                daVisitTreatment.Fill(datasetGlendene);
                //Our tables
                _dtCat = datasetGlendene.Tables["Cat"];
                _dtTreatment = datasetGlendene.Tables["Treatment"];
                _dtOwner = datasetGlendene.Tables["Owner"];
                _dtVeterinarian = datasetGlendene.Tables["Veterinarian"];
                _dtVisit = datasetGlendene.Tables["Visit"];
                _dtVisitTreatment = datasetGlendene.Tables["VisitTreatment"];
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception: " + ex.ToString());
            }
            
            //Create a data view sorted in key order for the Cat Table
            _catView = new DataView(_dtCat);
            _catView.Sort = "CatID";

            //Create a data view sorted in key order for the Owner Table
            _ownerView = new DataView(_dtOwner);
            _ownerView.Sort = "OwnerID";

            //Create a data view sorted in key order for the Treatment Table
            _treatmentView = new DataView(_dtTreatment);
            _treatmentView.Sort = "TreatmentID";

            //Create a data view sorted in key order for the Veterinarian
            _veterinarianView = new DataView(_dtVeterinarian);
            _veterinarianView.Sort = "VeterinarianID";

            //Switch on constraints
            datasetGlendene.EnforceConstraints = true;
        }

        /// <summary>
        /// Method for updating an owner
        /// </summary>

        public void UpdateOwner()
        {
            daOwner.Update(_dtOwner);
          // Refill dataset in case the user wants to delete a new row straightaway after adding
         //Switch off constraints (just in case)
            datasetGlendene.EnforceConstraints = false;

            datasetGlendene.OWNER.Clear();
            daOwner.Fill(datasetGlendene);
        //Switch on constraints
            datasetGlendene.EnforceConstraints = true;
        }

        /// <summary>
        /// Method for updating a veterinarian
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void UpdateVet()
        {
            daVeterinarian.Update(_dtVeterinarian);

         // Refill dataset in case the user wants to delete a new row straightaway after adding
         //Switch off constraints (just in case)
            datasetGlendene.EnforceConstraints = false;
            datasetGlendene.VETERINARIAN.Clear();
            daVeterinarian.Fill(datasetGlendene);
         //Switch on constraints 
            datasetGlendene.EnforceConstraints = true;
        }

        /// <summary>
        /// Method for updating Cat
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// 
        public void UpdateCat()
        {
            daCat.Update(_dtCat);

        // Refill dataset in case  user wants to delete a new row straightaway after adding
        //Switch off constraints (just in case)
            datasetGlendene.EnforceConstraints = false;
            datasetGlendene.CAT.Clear();
            daCat.Fill(datasetGlendene);
        //Switch on constraints 
            datasetGlendene.EnforceConstraints = true;
        }



        /// <summary>
        /// Method for updating Treatment
        /// </summary>
        public void UpdateTreatment()
        {    
            
            daTreatment.Update(_dtTreatment);
            // Refill dataset in case  user wants to delete a new row straightaway after adding
            //Switch off constraints (just in case)
            datasetGlendene.EnforceConstraints = false;
            
            datasetGlendene.TREATMENT.Clear();
            daTreatment.Fill(datasetGlendene);
            //Switch on constraints
            datasetGlendene.EnforceConstraints = true;


        }


        /// <summary>
        /// Method for updating Visit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// 
        public void UpdateVisit()
        {
            daVisit.Update(_dtVisit);

            // Refill dataset in case  user wants to delete a new row straightaway after adding
            //Switch off constraints (just in case)

            datasetGlendene.EnforceConstraints = false;
            datasetGlendene.VISIT.Clear();
            daVisit.Fill(datasetGlendene);
            
            //Switch on constraints 
            datasetGlendene.EnforceConstraints = true;
        }

        /// <summary>
        /// Method for updating VisitTreatment
        /// </summary>
        public void UpdateVisitTreatment()
        {

            daVisitTreatment.Update(_dtVisitTreatment);
            // Refill dataset in case  user wants to delete a new row straightaway after adding
            //Switch off constraints (just in case)
            datasetGlendene.EnforceConstraints = false;
            datasetGlendene.VISITTREATMENT.Clear();
            daVisitTreatment.Fill(datasetGlendene);
            //Switch on constraints 
            datasetGlendene.EnforceConstraints = true;
        }

        /// <summary>
        /// Method for updating Visit Status
        /// </summary>
        public void UpdateVisitStatus()
        {
            daVisitTreatment.Update(_dtVisitTreatment);
            daVisit.Update(_dtVisit);
            //Switch off constraints (just in case)
            datasetGlendene.EnforceConstraints = false;
            datasetGlendene.VISITTREATMENT.Clear();
            datasetGlendene.VISIT.Clear();

            daVisit.Fill(datasetGlendene);
            daVisitTreatment.Fill(datasetGlendene);
            datasetGlendene.EnforceConstraints = true;
        }



        private void DataModule_Load(object sender, EventArgs e)
        {
        }

        private void oleDbConnection2_InfoMessage(object sender, OleDbInfoMessageEventArgs e)
        {

        }

 
   
    }
}
