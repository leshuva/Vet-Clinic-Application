﻿namespace ShuvaevaAssignment1
{
    partial class CatForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnUpdateCat = new System.Windows.Forms.Button();
            this.btnReturnToCatF = new System.Windows.Forms.Button();
            this.lstCats = new System.Windows.Forms.ListBox();
            this.btnSaveCat = new System.Windows.Forms.Button();
            this.pnlAddCat = new System.Windows.Forms.Panel();
            this.lblCathint = new System.Windows.Forms.Label();
            this.cmbCatAddOwnerId = new System.Windows.Forms.ComboBox();
            this.chxCatAddNeutered = new System.Windows.Forms.CheckBox();
            this.dtpCatAddDateOfBirth = new System.Windows.Forms.DateTimePicker();
            this.cmbAddCatGender = new System.Windows.Forms.ComboBox();
            this.lblAddCatOwner = new System.Windows.Forms.Label();
            this.tbCatAddBreed = new System.Windows.Forms.TextBox();
            this.tbCatAddName = new System.Windows.Forms.TextBox();
            this.lblCatAddNeut = new System.Windows.Forms.Label();
            this.lblCatAddDateOfBirth = new System.Windows.Forms.Label();
            this.lblCatAddGender = new System.Windows.Forms.Label();
            this.lblCatAddBreed = new System.Windows.Forms.Label();
            this.lblAddCatName = new System.Windows.Forms.Label();
            this.lblCatId = new System.Windows.Forms.Label();
            this.lbOwnerIdShow = new System.Windows.Forms.Label();
            this.btnDeleteCat = new System.Windows.Forms.Button();
            this.tbCatBreed = new System.Windows.Forms.TextBox();
            this.tbCatName = new System.Windows.Forms.TextBox();
            this.btnCatReturn = new System.Windows.Forms.Button();
            this.btnNextCat = new System.Windows.Forms.Button();
            this.lblCatName = new System.Windows.Forms.Label();
            this.lblCatBreed = new System.Windows.Forms.Label();
            this.btnPreviousCat = new System.Windows.Forms.Button();
            this.lblCatIdname = new System.Windows.Forms.Label();
            this.grpCatDetails = new System.Windows.Forms.GroupBox();
            this.cmbCatOwner = new System.Windows.Forms.ComboBox();
            this.chbCatNeutered = new System.Windows.Forms.CheckBox();
            this.cmbCatGender = new System.Windows.Forms.ComboBox();
            this.lblCatOwner = new System.Windows.Forms.Label();
            this.tbCatDateOfBirth = new System.Windows.Forms.TextBox();
            this.lblCatNeutered = new System.Windows.Forms.Label();
            this.lblCatDateOfBirth = new System.Windows.Forms.Label();
            this.lblCatGender = new System.Windows.Forms.Label();
            this.grpCatMaintenance = new System.Windows.Forms.GroupBox();
            this.btnModifyCat = new System.Windows.Forms.Button();
            this.btnAddCat = new System.Windows.Forms.Button();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.pnlAddCat.SuspendLayout();
            this.grpCatDetails.SuspendLayout();
            this.grpCatMaintenance.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnUpdateCat
            // 
            this.btnUpdateCat.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnUpdateCat.ForeColor = System.Drawing.Color.Green;
            this.btnUpdateCat.Location = new System.Drawing.Point(232, 223);
            this.btnUpdateCat.Name = "btnUpdateCat";
            this.btnUpdateCat.Size = new System.Drawing.Size(242, 47);
            this.btnUpdateCat.TabIndex = 14;
            this.btnUpdateCat.Text = "Update Cat";
            this.btnUpdateCat.UseVisualStyleBackColor = true;
            this.btnUpdateCat.Click += new System.EventHandler(this.btnUpdateCat_Click);
            // 
            // btnReturnToCatF
            // 
            this.btnReturnToCatF.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnReturnToCatF.Location = new System.Drawing.Point(232, 294);
            this.btnReturnToCatF.Name = "btnReturnToCatF";
            this.btnReturnToCatF.Size = new System.Drawing.Size(242, 47);
            this.btnReturnToCatF.TabIndex = 16;
            this.btnReturnToCatF.Text = "Cancel";
            this.btnReturnToCatF.UseVisualStyleBackColor = true;
            this.btnReturnToCatF.Click += new System.EventHandler(this.btnReturnToCatF_Click);
            // 
            // lstCats
            // 
            this.lstCats.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lstCats.FormattingEnabled = true;
            this.lstCats.ItemHeight = 21;
            this.lstCats.Location = new System.Drawing.Point(23, 46);
            this.lstCats.Name = "lstCats";
            this.lstCats.Size = new System.Drawing.Size(354, 88);
            this.lstCats.TabIndex = 1;
            // 
            // btnSaveCat
            // 
            this.btnSaveCat.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnSaveCat.ForeColor = System.Drawing.Color.DarkGreen;
            this.btnSaveCat.Location = new System.Drawing.Point(232, 222);
            this.btnSaveCat.Name = "btnSaveCat";
            this.btnSaveCat.Size = new System.Drawing.Size(242, 48);
            this.btnSaveCat.TabIndex = 15;
            this.btnSaveCat.Text = "Save Cat";
            this.btnSaveCat.UseVisualStyleBackColor = true;
            this.btnSaveCat.Click += new System.EventHandler(this.btnSaveCat_Click);
            // 
            // pnlAddCat
            // 
            this.pnlAddCat.BackColor = System.Drawing.Color.Silver;
            this.pnlAddCat.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlAddCat.Controls.Add(this.lblCathint);
            this.pnlAddCat.Controls.Add(this.cmbCatAddOwnerId);
            this.pnlAddCat.Controls.Add(this.chxCatAddNeutered);
            this.pnlAddCat.Controls.Add(this.dtpCatAddDateOfBirth);
            this.pnlAddCat.Controls.Add(this.cmbAddCatGender);
            this.pnlAddCat.Controls.Add(this.lblAddCatOwner);
            this.pnlAddCat.Controls.Add(this.btnUpdateCat);
            this.pnlAddCat.Controls.Add(this.btnReturnToCatF);
            this.pnlAddCat.Controls.Add(this.btnSaveCat);
            this.pnlAddCat.Controls.Add(this.tbCatAddBreed);
            this.pnlAddCat.Controls.Add(this.tbCatAddName);
            this.pnlAddCat.Controls.Add(this.lblCatAddNeut);
            this.pnlAddCat.Controls.Add(this.lblCatAddDateOfBirth);
            this.pnlAddCat.Controls.Add(this.lblCatAddGender);
            this.pnlAddCat.Controls.Add(this.lblCatAddBreed);
            this.pnlAddCat.Controls.Add(this.lblAddCatName);
            this.pnlAddCat.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.pnlAddCat.Location = new System.Drawing.Point(211, 14);
            this.pnlAddCat.MaximumSize = new System.Drawing.Size(710, 351);
            this.pnlAddCat.MinimumSize = new System.Drawing.Size(710, 351);
            this.pnlAddCat.Name = "pnlAddCat";
            this.pnlAddCat.Size = new System.Drawing.Size(710, 351);
            this.pnlAddCat.TabIndex = 28;
            // 
            // lblCathint
            // 
            this.lblCathint.AutoSize = true;
            this.lblCathint.Location = new System.Drawing.Point(276, 149);
            this.lblCathint.Name = "lblCathint";
            this.lblCathint.Size = new System.Drawing.Size(163, 19);
            this.lblCathint.TabIndex = 29;
            this.lblCathint.Text = "Tick, if the cat is neutered";
            // 
            // cmbCatAddOwnerId
            // 
            this.cmbCatAddOwnerId.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCatAddOwnerId.FormattingEnabled = true;
            this.cmbCatAddOwnerId.Location = new System.Drawing.Point(232, 175);
            this.cmbCatAddOwnerId.Name = "cmbCatAddOwnerId";
            this.cmbCatAddOwnerId.Size = new System.Drawing.Size(242, 27);
            this.cmbCatAddOwnerId.TabIndex = 13;
            // 
            // chxCatAddNeutered
            // 
            this.chxCatAddNeutered.AutoSize = true;
            this.chxCatAddNeutered.Location = new System.Drawing.Point(232, 149);
            this.chxCatAddNeutered.Name = "chxCatAddNeutered";
            this.chxCatAddNeutered.Size = new System.Drawing.Size(15, 14);
            this.chxCatAddNeutered.TabIndex = 12;
            this.chxCatAddNeutered.UseVisualStyleBackColor = true;
            // 
            // dtpCatAddDateOfBirth
            // 
            this.dtpCatAddDateOfBirth.Location = new System.Drawing.Point(232, 116);
            this.dtpCatAddDateOfBirth.Name = "dtpCatAddDateOfBirth";
            this.dtpCatAddDateOfBirth.Size = new System.Drawing.Size(242, 26);
            this.dtpCatAddDateOfBirth.TabIndex = 11;
            // 
            // cmbAddCatGender
            // 
            this.cmbAddCatGender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAddCatGender.FormattingEnabled = true;
            this.cmbAddCatGender.Location = new System.Drawing.Point(232, 86);
            this.cmbAddCatGender.Name = "cmbAddCatGender";
            this.cmbAddCatGender.Size = new System.Drawing.Size(242, 27);
            this.cmbAddCatGender.TabIndex = 10;
            // 
            // lblAddCatOwner
            // 
            this.lblAddCatOwner.AutoSize = true;
            this.lblAddCatOwner.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblAddCatOwner.Location = new System.Drawing.Point(92, 178);
            this.lblAddCatOwner.Name = "lblAddCatOwner";
            this.lblAddCatOwner.Size = new System.Drawing.Size(50, 17);
            this.lblAddCatOwner.TabIndex = 23;
            this.lblAddCatOwner.Text = "Owner";
            // 
            // tbCatAddBreed
            // 
            this.tbCatAddBreed.Location = new System.Drawing.Point(232, 57);
            this.tbCatAddBreed.MaxLength = 20;
            this.tbCatAddBreed.Name = "tbCatAddBreed";
            this.tbCatAddBreed.Size = new System.Drawing.Size(242, 26);
            this.tbCatAddBreed.TabIndex = 9;
            // 
            // tbCatAddName
            // 
            this.tbCatAddName.Location = new System.Drawing.Point(232, 27);
            this.tbCatAddName.MaxLength = 20;
            this.tbCatAddName.Name = "tbCatAddName";
            this.tbCatAddName.Size = new System.Drawing.Size(242, 26);
            this.tbCatAddName.TabIndex = 8;
            // 
            // lblCatAddNeut
            // 
            this.lblCatAddNeut.AutoSize = true;
            this.lblCatAddNeut.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCatAddNeut.Location = new System.Drawing.Point(92, 149);
            this.lblCatAddNeut.Name = "lblCatAddNeut";
            this.lblCatAddNeut.Size = new System.Drawing.Size(68, 17);
            this.lblCatAddNeut.TabIndex = 4;
            this.lblCatAddNeut.Text = "Neutered";
            // 
            // lblCatAddDateOfBirth
            // 
            this.lblCatAddDateOfBirth.AutoSize = true;
            this.lblCatAddDateOfBirth.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCatAddDateOfBirth.Location = new System.Drawing.Point(91, 120);
            this.lblCatAddDateOfBirth.Name = "lblCatAddDateOfBirth";
            this.lblCatAddDateOfBirth.Size = new System.Drawing.Size(97, 17);
            this.lblCatAddDateOfBirth.TabIndex = 3;
            this.lblCatAddDateOfBirth.Text = "Date Of  Birth";
            // 
            // lblCatAddGender
            // 
            this.lblCatAddGender.AutoSize = true;
            this.lblCatAddGender.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCatAddGender.Location = new System.Drawing.Point(93, 90);
            this.lblCatAddGender.Name = "lblCatAddGender";
            this.lblCatAddGender.Size = new System.Drawing.Size(80, 17);
            this.lblCatAddGender.TabIndex = 2;
            this.lblCatAddGender.Text = "Cat gender";
            // 
            // lblCatAddBreed
            // 
            this.lblCatAddBreed.AutoSize = true;
            this.lblCatAddBreed.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCatAddBreed.Location = new System.Drawing.Point(93, 57);
            this.lblCatAddBreed.Name = "lblCatAddBreed";
            this.lblCatAddBreed.Size = new System.Drawing.Size(72, 17);
            this.lblCatAddBreed.TabIndex = 1;
            this.lblCatAddBreed.Text = "Cat breed";
            // 
            // lblAddCatName
            // 
            this.lblAddCatName.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblAddCatName.Location = new System.Drawing.Point(90, 30);
            this.lblAddCatName.Name = "lblAddCatName";
            this.lblAddCatName.Size = new System.Drawing.Size(101, 17);
            this.lblAddCatName.TabIndex = 0;
            this.lblAddCatName.Text = "Cat name";
            // 
            // lblCatId
            // 
            this.lblCatId.AutoSize = true;
            this.lblCatId.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCatId.Location = new System.Drawing.Point(164, 27);
            this.lblCatId.Name = "lblCatId";
            this.lblCatId.Size = new System.Drawing.Size(29, 23);
            this.lblCatId.TabIndex = 20;
            this.lblCatId.Text = "ID";
            // 
            // lbOwnerIdShow
            // 
            this.lbOwnerIdShow.Location = new System.Drawing.Point(-149, -6);
            this.lbOwnerIdShow.Name = "lbOwnerIdShow";
            this.lbOwnerIdShow.Size = new System.Drawing.Size(100, 23);
            this.lbOwnerIdShow.TabIndex = 27;
            // 
            // btnDeleteCat
            // 
            this.btnDeleteCat.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnDeleteCat.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnDeleteCat.Location = new System.Drawing.Point(8, 414);
            this.btnDeleteCat.Name = "btnDeleteCat";
            this.btnDeleteCat.Size = new System.Drawing.Size(354, 49);
            this.btnDeleteCat.TabIndex = 7;
            this.btnDeleteCat.Text = "Delete Cat";
            this.btnDeleteCat.UseVisualStyleBackColor = true;
            this.btnDeleteCat.Click += new System.EventHandler(this.btnDeleteCat_Click);
            // 
            // tbCatBreed
            // 
            this.tbCatBreed.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tbCatBreed.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbCatBreed.Location = new System.Drawing.Point(168, 120);
            this.tbCatBreed.Name = "tbCatBreed";
            this.tbCatBreed.ReadOnly = true;
            this.tbCatBreed.Size = new System.Drawing.Size(173, 29);
            this.tbCatBreed.TabIndex = 5;
            // 
            // tbCatName
            // 
            this.tbCatName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tbCatName.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbCatName.Location = new System.Drawing.Point(168, 77);
            this.tbCatName.Name = "tbCatName";
            this.tbCatName.ReadOnly = true;
            this.tbCatName.Size = new System.Drawing.Size(173, 29);
            this.tbCatName.TabIndex = 1;
            // 
            // btnCatReturn
            // 
            this.btnCatReturn.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCatReturn.Location = new System.Drawing.Point(8, 331);
            this.btnCatReturn.Name = "btnCatReturn";
            this.btnCatReturn.Size = new System.Drawing.Size(354, 50);
            this.btnCatReturn.TabIndex = 6;
            this.btnCatReturn.Text = "Return to Main Menu";
            this.btnCatReturn.UseVisualStyleBackColor = true;
            this.btnCatReturn.Click += new System.EventHandler(this.btnCatReturn_Click);
            // 
            // btnNextCat
            // 
            this.btnNextCat.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnNextCat.Location = new System.Drawing.Point(199, 153);
            this.btnNextCat.Name = "btnNextCat";
            this.btnNextCat.Size = new System.Drawing.Size(178, 37);
            this.btnNextCat.TabIndex = 3;
            this.btnNextCat.Text = "Next Cat";
            this.btnNextCat.UseVisualStyleBackColor = true;
            this.btnNextCat.Click += new System.EventHandler(this.btnNextCat_Click);
            // 
            // lblCatName
            // 
            this.lblCatName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblCatName.BackColor = System.Drawing.SystemColors.Control;
            this.lblCatName.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCatName.ForeColor = System.Drawing.Color.Black;
            this.lblCatName.Location = new System.Drawing.Point(25, 77);
            this.lblCatName.Name = "lblCatName";
            this.lblCatName.Size = new System.Drawing.Size(106, 23);
            this.lblCatName.TabIndex = 0;
            this.lblCatName.Text = "Cat Name";
            // 
            // lblCatBreed
            // 
            this.lblCatBreed.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblCatBreed.BackColor = System.Drawing.SystemColors.Control;
            this.lblCatBreed.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCatBreed.ForeColor = System.Drawing.Color.Black;
            this.lblCatBreed.Location = new System.Drawing.Point(25, 118);
            this.lblCatBreed.Name = "lblCatBreed";
            this.lblCatBreed.Size = new System.Drawing.Size(118, 22);
            this.lblCatBreed.TabIndex = 2;
            this.lblCatBreed.Text = "Breed";
            // 
            // btnPreviousCat
            // 
            this.btnPreviousCat.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnPreviousCat.Location = new System.Drawing.Point(17, 153);
            this.btnPreviousCat.Name = "btnPreviousCat";
            this.btnPreviousCat.Size = new System.Drawing.Size(176, 37);
            this.btnPreviousCat.TabIndex = 2;
            this.btnPreviousCat.Text = "Previous Cat";
            this.btnPreviousCat.UseVisualStyleBackColor = true;
            this.btnPreviousCat.Click += new System.EventHandler(this.btnPreviousCat_Click);
            // 
            // lblCatIdname
            // 
            this.lblCatIdname.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblCatIdname.BackColor = System.Drawing.SystemColors.Control;
            this.lblCatIdname.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCatIdname.ForeColor = System.Drawing.Color.Black;
            this.lblCatIdname.Location = new System.Drawing.Point(25, 27);
            this.lblCatIdname.Name = "lblCatIdname";
            this.lblCatIdname.Size = new System.Drawing.Size(106, 23);
            this.lblCatIdname.TabIndex = 21;
            this.lblCatIdname.Text = "Cat ID";
            // 
            // grpCatDetails
            // 
            this.grpCatDetails.Controls.Add(this.cmbCatOwner);
            this.grpCatDetails.Controls.Add(this.chbCatNeutered);
            this.grpCatDetails.Controls.Add(this.cmbCatGender);
            this.grpCatDetails.Controls.Add(this.lblCatOwner);
            this.grpCatDetails.Controls.Add(this.lblCatIdname);
            this.grpCatDetails.Controls.Add(this.lblCatId);
            this.grpCatDetails.Controls.Add(this.tbCatDateOfBirth);
            this.grpCatDetails.Controls.Add(this.lblCatNeutered);
            this.grpCatDetails.Controls.Add(this.lblCatDateOfBirth);
            this.grpCatDetails.Controls.Add(this.tbCatBreed);
            this.grpCatDetails.Controls.Add(this.lblCatGender);
            this.grpCatDetails.Controls.Add(this.tbCatName);
            this.grpCatDetails.Controls.Add(this.lblCatName);
            this.grpCatDetails.Controls.Add(this.lblCatBreed);
            this.grpCatDetails.Location = new System.Drawing.Point(468, 28);
            this.grpCatDetails.Name = "grpCatDetails";
            this.grpCatDetails.Size = new System.Drawing.Size(372, 504);
            this.grpCatDetails.TabIndex = 30;
            this.grpCatDetails.TabStop = false;
            // 
            // cmbCatOwner
            // 
            this.cmbCatOwner.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCatOwner.Enabled = false;
            this.cmbCatOwner.FormattingEnabled = true;
            this.cmbCatOwner.Location = new System.Drawing.Point(168, 314);
            this.cmbCatOwner.Name = "cmbCatOwner";
            this.cmbCatOwner.Size = new System.Drawing.Size(173, 21);
            this.cmbCatOwner.TabIndex = 26;
            // 
            // chbCatNeutered
            // 
            this.chbCatNeutered.AutoSize = true;
            this.chbCatNeutered.Enabled = false;
            this.chbCatNeutered.Location = new System.Drawing.Point(168, 265);
            this.chbCatNeutered.Name = "chbCatNeutered";
            this.chbCatNeutered.Size = new System.Drawing.Size(15, 14);
            this.chbCatNeutered.TabIndex = 25;
            this.chbCatNeutered.UseVisualStyleBackColor = true;
            // 
            // cmbCatGender
            // 
            this.cmbCatGender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCatGender.Enabled = false;
            this.cmbCatGender.FormattingEnabled = true;
            this.cmbCatGender.Location = new System.Drawing.Point(168, 165);
            this.cmbCatGender.Name = "cmbCatGender";
            this.cmbCatGender.Size = new System.Drawing.Size(173, 21);
            this.cmbCatGender.TabIndex = 24;
            // 
            // lblCatOwner
            // 
            this.lblCatOwner.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblCatOwner.BackColor = System.Drawing.SystemColors.Control;
            this.lblCatOwner.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCatOwner.ForeColor = System.Drawing.Color.Black;
            this.lblCatOwner.Location = new System.Drawing.Point(31, 314);
            this.lblCatOwner.Name = "lblCatOwner";
            this.lblCatOwner.Size = new System.Drawing.Size(106, 23);
            this.lblCatOwner.TabIndex = 22;
            this.lblCatOwner.Text = "Owner";
            // 
            // tbCatDateOfBirth
            // 
            this.tbCatDateOfBirth.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tbCatDateOfBirth.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbCatDateOfBirth.Location = new System.Drawing.Point(168, 205);
            this.tbCatDateOfBirth.Name = "tbCatDateOfBirth";
            this.tbCatDateOfBirth.ReadOnly = true;
            this.tbCatDateOfBirth.Size = new System.Drawing.Size(173, 29);
            this.tbCatDateOfBirth.TabIndex = 9;
            // 
            // lblCatNeutered
            // 
            this.lblCatNeutered.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblCatNeutered.BackColor = System.Drawing.SystemColors.Control;
            this.lblCatNeutered.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCatNeutered.ForeColor = System.Drawing.Color.Black;
            this.lblCatNeutered.Location = new System.Drawing.Point(25, 260);
            this.lblCatNeutered.Name = "lblCatNeutered";
            this.lblCatNeutered.Size = new System.Drawing.Size(100, 20);
            this.lblCatNeutered.TabIndex = 11;
            this.lblCatNeutered.Text = "Neutered";
            // 
            // lblCatDateOfBirth
            // 
            this.lblCatDateOfBirth.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblCatDateOfBirth.BackColor = System.Drawing.SystemColors.Control;
            this.lblCatDateOfBirth.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCatDateOfBirth.ForeColor = System.Drawing.Color.Black;
            this.lblCatDateOfBirth.Location = new System.Drawing.Point(25, 206);
            this.lblCatDateOfBirth.Name = "lblCatDateOfBirth";
            this.lblCatDateOfBirth.Size = new System.Drawing.Size(137, 27);
            this.lblCatDateOfBirth.TabIndex = 8;
            this.lblCatDateOfBirth.Text = "Date Of Birth";
            // 
            // lblCatGender
            // 
            this.lblCatGender.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblCatGender.BackColor = System.Drawing.SystemColors.Control;
            this.lblCatGender.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCatGender.ForeColor = System.Drawing.Color.Black;
            this.lblCatGender.Location = new System.Drawing.Point(25, 165);
            this.lblCatGender.Name = "lblCatGender";
            this.lblCatGender.Size = new System.Drawing.Size(110, 28);
            this.lblCatGender.TabIndex = 7;
            this.lblCatGender.Text = "Cat Gender";
            // 
            // grpCatMaintenance
            // 
            this.grpCatMaintenance.Controls.Add(this.btnCatReturn);
            this.grpCatMaintenance.Controls.Add(this.btnDeleteCat);
            this.grpCatMaintenance.Controls.Add(this.btnPreviousCat);
            this.grpCatMaintenance.Controls.Add(this.btnNextCat);
            this.grpCatMaintenance.Controls.Add(this.btnModifyCat);
            this.grpCatMaintenance.Controls.Add(this.btnAddCat);
            this.grpCatMaintenance.Controls.Add(this.lstCats);
            this.grpCatMaintenance.Font = new System.Drawing.Font("Vivaldi", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpCatMaintenance.Location = new System.Drawing.Point(12, 20);
            this.grpCatMaintenance.Name = "grpCatMaintenance";
            this.grpCatMaintenance.Size = new System.Drawing.Size(401, 478);
            this.grpCatMaintenance.TabIndex = 29;
            this.grpCatMaintenance.TabStop = false;
            this.grpCatMaintenance.Text = "Cat Maintenance";
            // 
            // btnModifyCat
            // 
            this.btnModifyCat.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnModifyCat.Location = new System.Drawing.Point(8, 260);
            this.btnModifyCat.Name = "btnModifyCat";
            this.btnModifyCat.Size = new System.Drawing.Size(354, 42);
            this.btnModifyCat.TabIndex = 5;
            this.btnModifyCat.Text = "Modify Cat";
            this.btnModifyCat.UseVisualStyleBackColor = true;
            this.btnModifyCat.Click += new System.EventHandler(this.btnModifyCat_Click);
            // 
            // btnAddCat
            // 
            this.btnAddCat.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnAddCat.ForeColor = System.Drawing.Color.Green;
            this.btnAddCat.Location = new System.Drawing.Point(8, 206);
            this.btnAddCat.Name = "btnAddCat";
            this.btnAddCat.Size = new System.Drawing.Size(354, 41);
            this.btnAddCat.TabIndex = 4;
            this.btnAddCat.Text = "Add Cat";
            this.btnAddCat.UseVisualStyleBackColor = true;
            this.btnAddCat.Click += new System.EventHandler(this.btnAddCat_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // CatForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1024, 553);
            this.Controls.Add(this.pnlAddCat);
            this.Controls.Add(this.lbOwnerIdShow);
            this.Controls.Add(this.grpCatDetails);
            this.Controls.Add(this.grpCatMaintenance);
            this.Name = "CatForm";
            this.Text = "Cat_Maintenance";
            this.pnlAddCat.ResumeLayout(false);
            this.pnlAddCat.PerformLayout();
            this.grpCatDetails.ResumeLayout(false);
            this.grpCatDetails.PerformLayout();
            this.grpCatMaintenance.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnUpdateCat;
        private System.Windows.Forms.Button btnReturnToCatF;
        private System.Windows.Forms.ListBox lstCats;
        private System.Windows.Forms.Button btnSaveCat;
        private System.Windows.Forms.Panel pnlAddCat;
        private System.Windows.Forms.TextBox tbCatAddBreed;
        private System.Windows.Forms.Label lblCatAddNeut;
        private System.Windows.Forms.Label lblCatAddDateOfBirth;
        private System.Windows.Forms.Label lblCatAddGender;
        private System.Windows.Forms.Label lblCatAddBreed;
        private System.Windows.Forms.Label lblAddCatName;
        private System.Windows.Forms.Label lblCatId;
        private System.Windows.Forms.Label lbOwnerIdShow;
        private System.Windows.Forms.Button btnDeleteCat;
        private System.Windows.Forms.TextBox tbCatBreed;
        private System.Windows.Forms.TextBox tbCatName;
        private System.Windows.Forms.Button btnCatReturn;
        private System.Windows.Forms.Button btnNextCat;
        private System.Windows.Forms.Label lblCatName;
        private System.Windows.Forms.Label lblCatBreed;
        private System.Windows.Forms.Button btnPreviousCat;
        private System.Windows.Forms.Label lblCatIdname;
        private System.Windows.Forms.GroupBox grpCatDetails;
        private System.Windows.Forms.TextBox tbCatDateOfBirth;
        private System.Windows.Forms.Label lblCatNeutered;
        private System.Windows.Forms.Label lblCatDateOfBirth;
        private System.Windows.Forms.Label lblCatGender;
        private System.Windows.Forms.GroupBox grpCatMaintenance;
        private System.Windows.Forms.Button btnModifyCat;
        private System.Windows.Forms.Button btnAddCat;
        private System.Windows.Forms.Label lblCatOwner;
        private System.Windows.Forms.Label lblAddCatOwner;
        private System.Windows.Forms.ComboBox cmbCatAddOwnerId;
        private System.Windows.Forms.CheckBox chxCatAddNeutered;
        private System.Windows.Forms.DateTimePicker dtpCatAddDateOfBirth;
        private System.Windows.Forms.ComboBox cmbAddCatGender;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ComboBox cmbCatGender;
        private System.Windows.Forms.CheckBox chbCatNeutered;
        private System.Windows.Forms.ComboBox cmbCatOwner;
        private System.Windows.Forms.Label lblCathint;
        private System.Windows.Forms.TextBox tbCatAddName;
    }
}