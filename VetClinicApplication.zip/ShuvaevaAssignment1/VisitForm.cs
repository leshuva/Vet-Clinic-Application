﻿
/*
 * Description: Visit maintenance form. Allows to read, add, modify ,delete visits.
 * Author: Elena Shuvaeva
 * Date: 26.08.2014
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ShuvaevaAssignment1
{
    public partial class VisitForm : Form
    {

        /// <summary>
        ///  Declare a shared data source (add references to DataModul ,MainMenu and CurrencyManager objects)
        /// </summary>

        private DataModule _dm;
        private MainMenu _mmenu;
        private CurrencyManager _currencyManager;
    

        /// <summary>
        /// Changing the constructor to accept Datamodul and Main menu references
        /// </summary>
        /// <param name="dm"></param>
        /// <param name="mmenu"></param>
        public VisitForm(DataModule dm, MainMenu mmenu)
        {
            // Create and set values for the controls
            InitializeComponent();

            //Store the location of the data modul
            _dm = dm;

            // Store the location of the menu form
            _mmenu = mmenu;

            //Run the code for binding the controls on the form
            BindControls();

            //Adding panel hidden
            pnlAddVisit.Enabled = false;
            pnlAddVisit.Visible = false;

        }

        /// <summary>
        /// Binds controls to the data source (bind the data to listbox,textboxes and comboboxes)
        /// </summary>

        public void BindControls()
        {

            lstVisits.DataSource = _dm.datasetGlendene.VISIT;
            lstVisits.DisplayMember = "VisitID";
            lstVisits.ValueMember = "VisitId";

            lblVisitId.DataBindings.Add("Text", _dm.datasetGlendene, "VISIT.VisitID");
            tbVisitCatName.DataBindings.Add("Text", _dm.datasetGlendene, "VISIT.Name");
            tbVisitOwnerName.DataBindings.Add("Text", _dm.datasetGlendene, "VISIT.OwnerDetails");
            tbVisitVetName.DataBindings.Add("Text", _dm.datasetGlendene, "VISIT.VeterinarianDetails");
            tbVisitDate.DataBindings.Add("Text", _dm.datasetGlendene, "VISIT.VisitDate");
            tbVisitStatus.DataBindings.Add("Text", _dm.datasetGlendene, "VISIT.Status");

            cmbVisitAddCatName.DataSource = _dm.datasetGlendene.CAT;
            cmbVisitAddCatName.DisplayMember = "Name";
            cmbVisitAddCatName.ValueMember = "CatID";

            cmbVisitAddVetName.DataSource = _dm.datasetGlendene.VETERINARIAN;
            cmbVisitAddVetName.DisplayMember = "Details";
            cmbVisitAddVetName.ValueMember = "VeterinarianID";

            _currencyManager = (CurrencyManager)this.BindingContext[_dm.datasetGlendene, "VISIT"];
            lstVisits.SelectedIndexChanged += new EventHandler(VisitsIndexChanged);

            cmbVisitAddStatus.Items.Add(DataModule.STATUS_PENDING);
            cmbVisitAddStatus.SelectedItem = DataModule.STATUS_PENDING;


        }

        /// <summary>
        /// Event handler for  navigating between visits in the listbox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void VisitsIndexChanged(object sender, EventArgs e)
        {
            if (lstVisits.SelectedIndex >= 0 && lstVisits.SelectedIndex < _currencyManager.Count)
            {
                _currencyManager.Position = lstVisits.SelectedIndex;

            }
        }


        /// <summary>
        /// Event Handler for 'Previous Visit' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void btnPreviousVisit_Click(object sender, EventArgs e)
        {
            if (lstVisits.SelectedIndex > 0)
            {
                --_currencyManager.Position;
                lstVisits.SelectedIndex = _currencyManager.Position;
            }
        }

        /// <summary>
        /// Event Handler for 'Next Visit' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void btnNextVisit_Click(object sender, EventArgs e)
        {
            if (lstVisits.SelectedIndex < _currencyManager.Count-1)
            {
                ++_currencyManager.Position;
                lstVisits.SelectedIndex = _currencyManager.Position;
            }

        }

        /// <summary>
        /// Event Handler for 'Add  Visit' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAddVisit_Click(object sender, EventArgs e)

        {
            
            cmbVisitAddCatName.Enabled = true;
            cmbVisitAddCatName.SelectedItem = null;
            cmbVisitAddVetName.SelectedItem = null;

           // unable Delete, Update and Modify Visit buttons

            btnDeleteVisit.Enabled = false;
            btnModifyVisit.Enabled = false;

            btnUpdateVisit.Enabled = false;
            btnUpdateVisit.Visible = false;


            // AddCat Panel and 'Save Cat' button are visible and enabled
            pnlAddVisit.Visible = true;
            pnlAddVisit.Enabled = true;
            btnSaveVisit.Enabled = true;
            btnSaveVisit.Visible = true;

            //Hints for the user
            lblVisithint1.Enabled = true;
            lblVisithint1.Visible = true;
            lblVisithint2.Enabled = true;
            lblVisithint2.Visible = true;
            lblVisithint3.Enabled = true;
            lblVisithint3.Visible = true;
            lblVisithint4.Enabled = true;
            lblVisithint4.Visible = true;
        }


        /// <summary>
        /// Event Handler for 'Save Visit' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSaveVisit_Click(object sender, EventArgs e)
        {
            DataRow newVisitRow = _dm._dtVisit.NewRow();

            if (cmbVisitAddCatName.SelectedItem == null || cmbVisitAddVetName == null)
            {
                MessageBox.Show("You must choose a value for each of the fields","Error");
                return;
            }
            else
            {
                newVisitRow["CatID"] = cmbVisitAddCatName.SelectedValue;
                newVisitRow["VeterinarianID"] = cmbVisitAddVetName.SelectedValue;
                newVisitRow["VisitDate"] = dtpVisitAddDate.Value;
                newVisitRow["Status"] = cmbVisitAddStatus.SelectedItem;

                //Add the new row to the Table
                _dm._dtVisit.Rows.Add(newVisitRow);
                _dm.UpdateVisit();

                //Give the user a success message
                MessageBox.Show("Visit added successfully","Success");


                // Going back to the form- closing the panel

                pnlAddVisit.Visible = false;
                pnlAddVisit.Enabled = false;
                btnDeleteVisit.Enabled = true;
                btnModifyVisit.Enabled = true;
                btnAddVisit.Enabled = true;
                btnUpdateVisit.Enabled = true;
                btnUpdateVisit.Visible = true;

            }

        }

        /// <summary>
        /// Event Handler for 'Cancel' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void btnReturnToVisitF_Click(object sender, EventArgs e)
        {
            pnlAddVisit.Enabled = false;
            pnlAddVisit.Visible = false;
            btnModifyVisit.Enabled = true;
            btnDeleteVisit.Enabled = true;
            btnAddVisit.Enabled = true;

        }

        /// <summary>
        /// Event Handler for 'Modify visit' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnModifyVisit_Click(object sender, EventArgs e)
        {
            string currentStatus = _dm.datasetGlendene.VISIT.Rows[_currencyManager.Position]["Status"].ToString();
            if (currentStatus == DataModule.STATUS_PAID)
            {
                MessageBox.Show("Cannot update a paid visit","Error");
                return;
            }
            else
            {
                //Add visit button enable
                btnAddVisit.Enabled = false;
                btnDeleteVisit.Enabled = false;
                //panel is shown
                pnlAddVisit.Enabled = true;
                pnlAddVisit.Visible = true;

                //Save button is hidden
                btnSaveVisit.Enabled = false;
                btnSaveVisit.Visible = false;
                //Update button is shown
                btnUpdateVisit.Enabled = true;
                btnUpdateVisit.Visible = true;

                //hints for the user shown which is needed
                lblVisithint1.Enabled = false;
                lblVisithint1.Visible = false;
                lblVisithint2.Enabled = true;
                lblVisithint2.Visible = true;
                lblVisithint3.Enabled = true;
                lblVisithint3.Visible = true;
                lblVisithint4.Enabled = false;
                lblVisithint4.Visible = false;

                //making combobox with Catname and Visit status read only
                cmbVisitAddCatName.Enabled = false;
                cmbVisitAddStatus.Enabled = false;

                //Show values  in comboboxes
                cmbVisitAddVetName.SelectedValue = _dm.datasetGlendene.VISIT.Rows[_currencyManager.Position]["VeterinarianID"];
                cmbVisitAddCatName.SelectedValue = _dm.datasetGlendene.VISIT.Rows[_currencyManager.Position]["CatID"];
            }

        }


        /// <summary>
        /// Event Handler for 'Update Visit' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnUpdateVisit_Click(object sender, EventArgs e)
        {
            // the row of the chosen visit
            DataRow updateVisitRow = _dm._dtVisit.Rows[_currencyManager.Position];
        
            //Don't allow the user to skip fields
                if (cmbVisitAddVetName.SelectedItem == null)
                {
                    MessageBox.Show("You must enter a value for each of the text fields","Error");
                    return;
                }

                else
                {

                    updateVisitRow["VeterinarianID"] = cmbVisitAddVetName.SelectedValue;
                    updateVisitRow["VisitDate"] = dtpVisitAddDate.Value;
                    _currencyManager.EndCurrentEdit();
                    _dm.UpdateVisit();

                    //Give the user a success message
                    MessageBox.Show("Visit updated successfully","Success");
                }


        }

        /// <summary>
        /// Event Handler for 'Mark Visit as paid' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void btnMarkVisitAsPaid_Click(object sender, EventArgs e)
        {

            string currentStatus = _dm.datasetGlendene.VISIT.Rows[_currencyManager.Position]["Status"].ToString();

            //compaire with the value of the status we declared in the DatamodulForm
            if (currentStatus == DataModule.STATUS_PAID)
            {
                MessageBox.Show("The visit is already marked as paid", "Error");
                return;
            }

            else
            {
                //the row we want to update

             DataRow updateVisitRow = _dm._dtVisit.Rows[_currencyManager.Position];

                //change the status
             updateVisitRow["Status"] = DataModule.STATUS_PAID;

                // delete all treatments assigned to this visit 
                for (int i = 0; i < _dm.datasetGlendene.VISITTREATMENT.Rows.Count; i++)
                {

                    DataRow row = _dm.datasetGlendene.VISITTREATMENT.Rows[i];

                    if (row["VisitID"].ToString() == _dm._dtVisit.Rows[_currencyManager.Position]["VisitID"].ToString())
                    {
                        row.Delete();
                    }
                }
               

                _currencyManager.EndCurrentEdit();

                _dm.UpdateVisitStatus();
                
                //Give the user a success message
                MessageBox.Show("Status updated successfully","Success");
            }
        

             }



        /// <summary>
        /// Event Handler for 'Delete Visit' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDeleteVisit_Click(object sender, EventArgs e)
        {
            DataRow DeleteVisitRow = _dm._dtVisit.Rows[_currencyManager.Position];
            string currentStatus = _dm.datasetGlendene.VISIT.Rows[_currencyManager.Position]["Status"].ToString();
            if (currentStatus == DataModule.STATUS_PAID)
            {
                if (
                    MessageBox.Show("Are you sure you want to delete this record?", "Warning!",
                                     MessageBoxButtons.OKCancel) == DialogResult.OK)
                {
                    DeleteVisitRow.Delete();
                    _dm.UpdateVisit();
                }
            }
            else
            {
                MessageBox.Show("You may only delete paid visits","Error");
            }

        }


        /// <summary>
        /// Event Handler for 'Go back to MainMenu' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void btnVisitReturn_Click(object sender, EventArgs e)
        {
            Close();
        }


        




















        
    }
}
