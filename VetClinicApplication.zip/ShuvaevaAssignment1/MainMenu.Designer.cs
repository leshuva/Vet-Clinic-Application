﻿namespace ShuvaevaAssignment1
{
    partial class MainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpMaintenance = new System.Windows.Forms.GroupBox();
            this.btnTreatVisitAllocation = new System.Windows.Forms.Button();
            this.btnCatMaintenance = new System.Windows.Forms.Button();
            this.btnOwnMaintenance = new System.Windows.Forms.Button();
            this.btnVetMaintenance = new System.Windows.Forms.Button();
            this.btnTreatMaintetance = new System.Windows.Forms.Button();
            this.btnVisitMaintenance = new System.Windows.Forms.Button();
            this.grpReports = new System.Windows.Forms.GroupBox();
            this.btnInvoices = new System.Windows.Forms.Button();
            this.grpMainPicture = new System.Windows.Forms.GroupBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.pdInvoices = new System.Drawing.Printing.PrintDocument();
            this.grpMaintenance.SuspendLayout();
            this.grpReports.SuspendLayout();
            this.grpMainPicture.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpMaintenance
            // 
            this.grpMaintenance.BackColor = System.Drawing.SystemColors.ControlDark;
            this.grpMaintenance.Controls.Add(this.btnTreatVisitAllocation);
            this.grpMaintenance.Controls.Add(this.btnCatMaintenance);
            this.grpMaintenance.Controls.Add(this.btnOwnMaintenance);
            this.grpMaintenance.Controls.Add(this.btnVetMaintenance);
            this.grpMaintenance.Controls.Add(this.btnTreatMaintetance);
            this.grpMaintenance.Controls.Add(this.btnVisitMaintenance);
            this.grpMaintenance.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.grpMaintenance.Font = new System.Drawing.Font("Vivaldi", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpMaintenance.ForeColor = System.Drawing.Color.Red;
            this.grpMaintenance.Location = new System.Drawing.Point(32, 12);
            this.grpMaintenance.Name = "grpMaintenance";
            this.grpMaintenance.Size = new System.Drawing.Size(378, 461);
            this.grpMaintenance.TabIndex = 0;
            this.grpMaintenance.TabStop = false;
            this.grpMaintenance.Text = "Maintenance";
            // 
            // btnTreatVisitAllocation
            // 
            this.btnTreatVisitAllocation.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnTreatVisitAllocation.Location = new System.Drawing.Point(40, 385);
            this.btnTreatVisitAllocation.Name = "btnTreatVisitAllocation";
            this.btnTreatVisitAllocation.Size = new System.Drawing.Size(253, 61);
            this.btnTreatVisitAllocation.TabIndex = 5;
            this.btnTreatVisitAllocation.Text = "Treatment to Visit Allocation ";
            this.btnTreatVisitAllocation.UseVisualStyleBackColor = true;
            this.btnTreatVisitAllocation.Click += new System.EventHandler(this.btnTreatVisitAllocation_Click);
            // 
            // btnCatMaintenance
            // 
            this.btnCatMaintenance.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCatMaintenance.Location = new System.Drawing.Point(40, 194);
            this.btnCatMaintenance.Name = "btnCatMaintenance";
            this.btnCatMaintenance.Size = new System.Drawing.Size(253, 60);
            this.btnCatMaintenance.TabIndex = 2;
            this.btnCatMaintenance.Text = "Cat maintenance";
            this.btnCatMaintenance.UseVisualStyleBackColor = true;
            this.btnCatMaintenance.Click += new System.EventHandler(this.btnCatMaintenance_Click);
            // 
            // btnOwnMaintenance
            // 
            this.btnOwnMaintenance.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOwnMaintenance.Location = new System.Drawing.Point(40, 67);
            this.btnOwnMaintenance.Name = "btnOwnMaintenance";
            this.btnOwnMaintenance.Size = new System.Drawing.Size(253, 60);
            this.btnOwnMaintenance.TabIndex = 0;
            this.btnOwnMaintenance.Text = "Owner Maintenance";
            this.btnOwnMaintenance.UseVisualStyleBackColor = true;
            this.btnOwnMaintenance.Click += new System.EventHandler(this.btnOwnMaintenance_Click);
            // 
            // btnVetMaintenance
            // 
            this.btnVetMaintenance.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVetMaintenance.Location = new System.Drawing.Point(40, 131);
            this.btnVetMaintenance.Name = "btnVetMaintenance";
            this.btnVetMaintenance.Size = new System.Drawing.Size(253, 60);
            this.btnVetMaintenance.TabIndex = 1;
            this.btnVetMaintenance.Text = "Veterinarian maintenance";
            this.btnVetMaintenance.UseVisualStyleBackColor = true;
            this.btnVetMaintenance.Click += new System.EventHandler(this.btnVetMaintenance_Click);
            // 
            // btnTreatMaintetance
            // 
            this.btnTreatMaintetance.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTreatMaintetance.Location = new System.Drawing.Point(40, 257);
            this.btnTreatMaintetance.Name = "btnTreatMaintetance";
            this.btnTreatMaintetance.Size = new System.Drawing.Size(253, 60);
            this.btnTreatMaintetance.TabIndex = 3;
            this.btnTreatMaintetance.Text = "Treatment maintenance ";
            this.btnTreatMaintetance.UseVisualStyleBackColor = true;
            this.btnTreatMaintetance.Click += new System.EventHandler(this.btnTreatMaintetance_Click);
            // 
            // btnVisitMaintenance
            // 
            this.btnVisitMaintenance.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVisitMaintenance.Location = new System.Drawing.Point(40, 319);
            this.btnVisitMaintenance.Name = "btnVisitMaintenance";
            this.btnVisitMaintenance.Size = new System.Drawing.Size(253, 60);
            this.btnVisitMaintenance.TabIndex = 4;
            this.btnVisitMaintenance.Text = "Visit maintenance ";
            this.btnVisitMaintenance.UseVisualStyleBackColor = true;
            this.btnVisitMaintenance.Click += new System.EventHandler(this.btnVisitMaintenance_Click);
            // 
            // grpReports
            // 
            this.grpReports.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.grpReports.BackColor = System.Drawing.SystemColors.ControlDark;
            this.grpReports.Controls.Add(this.btnInvoices);
            this.grpReports.Font = new System.Drawing.Font("Vivaldi", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpReports.Location = new System.Drawing.Point(445, 12);
            this.grpReports.Name = "grpReports";
            this.grpReports.Size = new System.Drawing.Size(389, 127);
            this.grpReports.TabIndex = 1;
            this.grpReports.TabStop = false;
            this.grpReports.Text = "Reporting";
            // 
            // btnInvoices
            // 
            this.btnInvoices.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnInvoices.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnInvoices.Location = new System.Drawing.Point(57, 47);
            this.btnInvoices.Name = "btnInvoices";
            this.btnInvoices.Size = new System.Drawing.Size(278, 41);
            this.btnInvoices.TabIndex = 6;
            this.btnInvoices.Text = "Invoices";
            this.btnInvoices.UseVisualStyleBackColor = true;
            this.btnInvoices.Click += new System.EventHandler(this.btnInvoices_Click);
            // 
            // grpMainPicture
            // 
            this.grpMainPicture.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.grpMainPicture.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.grpMainPicture.BackgroundImage = global::ShuvaevaAssignment1.Properties.Resources.cat1;
            this.grpMainPicture.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.grpMainPicture.Controls.Add(this.btnExit);
            this.grpMainPicture.Location = new System.Drawing.Point(445, 136);
            this.grpMainPicture.Name = "grpMainPicture";
            this.grpMainPicture.Size = new System.Drawing.Size(389, 337);
            this.grpMainPicture.TabIndex = 8;
            this.grpMainPicture.TabStop = false;
            // 
            // btnExit
            // 
            this.btnExit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExit.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnExit.Location = new System.Drawing.Point(43, 283);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(301, 41);
            this.btnExit.TabIndex = 7;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // pdInvoices
            // 
            this.pdInvoices.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.PrintDoc);
            // 
            // MainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(885, 535);
            this.Controls.Add(this.grpReports);
            this.Controls.Add(this.grpMaintenance);
            this.Controls.Add(this.grpMainPicture);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(901, 573);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(901, 573);
            this.Name = "MainMenu";
            this.Text = "Main Menu";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.grpMaintenance.ResumeLayout(false);
            this.grpReports.ResumeLayout(false);
            this.grpMainPicture.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpMaintenance;
        private System.Windows.Forms.GroupBox grpReports;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnInvoices;
        private System.Windows.Forms.Button btnOwnMaintenance;
        private System.Windows.Forms.Button btnTreatMaintetance;
        private System.Windows.Forms.Button btnCatMaintenance;
        private System.Windows.Forms.Button btnVetMaintenance;
        private System.Windows.Forms.Button btnTreatVisitAllocation;
        private System.Windows.Forms.Button btnVisitMaintenance;
        private System.Windows.Forms.GroupBox grpMainPicture;
        private System.Drawing.Printing.PrintDocument pdInvoices;
    }
}

