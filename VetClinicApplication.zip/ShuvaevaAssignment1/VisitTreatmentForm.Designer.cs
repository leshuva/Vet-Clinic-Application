﻿namespace ShuvaevaAssignment1
{
    partial class VisitTreatmentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnVisitTreatPreviousVisit = new System.Windows.Forms.Button();
            this.btnVisitTreatNextVisit = new System.Windows.Forms.Button();
            this.lstVisitTreatVisitsId = new System.Windows.Forms.ListBox();
            this.btnVisitTreatRemoveTreat = new System.Windows.Forms.Button();
            this.btnVisitTreatReturn = new System.Windows.Forms.Button();
            this.btnVisitTreatModifyTreat = new System.Windows.Forms.Button();
            this.btnAllocateTreat = new System.Windows.Forms.Button();
            this.grpVisitTreatMaintenance = new System.Windows.Forms.GroupBox();
            this.pnlVisitTreatAddTreat = new System.Windows.Forms.Panel();
            this.maskTbVisitTreatQuantity = new System.Windows.Forms.MaskedTextBox();
            this.lblVisitTreathint = new System.Windows.Forms.Label();
            this.btnVisitTreatUpdate = new System.Windows.Forms.Button();
            this.cmbVisitTreatAddDescr = new System.Windows.Forms.ComboBox();
            this.lblVisitTreatAddQuantity = new System.Windows.Forms.Label();
            this.lblVisitTreatAddDescr = new System.Windows.Forms.Label();
            this.btnReturnToVisitF = new System.Windows.Forms.Button();
            this.btnVisitTreatSave = new System.Windows.Forms.Button();
            this.tbVisitTreatCatName = new System.Windows.Forms.TextBox();
            this.tbVisitTreatVetName = new System.Windows.Forms.TextBox();
            this.lblVisitTreatDescr = new System.Windows.Forms.Label();
            this.grpVisitTreatDetails = new System.Windows.Forms.GroupBox();
            this.tbVisitTreatStatus = new System.Windows.Forms.TextBox();
            this.lblVisitTreatStatus = new System.Windows.Forms.Label();
            this.dgvVisitTreatments = new System.Windows.Forms.DataGridView();
            this.lblVisitTreatVetName = new System.Windows.Forms.Label();
            this.tbVisitTreatOwnerName = new System.Windows.Forms.TextBox();
            this.lblVisitTreatOwnerName = new System.Windows.Forms.Label();
            this.lblVisitTreatCatName = new System.Windows.Forms.Label();
            this.grpVisitTreatMaintenance.SuspendLayout();
            this.pnlVisitTreatAddTreat.SuspendLayout();
            this.grpVisitTreatDetails.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvVisitTreatments)).BeginInit();
            this.SuspendLayout();
            // 
            // btnVisitTreatPreviousVisit
            // 
            this.btnVisitTreatPreviousVisit.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnVisitTreatPreviousVisit.Location = new System.Drawing.Point(17, 153);
            this.btnVisitTreatPreviousVisit.Name = "btnVisitTreatPreviousVisit";
            this.btnVisitTreatPreviousVisit.Size = new System.Drawing.Size(176, 37);
            this.btnVisitTreatPreviousVisit.TabIndex = 2;
            this.btnVisitTreatPreviousVisit.Text = "Previous Visit";
            this.btnVisitTreatPreviousVisit.UseVisualStyleBackColor = true;
            this.btnVisitTreatPreviousVisit.Click += new System.EventHandler(this.btnVisitTreatPreviousVisit_Click);
            // 
            // btnVisitTreatNextVisit
            // 
            this.btnVisitTreatNextVisit.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnVisitTreatNextVisit.Location = new System.Drawing.Point(199, 153);
            this.btnVisitTreatNextVisit.Name = "btnVisitTreatNextVisit";
            this.btnVisitTreatNextVisit.Size = new System.Drawing.Size(178, 37);
            this.btnVisitTreatNextVisit.TabIndex = 3;
            this.btnVisitTreatNextVisit.Text = "Next Visit";
            this.btnVisitTreatNextVisit.UseVisualStyleBackColor = true;
            this.btnVisitTreatNextVisit.Click += new System.EventHandler(this.btnVisitTreatNextVisit_Click);
            // 
            // lstVisitTreatVisitsId
            // 
            this.lstVisitTreatVisitsId.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lstVisitTreatVisitsId.FormattingEnabled = true;
            this.lstVisitTreatVisitsId.ItemHeight = 21;
            this.lstVisitTreatVisitsId.Location = new System.Drawing.Point(23, 46);
            this.lstVisitTreatVisitsId.Name = "lstVisitTreatVisitsId";
            this.lstVisitTreatVisitsId.Size = new System.Drawing.Size(354, 88);
            this.lstVisitTreatVisitsId.TabIndex = 1;
            // 
            // btnVisitTreatRemoveTreat
            // 
            this.btnVisitTreatRemoveTreat.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnVisitTreatRemoveTreat.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnVisitTreatRemoveTreat.Location = new System.Drawing.Point(17, 301);
            this.btnVisitTreatRemoveTreat.Name = "btnVisitTreatRemoveTreat";
            this.btnVisitTreatRemoveTreat.Size = new System.Drawing.Size(354, 42);
            this.btnVisitTreatRemoveTreat.TabIndex = 6;
            this.btnVisitTreatRemoveTreat.Text = "Remove Treatment";
            this.btnVisitTreatRemoveTreat.UseVisualStyleBackColor = true;
            this.btnVisitTreatRemoveTreat.Click += new System.EventHandler(this.btnVisitTreatRemoveTreat_Click);
            // 
            // btnVisitTreatReturn
            // 
            this.btnVisitTreatReturn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnVisitTreatReturn.Location = new System.Drawing.Point(17, 352);
            this.btnVisitTreatReturn.Name = "btnVisitTreatReturn";
            this.btnVisitTreatReturn.Size = new System.Drawing.Size(354, 50);
            this.btnVisitTreatReturn.TabIndex = 7;
            this.btnVisitTreatReturn.Text = "Return to Main Menu";
            this.btnVisitTreatReturn.UseVisualStyleBackColor = true;
            this.btnVisitTreatReturn.Click += new System.EventHandler(this.btnVisitTreatReturn_Click);
            // 
            // btnVisitTreatModifyTreat
            // 
            this.btnVisitTreatModifyTreat.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnVisitTreatModifyTreat.Location = new System.Drawing.Point(17, 253);
            this.btnVisitTreatModifyTreat.Name = "btnVisitTreatModifyTreat";
            this.btnVisitTreatModifyTreat.Size = new System.Drawing.Size(354, 42);
            this.btnVisitTreatModifyTreat.TabIndex = 5;
            this.btnVisitTreatModifyTreat.Text = "Modify Treatment";
            this.btnVisitTreatModifyTreat.UseVisualStyleBackColor = true;
            this.btnVisitTreatModifyTreat.Click += new System.EventHandler(this.btnVisitTreatModifyTreat_Click);
            // 
            // btnAllocateTreat
            // 
            this.btnAllocateTreat.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnAllocateTreat.ForeColor = System.Drawing.Color.Green;
            this.btnAllocateTreat.Location = new System.Drawing.Point(17, 206);
            this.btnAllocateTreat.Name = "btnAllocateTreat";
            this.btnAllocateTreat.Size = new System.Drawing.Size(354, 41);
            this.btnAllocateTreat.TabIndex = 4;
            this.btnAllocateTreat.Text = "Allocate Treatment";
            this.btnAllocateTreat.UseVisualStyleBackColor = true;
            this.btnAllocateTreat.Click += new System.EventHandler(this.btnAllocateTreat_Click);
            // 
            // grpVisitTreatMaintenance
            // 
            this.grpVisitTreatMaintenance.Controls.Add(this.btnVisitTreatRemoveTreat);
            this.grpVisitTreatMaintenance.Controls.Add(this.btnVisitTreatReturn);
            this.grpVisitTreatMaintenance.Controls.Add(this.btnVisitTreatPreviousVisit);
            this.grpVisitTreatMaintenance.Controls.Add(this.btnVisitTreatNextVisit);
            this.grpVisitTreatMaintenance.Controls.Add(this.btnVisitTreatModifyTreat);
            this.grpVisitTreatMaintenance.Controls.Add(this.btnAllocateTreat);
            this.grpVisitTreatMaintenance.Controls.Add(this.lstVisitTreatVisitsId);
            this.grpVisitTreatMaintenance.Font = new System.Drawing.Font("Vivaldi", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpVisitTreatMaintenance.Location = new System.Drawing.Point(29, 25);
            this.grpVisitTreatMaintenance.Name = "grpVisitTreatMaintenance";
            this.grpVisitTreatMaintenance.Size = new System.Drawing.Size(394, 421);
            this.grpVisitTreatMaintenance.TabIndex = 39;
            this.grpVisitTreatMaintenance.TabStop = false;
            this.grpVisitTreatMaintenance.Text = "Treatment to Visit Allocation";
            // 
            // pnlVisitTreatAddTreat
            // 
            this.pnlVisitTreatAddTreat.BackColor = System.Drawing.Color.Silver;
            this.pnlVisitTreatAddTreat.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlVisitTreatAddTreat.Controls.Add(this.maskTbVisitTreatQuantity);
            this.pnlVisitTreatAddTreat.Controls.Add(this.lblVisitTreathint);
            this.pnlVisitTreatAddTreat.Controls.Add(this.btnVisitTreatUpdate);
            this.pnlVisitTreatAddTreat.Controls.Add(this.cmbVisitTreatAddDescr);
            this.pnlVisitTreatAddTreat.Controls.Add(this.lblVisitTreatAddQuantity);
            this.pnlVisitTreatAddTreat.Controls.Add(this.lblVisitTreatAddDescr);
            this.pnlVisitTreatAddTreat.Controls.Add(this.btnReturnToVisitF);
            this.pnlVisitTreatAddTreat.Controls.Add(this.btnVisitTreatSave);
            this.pnlVisitTreatAddTreat.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.pnlVisitTreatAddTreat.Location = new System.Drawing.Point(286, 25);
            this.pnlVisitTreatAddTreat.MaximumSize = new System.Drawing.Size(621, 408);
            this.pnlVisitTreatAddTreat.MinimumSize = new System.Drawing.Size(621, 408);
            this.pnlVisitTreatAddTreat.Name = "pnlVisitTreatAddTreat";
            this.pnlVisitTreatAddTreat.Size = new System.Drawing.Size(621, 408);
            this.pnlVisitTreatAddTreat.TabIndex = 38;
            // 
            // maskTbVisitTreatQuantity
            // 
            this.maskTbVisitTreatQuantity.Location = new System.Drawing.Point(212, 123);
            this.maskTbVisitTreatQuantity.Mask = "00000";
            this.maskTbVisitTreatQuantity.Name = "maskTbVisitTreatQuantity";
            this.maskTbVisitTreatQuantity.Size = new System.Drawing.Size(116, 26);
            this.maskTbVisitTreatQuantity.TabIndex = 8;
            this.maskTbVisitTreatQuantity.ValidatingType = typeof(int);
            // 
            // lblVisitTreathint
            // 
            this.lblVisitTreathint.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVisitTreathint.ForeColor = System.Drawing.Color.Navy;
            this.lblVisitTreathint.Location = new System.Drawing.Point(334, 117);
            this.lblVisitTreathint.Name = "lblVisitTreathint";
            this.lblVisitTreathint.Size = new System.Drawing.Size(268, 52);
            this.lblVisitTreathint.TabIndex = 34;
            this.lblVisitTreathint.Text = "Enter a positive  number - quantity of the treament you are going to allocate";
            // 
            // btnVisitTreatUpdate
            // 
            this.btnVisitTreatUpdate.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnVisitTreatUpdate.ForeColor = System.Drawing.Color.DarkGreen;
            this.btnVisitTreatUpdate.Location = new System.Drawing.Point(269, 251);
            this.btnVisitTreatUpdate.Name = "btnVisitTreatUpdate";
            this.btnVisitTreatUpdate.Size = new System.Drawing.Size(242, 48);
            this.btnVisitTreatUpdate.TabIndex = 9;
            this.btnVisitTreatUpdate.Text = "Update";
            this.btnVisitTreatUpdate.UseVisualStyleBackColor = true;
            this.btnVisitTreatUpdate.Click += new System.EventHandler(this.btnVisitTreatUpdate_Click);
            // 
            // cmbVisitTreatAddDescr
            // 
            this.cmbVisitTreatAddDescr.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbVisitTreatAddDescr.FormattingEnabled = true;
            this.cmbVisitTreatAddDescr.Location = new System.Drawing.Point(210, 78);
            this.cmbVisitTreatAddDescr.Name = "cmbVisitTreatAddDescr";
            this.cmbVisitTreatAddDescr.Size = new System.Drawing.Size(224, 27);
            this.cmbVisitTreatAddDescr.TabIndex = 31;
            // 
            // lblVisitTreatAddQuantity
            // 
            this.lblVisitTreatAddQuantity.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblVisitTreatAddQuantity.BackColor = System.Drawing.Color.Silver;
            this.lblVisitTreatAddQuantity.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVisitTreatAddQuantity.ForeColor = System.Drawing.Color.Black;
            this.lblVisitTreatAddQuantity.Location = new System.Drawing.Point(19, 118);
            this.lblVisitTreatAddQuantity.Name = "lblVisitTreatAddQuantity";
            this.lblVisitTreatAddQuantity.Size = new System.Drawing.Size(154, 28);
            this.lblVisitTreatAddQuantity.TabIndex = 27;
            this.lblVisitTreatAddQuantity.Text = "Quantity";
            this.lblVisitTreatAddQuantity.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblVisitTreatAddDescr
            // 
            this.lblVisitTreatAddDescr.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblVisitTreatAddDescr.BackColor = System.Drawing.Color.Silver;
            this.lblVisitTreatAddDescr.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVisitTreatAddDescr.ForeColor = System.Drawing.Color.Black;
            this.lblVisitTreatAddDescr.Location = new System.Drawing.Point(19, 78);
            this.lblVisitTreatAddDescr.Name = "lblVisitTreatAddDescr";
            this.lblVisitTreatAddDescr.Size = new System.Drawing.Size(177, 22);
            this.lblVisitTreatAddDescr.TabIndex = 25;
            this.lblVisitTreatAddDescr.Text = "Treatment Description";
            this.lblVisitTreatAddDescr.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnReturnToVisitF
            // 
            this.btnReturnToVisitF.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnReturnToVisitF.Location = new System.Drawing.Point(269, 306);
            this.btnReturnToVisitF.Name = "btnReturnToVisitF";
            this.btnReturnToVisitF.Size = new System.Drawing.Size(242, 47);
            this.btnReturnToVisitF.TabIndex = 11;
            this.btnReturnToVisitF.Text = "Cancel";
            this.btnReturnToVisitF.UseVisualStyleBackColor = true;
            this.btnReturnToVisitF.Click += new System.EventHandler(this.btnReturnToVisitF_Click);
            // 
            // btnVisitTreatSave
            // 
            this.btnVisitTreatSave.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnVisitTreatSave.ForeColor = System.Drawing.Color.DarkGreen;
            this.btnVisitTreatSave.Location = new System.Drawing.Point(269, 250);
            this.btnVisitTreatSave.Name = "btnVisitTreatSave";
            this.btnVisitTreatSave.Size = new System.Drawing.Size(242, 48);
            this.btnVisitTreatSave.TabIndex = 10;
            this.btnVisitTreatSave.Text = "Save ";
            this.btnVisitTreatSave.UseVisualStyleBackColor = true;
            this.btnVisitTreatSave.Click += new System.EventHandler(this.btnVisitTreatSave_Click);
            // 
            // tbVisitTreatCatName
            // 
            this.tbVisitTreatCatName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tbVisitTreatCatName.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbVisitTreatCatName.Location = new System.Drawing.Point(278, 35);
            this.tbVisitTreatCatName.Name = "tbVisitTreatCatName";
            this.tbVisitTreatCatName.ReadOnly = true;
            this.tbVisitTreatCatName.Size = new System.Drawing.Size(173, 29);
            this.tbVisitTreatCatName.TabIndex = 29;
            // 
            // tbVisitTreatVetName
            // 
            this.tbVisitTreatVetName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tbVisitTreatVetName.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbVisitTreatVetName.Location = new System.Drawing.Point(278, 119);
            this.tbVisitTreatVetName.Name = "tbVisitTreatVetName";
            this.tbVisitTreatVetName.ReadOnly = true;
            this.tbVisitTreatVetName.Size = new System.Drawing.Size(173, 29);
            this.tbVisitTreatVetName.TabIndex = 30;
            // 
            // lblVisitTreatDescr
            // 
            this.lblVisitTreatDescr.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblVisitTreatDescr.BackColor = System.Drawing.SystemColors.Control;
            this.lblVisitTreatDescr.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVisitTreatDescr.ForeColor = System.Drawing.Color.Black;
            this.lblVisitTreatDescr.Location = new System.Drawing.Point(66, 192);
            this.lblVisitTreatDescr.Name = "lblVisitTreatDescr";
            this.lblVisitTreatDescr.Size = new System.Drawing.Size(227, 55);
            this.lblVisitTreatDescr.TabIndex = 25;
            this.lblVisitTreatDescr.Text = "Treatment Description";
            // 
            // grpVisitTreatDetails
            // 
            this.grpVisitTreatDetails.Controls.Add(this.tbVisitTreatStatus);
            this.grpVisitTreatDetails.Controls.Add(this.lblVisitTreatStatus);
            this.grpVisitTreatDetails.Controls.Add(this.dgvVisitTreatments);
            this.grpVisitTreatDetails.Controls.Add(this.tbVisitTreatVetName);
            this.grpVisitTreatDetails.Controls.Add(this.tbVisitTreatCatName);
            this.grpVisitTreatDetails.Controls.Add(this.lblVisitTreatDescr);
            this.grpVisitTreatDetails.Controls.Add(this.lblVisitTreatVetName);
            this.grpVisitTreatDetails.Controls.Add(this.tbVisitTreatOwnerName);
            this.grpVisitTreatDetails.Controls.Add(this.lblVisitTreatOwnerName);
            this.grpVisitTreatDetails.Controls.Add(this.lblVisitTreatCatName);
            this.grpVisitTreatDetails.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpVisitTreatDetails.Location = new System.Drawing.Point(429, 25);
            this.grpVisitTreatDetails.Name = "grpVisitTreatDetails";
            this.grpVisitTreatDetails.Size = new System.Drawing.Size(484, 483);
            this.grpVisitTreatDetails.TabIndex = 40;
            this.grpVisitTreatDetails.TabStop = false;
            // 
            // tbVisitTreatStatus
            // 
            this.tbVisitTreatStatus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tbVisitTreatStatus.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbVisitTreatStatus.Location = new System.Drawing.Point(278, 160);
            this.tbVisitTreatStatus.Name = "tbVisitTreatStatus";
            this.tbVisitTreatStatus.ReadOnly = true;
            this.tbVisitTreatStatus.Size = new System.Drawing.Size(173, 29);
            this.tbVisitTreatStatus.TabIndex = 33;
            // 
            // lblVisitTreatStatus
            // 
            this.lblVisitTreatStatus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblVisitTreatStatus.BackColor = System.Drawing.SystemColors.Control;
            this.lblVisitTreatStatus.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVisitTreatStatus.ForeColor = System.Drawing.Color.Black;
            this.lblVisitTreatStatus.Location = new System.Drawing.Point(68, 159);
            this.lblVisitTreatStatus.Name = "lblVisitTreatStatus";
            this.lblVisitTreatStatus.Size = new System.Drawing.Size(173, 28);
            this.lblVisitTreatStatus.TabIndex = 32;
            this.lblVisitTreatStatus.Text = "Status of visit";
            // 
            // dgvVisitTreatments
            // 
            this.dgvVisitTreatments.AllowUserToAddRows = false;
            this.dgvVisitTreatments.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dgvVisitTreatments.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvVisitTreatments.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvVisitTreatments.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvVisitTreatments.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvVisitTreatments.Location = new System.Drawing.Point(6, 235);
            this.dgvVisitTreatments.Name = "dgvVisitTreatments";
            this.dgvVisitTreatments.ReadOnly = true;
            this.dgvVisitTreatments.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvVisitTreatments.Size = new System.Drawing.Size(472, 242);
            this.dgvVisitTreatments.TabIndex = 31;
            // 
            // lblVisitTreatVetName
            // 
            this.lblVisitTreatVetName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblVisitTreatVetName.BackColor = System.Drawing.SystemColors.Control;
            this.lblVisitTreatVetName.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVisitTreatVetName.ForeColor = System.Drawing.Color.Black;
            this.lblVisitTreatVetName.Location = new System.Drawing.Point(68, 118);
            this.lblVisitTreatVetName.Name = "lblVisitTreatVetName";
            this.lblVisitTreatVetName.Size = new System.Drawing.Size(173, 28);
            this.lblVisitTreatVetName.TabIndex = 23;
            this.lblVisitTreatVetName.Text = "Veterinarian Name";
            // 
            // tbVisitTreatOwnerName
            // 
            this.tbVisitTreatOwnerName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tbVisitTreatOwnerName.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbVisitTreatOwnerName.Location = new System.Drawing.Point(278, 76);
            this.tbVisitTreatOwnerName.Name = "tbVisitTreatOwnerName";
            this.tbVisitTreatOwnerName.ReadOnly = true;
            this.tbVisitTreatOwnerName.Size = new System.Drawing.Size(173, 29);
            this.tbVisitTreatOwnerName.TabIndex = 22;
            // 
            // lblVisitTreatOwnerName
            // 
            this.lblVisitTreatOwnerName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblVisitTreatOwnerName.BackColor = System.Drawing.SystemColors.Control;
            this.lblVisitTreatOwnerName.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVisitTreatOwnerName.ForeColor = System.Drawing.Color.Black;
            this.lblVisitTreatOwnerName.Location = new System.Drawing.Point(82, 76);
            this.lblVisitTreatOwnerName.Name = "lblVisitTreatOwnerName";
            this.lblVisitTreatOwnerName.Size = new System.Drawing.Size(148, 28);
            this.lblVisitTreatOwnerName.TabIndex = 7;
            this.lblVisitTreatOwnerName.Text = "Owner Name";
            // 
            // lblVisitTreatCatName
            // 
            this.lblVisitTreatCatName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblVisitTreatCatName.BackColor = System.Drawing.SystemColors.Control;
            this.lblVisitTreatCatName.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVisitTreatCatName.ForeColor = System.Drawing.Color.Black;
            this.lblVisitTreatCatName.Location = new System.Drawing.Point(82, 36);
            this.lblVisitTreatCatName.Name = "lblVisitTreatCatName";
            this.lblVisitTreatCatName.Size = new System.Drawing.Size(171, 22);
            this.lblVisitTreatCatName.TabIndex = 2;
            this.lblVisitTreatCatName.Text = "Cat Name";
            // 
            // VisitTreatmentForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1046, 605);
            this.Controls.Add(this.pnlVisitTreatAddTreat);
            this.Controls.Add(this.grpVisitTreatMaintenance);
            this.Controls.Add(this.grpVisitTreatDetails);
            this.Name = "VisitTreatmentForm";
            this.Text = "Allocate_Treatment_to_Visit";
            this.grpVisitTreatMaintenance.ResumeLayout(false);
            this.pnlVisitTreatAddTreat.ResumeLayout(false);
            this.pnlVisitTreatAddTreat.PerformLayout();
            this.grpVisitTreatDetails.ResumeLayout(false);
            this.grpVisitTreatDetails.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvVisitTreatments)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnVisitTreatPreviousVisit;
        private System.Windows.Forms.Button btnVisitTreatNextVisit;
        private System.Windows.Forms.ListBox lstVisitTreatVisitsId;
        private System.Windows.Forms.Button btnVisitTreatRemoveTreat;
        private System.Windows.Forms.Button btnVisitTreatReturn;
        private System.Windows.Forms.Button btnVisitTreatModifyTreat;
        private System.Windows.Forms.Button btnAllocateTreat;
        private System.Windows.Forms.GroupBox grpVisitTreatMaintenance;
        private System.Windows.Forms.TextBox tbVisitTreatCatName;
        private System.Windows.Forms.TextBox tbVisitTreatVetName;
        private System.Windows.Forms.Label lblVisitTreatDescr;
        private System.Windows.Forms.GroupBox grpVisitTreatDetails;
        private System.Windows.Forms.Label lblVisitTreatVetName;
        private System.Windows.Forms.TextBox tbVisitTreatOwnerName;
        private System.Windows.Forms.Label lblVisitTreatOwnerName;
        private System.Windows.Forms.Label lblVisitTreatCatName;
        private System.Windows.Forms.Button btnVisitTreatSave;
        private System.Windows.Forms.Button btnReturnToVisitF;
        private System.Windows.Forms.Label lblVisitTreatAddDescr;
        private System.Windows.Forms.Label lblVisitTreatAddQuantity;
        private System.Windows.Forms.ComboBox cmbVisitTreatAddDescr;
        private System.Windows.Forms.Panel pnlVisitTreatAddTreat;
        private System.Windows.Forms.DataGridView dgvVisitTreatments;
        private System.Windows.Forms.Button btnVisitTreatUpdate;
        private System.Windows.Forms.TextBox tbVisitTreatStatus;
        private System.Windows.Forms.Label lblVisitTreatStatus;
        private System.Windows.Forms.Label lblVisitTreathint;
        private System.Windows.Forms.MaskedTextBox maskTbVisitTreatQuantity;
    }
}