﻿namespace ShuvaevaAssignment1
{
    partial class VeterinarianForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstVeterinarians = new System.Windows.Forms.ListBox();
            this.grpVeterinarianMaintenance = new System.Windows.Forms.GroupBox();
            this.btnVetReturn = new System.Windows.Forms.Button();
            this.btnDeleteVet = new System.Windows.Forms.Button();
            this.btnNextVet = new System.Windows.Forms.Button();
            this.btnModifyVet = new System.Windows.Forms.Button();
            this.btnAddVet = new System.Windows.Forms.Button();
            this.btnPreviousVet = new System.Windows.Forms.Button();
            this.grpVeterenarianDetails = new System.Windows.Forms.GroupBox();
            this.lblVetIdname = new System.Windows.Forms.Label();
            this.lblVetId = new System.Windows.Forms.Label();
            this.tbVetRate = new System.Windows.Forms.TextBox();
            this.tbVetLastName = new System.Windows.Forms.TextBox();
            this.lblVetRate = new System.Windows.Forms.Label();
            this.tbVetFirstName = new System.Windows.Forms.TextBox();
            this.lblVetFirstName = new System.Windows.Forms.Label();
            this.lblVetLastName = new System.Windows.Forms.Label();
            this.pnlAddVet = new System.Windows.Forms.Panel();
            this.tbVetAddRate = new System.Windows.Forms.TextBox();
            this.lblVethint = new System.Windows.Forms.Label();
            this.btnUpdateVet = new System.Windows.Forms.Button();
            this.btnReturnToVetF = new System.Windows.Forms.Button();
            this.btnSaveVet = new System.Windows.Forms.Button();
            this.tbVetAddLastN = new System.Windows.Forms.TextBox();
            this.tbVetAddFirstN = new System.Windows.Forms.TextBox();
            this.lblVetAddRate = new System.Windows.Forms.Label();
            this.lblVetAddLastN = new System.Windows.Forms.Label();
            this.lblVetAddFirstN = new System.Windows.Forms.Label();
            this.eventLog1 = new System.Diagnostics.EventLog();
            this.grpVeterinarianMaintenance.SuspendLayout();
            this.grpVeterenarianDetails.SuspendLayout();
            this.pnlAddVet.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.eventLog1)).BeginInit();
            this.SuspendLayout();
            // 
            // lstVeterinarians
            // 
            this.lstVeterinarians.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lstVeterinarians.FormattingEnabled = true;
            this.lstVeterinarians.ItemHeight = 21;
            this.lstVeterinarians.Location = new System.Drawing.Point(59, 54);
            this.lstVeterinarians.Name = "lstVeterinarians";
            this.lstVeterinarians.Size = new System.Drawing.Size(346, 109);
            this.lstVeterinarians.TabIndex = 1;
            // 
            // grpVeterinarianMaintenance
            // 
            this.grpVeterinarianMaintenance.Controls.Add(this.btnVetReturn);
            this.grpVeterinarianMaintenance.Controls.Add(this.btnDeleteVet);
            this.grpVeterinarianMaintenance.Controls.Add(this.btnNextVet);
            this.grpVeterinarianMaintenance.Controls.Add(this.btnModifyVet);
            this.grpVeterinarianMaintenance.Controls.Add(this.btnAddVet);
            this.grpVeterinarianMaintenance.Controls.Add(this.btnPreviousVet);
            this.grpVeterinarianMaintenance.Font = new System.Drawing.Font("Vivaldi", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpVeterinarianMaintenance.Location = new System.Drawing.Point(36, 12);
            this.grpVeterinarianMaintenance.Name = "grpVeterinarianMaintenance";
            this.grpVeterinarianMaintenance.Size = new System.Drawing.Size(423, 488);
            this.grpVeterinarianMaintenance.TabIndex = 1;
            this.grpVeterinarianMaintenance.TabStop = false;
            this.grpVeterinarianMaintenance.Text = "Veterinarian Maintenance ";
            // 
            // btnVetReturn
            // 
            this.btnVetReturn.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnVetReturn.Location = new System.Drawing.Point(24, 362);
            this.btnVetReturn.Name = "btnVetReturn";
            this.btnVetReturn.Size = new System.Drawing.Size(354, 42);
            this.btnVetReturn.TabIndex = 6;
            this.btnVetReturn.Text = "Return to Main Menu";
            this.btnVetReturn.UseVisualStyleBackColor = true;
            this.btnVetReturn.Click += new System.EventHandler(this.btnVetReturn_Click);
            // 
            // btnDeleteVet
            // 
            this.btnDeleteVet.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnDeleteVet.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnDeleteVet.Location = new System.Drawing.Point(24, 436);
            this.btnDeleteVet.Name = "btnDeleteVet";
            this.btnDeleteVet.Size = new System.Drawing.Size(354, 42);
            this.btnDeleteVet.TabIndex = 7;
            this.btnDeleteVet.Text = "Delete Veterinarian";
            this.btnDeleteVet.UseVisualStyleBackColor = true;
            this.btnDeleteVet.Click += new System.EventHandler(this.btnDeleteVet_Click);
            // 
            // btnNextVet
            // 
            this.btnNextVet.Font = new System.Drawing.Font("Arial Narrow", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnNextVet.Location = new System.Drawing.Point(209, 188);
            this.btnNextVet.Name = "btnNextVet";
            this.btnNextVet.Size = new System.Drawing.Size(161, 39);
            this.btnNextVet.TabIndex = 3;
            this.btnNextVet.Text = "Next Veterinarian";
            this.btnNextVet.UseVisualStyleBackColor = true;
            this.btnNextVet.Click += new System.EventHandler(this.btnNextVet_Click);
            // 
            // btnModifyVet
            // 
            this.btnModifyVet.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnModifyVet.Location = new System.Drawing.Point(24, 314);
            this.btnModifyVet.Name = "btnModifyVet";
            this.btnModifyVet.Size = new System.Drawing.Size(354, 42);
            this.btnModifyVet.TabIndex = 5;
            this.btnModifyVet.Text = "Modify Veterinarian";
            this.btnModifyVet.UseVisualStyleBackColor = true;
            this.btnModifyVet.Click += new System.EventHandler(this.btnModifyVet_Click);
            // 
            // btnAddVet
            // 
            this.btnAddVet.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddVet.ForeColor = System.Drawing.Color.Green;
            this.btnAddVet.Location = new System.Drawing.Point(24, 257);
            this.btnAddVet.Name = "btnAddVet";
            this.btnAddVet.Size = new System.Drawing.Size(346, 43);
            this.btnAddVet.TabIndex = 4;
            this.btnAddVet.Text = "Add Veterinarian";
            this.btnAddVet.UseVisualStyleBackColor = true;
            this.btnAddVet.Click += new System.EventHandler(this.btnAddVet_Click);
            // 
            // btnPreviousVet
            // 
            this.btnPreviousVet.Font = new System.Drawing.Font("Arial Narrow", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnPreviousVet.Location = new System.Drawing.Point(24, 188);
            this.btnPreviousVet.Name = "btnPreviousVet";
            this.btnPreviousVet.Size = new System.Drawing.Size(161, 39);
            this.btnPreviousVet.TabIndex = 2;
            this.btnPreviousVet.Text = "Previous Veterinarian";
            this.btnPreviousVet.UseVisualStyleBackColor = true;
            this.btnPreviousVet.Click += new System.EventHandler(this.btnPreviousVet_Click);
            // 
            // grpVeterenarianDetails
            // 
            this.grpVeterenarianDetails.Controls.Add(this.lblVetIdname);
            this.grpVeterenarianDetails.Controls.Add(this.lblVetId);
            this.grpVeterenarianDetails.Controls.Add(this.tbVetRate);
            this.grpVeterenarianDetails.Controls.Add(this.tbVetLastName);
            this.grpVeterenarianDetails.Controls.Add(this.lblVetRate);
            this.grpVeterenarianDetails.Controls.Add(this.tbVetFirstName);
            this.grpVeterenarianDetails.Controls.Add(this.lblVetFirstName);
            this.grpVeterenarianDetails.Controls.Add(this.lblVetLastName);
            this.grpVeterenarianDetails.Location = new System.Drawing.Point(465, 12);
            this.grpVeterenarianDetails.Name = "grpVeterenarianDetails";
            this.grpVeterenarianDetails.Size = new System.Drawing.Size(381, 488);
            this.grpVeterenarianDetails.TabIndex = 2;
            this.grpVeterenarianDetails.TabStop = false;
            // 
            // lblVetIdname
            // 
            this.lblVetIdname.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblVetIdname.BackColor = System.Drawing.SystemColors.Control;
            this.lblVetIdname.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVetIdname.ForeColor = System.Drawing.Color.Black;
            this.lblVetIdname.Location = new System.Drawing.Point(0, 43);
            this.lblVetIdname.Name = "lblVetIdname";
            this.lblVetIdname.Size = new System.Drawing.Size(147, 23);
            this.lblVetIdname.TabIndex = 33;
            this.lblVetIdname.Text = "Veterenarian ID";
            // 
            // lblVetId
            // 
            this.lblVetId.AutoSize = true;
            this.lblVetId.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVetId.Location = new System.Drawing.Point(174, 43);
            this.lblVetId.Name = "lblVetId";
            this.lblVetId.Size = new System.Drawing.Size(29, 23);
            this.lblVetId.TabIndex = 32;
            this.lblVetId.Text = "ID";
            // 
            // tbVetRate
            // 
            this.tbVetRate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tbVetRate.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbVetRate.Location = new System.Drawing.Point(172, 173);
            this.tbVetRate.Name = "tbVetRate";
            this.tbVetRate.ReadOnly = true;
            this.tbVetRate.Size = new System.Drawing.Size(173, 29);
            this.tbVetRate.TabIndex = 26;
            // 
            // tbVetLastName
            // 
            this.tbVetLastName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tbVetLastName.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbVetLastName.Location = new System.Drawing.Point(172, 128);
            this.tbVetLastName.Name = "tbVetLastName";
            this.tbVetLastName.ReadOnly = true;
            this.tbVetLastName.Size = new System.Drawing.Size(173, 29);
            this.tbVetLastName.TabIndex = 25;
            // 
            // lblVetRate
            // 
            this.lblVetRate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblVetRate.BackColor = System.Drawing.SystemColors.Control;
            this.lblVetRate.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVetRate.ForeColor = System.Drawing.Color.Black;
            this.lblVetRate.Location = new System.Drawing.Point(74, 173);
            this.lblVetRate.Name = "lblVetRate";
            this.lblVetRate.Size = new System.Drawing.Size(92, 28);
            this.lblVetRate.TabIndex = 27;
            this.lblVetRate.Text = "Rate  $";
            // 
            // tbVetFirstName
            // 
            this.tbVetFirstName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tbVetFirstName.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbVetFirstName.Location = new System.Drawing.Point(172, 85);
            this.tbVetFirstName.Name = "tbVetFirstName";
            this.tbVetFirstName.ReadOnly = true;
            this.tbVetFirstName.Size = new System.Drawing.Size(173, 29);
            this.tbVetFirstName.TabIndex = 23;
            // 
            // lblVetFirstName
            // 
            this.lblVetFirstName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblVetFirstName.BackColor = System.Drawing.SystemColors.Control;
            this.lblVetFirstName.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVetFirstName.ForeColor = System.Drawing.Color.Black;
            this.lblVetFirstName.Location = new System.Drawing.Point(27, 82);
            this.lblVetFirstName.Name = "lblVetFirstName";
            this.lblVetFirstName.Size = new System.Drawing.Size(106, 23);
            this.lblVetFirstName.TabIndex = 22;
            this.lblVetFirstName.Text = "First Name";
            // 
            // lblVetLastName
            // 
            this.lblVetLastName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblVetLastName.BackColor = System.Drawing.SystemColors.Control;
            this.lblVetLastName.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVetLastName.ForeColor = System.Drawing.Color.Black;
            this.lblVetLastName.Location = new System.Drawing.Point(23, 126);
            this.lblVetLastName.Name = "lblVetLastName";
            this.lblVetLastName.Size = new System.Drawing.Size(118, 22);
            this.lblVetLastName.TabIndex = 24;
            this.lblVetLastName.Text = "Last Name";
            // 
            // pnlAddVet
            // 
            this.pnlAddVet.BackColor = System.Drawing.Color.Silver;
            this.pnlAddVet.Controls.Add(this.tbVetAddRate);
            this.pnlAddVet.Controls.Add(this.lblVethint);
            this.pnlAddVet.Controls.Add(this.btnUpdateVet);
            this.pnlAddVet.Controls.Add(this.btnReturnToVetF);
            this.pnlAddVet.Controls.Add(this.btnSaveVet);
            this.pnlAddVet.Controls.Add(this.tbVetAddLastN);
            this.pnlAddVet.Controls.Add(this.tbVetAddFirstN);
            this.pnlAddVet.Controls.Add(this.lblVetAddRate);
            this.pnlAddVet.Controls.Add(this.lblVetAddLastN);
            this.pnlAddVet.Controls.Add(this.lblVetAddFirstN);
            this.pnlAddVet.Location = new System.Drawing.Point(169, 0);
            this.pnlAddVet.MaximumSize = new System.Drawing.Size(717, 368);
            this.pnlAddVet.MinimumSize = new System.Drawing.Size(717, 368);
            this.pnlAddVet.Name = "pnlAddVet";
            this.pnlAddVet.Size = new System.Drawing.Size(717, 368);
            this.pnlAddVet.TabIndex = 10;
            // 
            // tbVetAddRate
            // 
            this.tbVetAddRate.Location = new System.Drawing.Point(216, 94);
            this.tbVetAddRate.Name = "tbVetAddRate";
            this.tbVetAddRate.Size = new System.Drawing.Size(100, 20);
            this.tbVetAddRate.TabIndex = 37;
            this.tbVetAddRate.TextChanged += new System.EventHandler(this.AddRateTextChange);
            // 
            // lblVethint
            // 
            this.lblVethint.AutoSize = true;
            this.lblVethint.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVethint.ForeColor = System.Drawing.Color.Navy;
            this.lblVethint.Location = new System.Drawing.Point(344, 96);
            this.lblVethint.Name = "lblVethint";
            this.lblVethint.Size = new System.Drawing.Size(145, 19);
            this.lblVethint.TabIndex = 36;
            this.lblVethint.Text = "Enter a number here ";
            // 
            // btnUpdateVet
            // 
            this.btnUpdateVet.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnUpdateVet.ForeColor = System.Drawing.Color.Green;
            this.btnUpdateVet.Location = new System.Drawing.Point(215, 204);
            this.btnUpdateVet.Name = "btnUpdateVet";
            this.btnUpdateVet.Size = new System.Drawing.Size(242, 47);
            this.btnUpdateVet.TabIndex = 9;
            this.btnUpdateVet.Text = "Update ";
            this.btnUpdateVet.UseVisualStyleBackColor = true;
            this.btnUpdateVet.Click += new System.EventHandler(this.btnUpdateVeterinarian_Click);
            // 
            // btnReturnToVetF
            // 
            this.btnReturnToVetF.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnReturnToVetF.Location = new System.Drawing.Point(216, 301);
            this.btnReturnToVetF.Name = "btnReturnToVetF";
            this.btnReturnToVetF.Size = new System.Drawing.Size(242, 47);
            this.btnReturnToVetF.TabIndex = 10;
            this.btnReturnToVetF.Text = "Cancel";
            this.btnReturnToVetF.UseVisualStyleBackColor = true;
            this.btnReturnToVetF.Click += new System.EventHandler(this.btnReturnToVetF_Click);
            // 
            // btnSaveVet
            // 
            this.btnSaveVet.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnSaveVet.ForeColor = System.Drawing.Color.Green;
            this.btnSaveVet.Location = new System.Drawing.Point(216, 203);
            this.btnSaveVet.Name = "btnSaveVet";
            this.btnSaveVet.Size = new System.Drawing.Size(242, 48);
            this.btnSaveVet.TabIndex = 8;
            this.btnSaveVet.Text = "Save";
            this.btnSaveVet.UseVisualStyleBackColor = true;
            this.btnSaveVet.Click += new System.EventHandler(this.btnSaveVet_Click);
            // 
            // tbVetAddLastN
            // 
            this.tbVetAddLastN.Location = new System.Drawing.Point(216, 65);
            this.tbVetAddLastN.MaxLength = 30;
            this.tbVetAddLastN.Name = "tbVetAddLastN";
            this.tbVetAddLastN.Size = new System.Drawing.Size(242, 20);
            this.tbVetAddLastN.TabIndex = 29;
            // 
            // tbVetAddFirstN
            // 
            this.tbVetAddFirstN.Location = new System.Drawing.Point(216, 34);
            this.tbVetAddFirstN.MaxLength = 30;
            this.tbVetAddFirstN.Name = "tbVetAddFirstN";
            this.tbVetAddFirstN.Size = new System.Drawing.Size(242, 20);
            this.tbVetAddFirstN.TabIndex = 28;
            // 
            // lblVetAddRate
            // 
            this.lblVetAddRate.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVetAddRate.Location = new System.Drawing.Point(151, 95);
            this.lblVetAddRate.Name = "lblVetAddRate";
            this.lblVetAddRate.Size = new System.Drawing.Size(68, 19);
            this.lblVetAddRate.TabIndex = 25;
            this.lblVetAddRate.Text = "Rate   $";
            // 
            // lblVetAddLastN
            // 
            this.lblVetAddLastN.AutoSize = true;
            this.lblVetAddLastN.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVetAddLastN.Location = new System.Drawing.Point(113, 63);
            this.lblVetAddLastN.Name = "lblVetAddLastN";
            this.lblVetAddLastN.Size = new System.Drawing.Size(87, 19);
            this.lblVetAddLastN.TabIndex = 24;
            this.lblVetAddLastN.Text = "Last Name";
            // 
            // lblVetAddFirstN
            // 
            this.lblVetAddFirstN.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVetAddFirstN.Location = new System.Drawing.Point(112, 34);
            this.lblVetAddFirstN.Name = "lblVetAddFirstN";
            this.lblVetAddFirstN.Size = new System.Drawing.Size(98, 20);
            this.lblVetAddFirstN.TabIndex = 23;
            this.lblVetAddFirstN.Text = "First Name";
            // 
            // eventLog1
            // 
            this.eventLog1.SynchronizingObject = this;
            // 
            // VeterinarianForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(931, 512);
            this.Controls.Add(this.pnlAddVet);
            this.Controls.Add(this.lstVeterinarians);
            this.Controls.Add(this.grpVeterinarianMaintenance);
            this.Controls.Add(this.grpVeterenarianDetails);
            this.Name = "VeterinarianForm";
            this.Text = "Veterinarian_Maintenance";
            this.grpVeterinarianMaintenance.ResumeLayout(false);
            this.grpVeterenarianDetails.ResumeLayout(false);
            this.grpVeterenarianDetails.PerformLayout();
            this.pnlAddVet.ResumeLayout(false);
            this.pnlAddVet.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.eventLog1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lstVeterinarians;
        private System.Windows.Forms.GroupBox grpVeterinarianMaintenance;
        private System.Windows.Forms.Button btnPreviousVet;
        private System.Windows.Forms.GroupBox grpVeterenarianDetails;
        private System.Windows.Forms.Button btnAddVet;
        private System.Windows.Forms.Button btnModifyVet;
        private System.Windows.Forms.Button btnDeleteVet;
        private System.Windows.Forms.Button btnNextVet;
        private System.Windows.Forms.Button btnVetReturn;
        private System.Windows.Forms.Label lblVetIdname;
        private System.Windows.Forms.Label lblVetId;
        private System.Windows.Forms.TextBox tbVetRate;
        private System.Windows.Forms.TextBox tbVetLastName;
        private System.Windows.Forms.Label lblVetRate;
        private System.Windows.Forms.TextBox tbVetFirstName;
        private System.Windows.Forms.Label lblVetFirstName;
        private System.Windows.Forms.Label lblVetLastName;
        private System.Windows.Forms.Panel pnlAddVet;
        private System.Windows.Forms.Button btnUpdateVet;
        private System.Windows.Forms.Button btnReturnToVetF;
        private System.Windows.Forms.Button btnSaveVet;
        private System.Windows.Forms.TextBox tbVetAddLastN;
        private System.Windows.Forms.TextBox tbVetAddFirstN;
        private System.Windows.Forms.Label lblVetAddRate;
        private System.Windows.Forms.Label lblVetAddLastN;
        private System.Windows.Forms.Label lblVetAddFirstN;
        private System.Diagnostics.EventLog eventLog1;
        private System.Windows.Forms.Label lblVethint;
        private System.Windows.Forms.TextBox tbVetAddRate;
    }
}