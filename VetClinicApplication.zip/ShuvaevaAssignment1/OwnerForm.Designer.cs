﻿namespace ShuvaevaAssignment1
{
    partial class OwnerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblOwnerFirstName = new System.Windows.Forms.Label();
            this.tbOwnerFirstName = new System.Windows.Forms.TextBox();
            this.lblOwnerLastName = new System.Windows.Forms.Label();
            this.lstOwners = new System.Windows.Forms.ListBox();
            this.btnAddOwner = new System.Windows.Forms.Button();
            this.tbOwnerLastName = new System.Windows.Forms.TextBox();
            this.tbOwnerPhoneNum = new System.Windows.Forms.TextBox();
            this.lblOwnerPhoneNum = new System.Windows.Forms.Label();
            this.lblOwnerAddress = new System.Windows.Forms.Label();
            this.tbOwnerAddress = new System.Windows.Forms.TextBox();
            this.tbOwnerSuburb = new System.Windows.Forms.TextBox();
            this.lblOwnerSuburb = new System.Windows.Forms.Label();
            this.btnPreviousOwner = new System.Windows.Forms.Button();
            this.btnNextOwner = new System.Windows.Forms.Button();
            this.btnOwnerReturn = new System.Windows.Forms.Button();
            this.btnModifyOwner = new System.Windows.Forms.Button();
            this.btnDeleteOwner = new System.Windows.Forms.Button();
            this.lblOwnerId = new System.Windows.Forms.Label();
            this.pnlAddOwner = new System.Windows.Forms.Panel();
            this.maskTbOwnerNumber = new System.Windows.Forms.MaskedTextBox();
            this.lblOwnhint1 = new System.Windows.Forms.Label();
            this.btnUpdateOwner = new System.Windows.Forms.Button();
            this.btnReturnToOwnerF = new System.Windows.Forms.Button();
            this.btnSaveOwner = new System.Windows.Forms.Button();
            this.tbOwnerAddSuburb = new System.Windows.Forms.TextBox();
            this.tbOwnerAddAddress = new System.Windows.Forms.TextBox();
            this.tbOwnerAddLastN = new System.Windows.Forms.TextBox();
            this.tbOwnerAddFirstN = new System.Windows.Forms.TextBox();
            this.lblOwnerAddSuburb = new System.Windows.Forms.Label();
            this.lblOwnerAddAddress = new System.Windows.Forms.Label();
            this.lblOwnerAddPhone = new System.Windows.Forms.Label();
            this.lblOwnerAddLastN = new System.Windows.Forms.Label();
            this.lblOwnerAddFirstN = new System.Windows.Forms.Label();
            this.grpOwnerMaintenance = new System.Windows.Forms.GroupBox();
            this.grpOwnersDetails = new System.Windows.Forms.GroupBox();
            this.lblOwnerIdname = new System.Windows.Forms.Label();
            this.pnlAddOwner.SuspendLayout();
            this.grpOwnerMaintenance.SuspendLayout();
            this.grpOwnersDetails.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblOwnerFirstName
            // 
            this.lblOwnerFirstName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblOwnerFirstName.BackColor = System.Drawing.SystemColors.Control;
            this.lblOwnerFirstName.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblOwnerFirstName.ForeColor = System.Drawing.Color.Black;
            this.lblOwnerFirstName.Location = new System.Drawing.Point(25, 77);
            this.lblOwnerFirstName.Name = "lblOwnerFirstName";
            this.lblOwnerFirstName.Size = new System.Drawing.Size(106, 23);
            this.lblOwnerFirstName.TabIndex = 0;
            this.lblOwnerFirstName.Text = "First Name";
            // 
            // tbOwnerFirstName
            // 
            this.tbOwnerFirstName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tbOwnerFirstName.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbOwnerFirstName.Location = new System.Drawing.Point(168, 77);
            this.tbOwnerFirstName.Name = "tbOwnerFirstName";
            this.tbOwnerFirstName.ReadOnly = true;
            this.tbOwnerFirstName.Size = new System.Drawing.Size(173, 29);
            this.tbOwnerFirstName.TabIndex = 1;
            // 
            // lblOwnerLastName
            // 
            this.lblOwnerLastName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblOwnerLastName.BackColor = System.Drawing.SystemColors.Control;
            this.lblOwnerLastName.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblOwnerLastName.ForeColor = System.Drawing.Color.Black;
            this.lblOwnerLastName.Location = new System.Drawing.Point(25, 118);
            this.lblOwnerLastName.Name = "lblOwnerLastName";
            this.lblOwnerLastName.Size = new System.Drawing.Size(118, 22);
            this.lblOwnerLastName.TabIndex = 2;
            this.lblOwnerLastName.Text = "Last Name";
            // 
            // lstOwners
            // 
            this.lstOwners.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lstOwners.FormattingEnabled = true;
            this.lstOwners.ItemHeight = 21;
            this.lstOwners.Location = new System.Drawing.Point(23, 46);
            this.lstOwners.Name = "lstOwners";
            this.lstOwners.Size = new System.Drawing.Size(354, 88);
            this.lstOwners.TabIndex = 1;
            // 
            // btnAddOwner
            // 
            this.btnAddOwner.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnAddOwner.ForeColor = System.Drawing.Color.Green;
            this.btnAddOwner.Location = new System.Drawing.Point(35, 239);
            this.btnAddOwner.Name = "btnAddOwner";
            this.btnAddOwner.Size = new System.Drawing.Size(354, 41);
            this.btnAddOwner.TabIndex = 4;
            this.btnAddOwner.Text = "Add Owner";
            this.btnAddOwner.UseVisualStyleBackColor = true;
            this.btnAddOwner.Click += new System.EventHandler(this.btnAddOwner_Click);
            // 
            // tbOwnerLastName
            // 
            this.tbOwnerLastName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tbOwnerLastName.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbOwnerLastName.Location = new System.Drawing.Point(168, 120);
            this.tbOwnerLastName.Name = "tbOwnerLastName";
            this.tbOwnerLastName.ReadOnly = true;
            this.tbOwnerLastName.Size = new System.Drawing.Size(173, 29);
            this.tbOwnerLastName.TabIndex = 5;
            // 
            // tbOwnerPhoneNum
            // 
            this.tbOwnerPhoneNum.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tbOwnerPhoneNum.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbOwnerPhoneNum.Location = new System.Drawing.Point(168, 165);
            this.tbOwnerPhoneNum.Name = "tbOwnerPhoneNum";
            this.tbOwnerPhoneNum.ReadOnly = true;
            this.tbOwnerPhoneNum.Size = new System.Drawing.Size(173, 29);
            this.tbOwnerPhoneNum.TabIndex = 6;
            // 
            // lblOwnerPhoneNum
            // 
            this.lblOwnerPhoneNum.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblOwnerPhoneNum.BackColor = System.Drawing.SystemColors.Control;
            this.lblOwnerPhoneNum.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblOwnerPhoneNum.ForeColor = System.Drawing.Color.Black;
            this.lblOwnerPhoneNum.Location = new System.Drawing.Point(25, 165);
            this.lblOwnerPhoneNum.Name = "lblOwnerPhoneNum";
            this.lblOwnerPhoneNum.Size = new System.Drawing.Size(110, 28);
            this.lblOwnerPhoneNum.TabIndex = 7;
            this.lblOwnerPhoneNum.Text = "Phone Number";
            // 
            // lblOwnerAddress
            // 
            this.lblOwnerAddress.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblOwnerAddress.BackColor = System.Drawing.SystemColors.Control;
            this.lblOwnerAddress.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblOwnerAddress.ForeColor = System.Drawing.Color.Black;
            this.lblOwnerAddress.Location = new System.Drawing.Point(25, 206);
            this.lblOwnerAddress.Name = "lblOwnerAddress";
            this.lblOwnerAddress.Size = new System.Drawing.Size(93, 27);
            this.lblOwnerAddress.TabIndex = 8;
            this.lblOwnerAddress.Text = "Address";
            // 
            // tbOwnerAddress
            // 
            this.tbOwnerAddress.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tbOwnerAddress.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbOwnerAddress.Location = new System.Drawing.Point(168, 205);
            this.tbOwnerAddress.Name = "tbOwnerAddress";
            this.tbOwnerAddress.ReadOnly = true;
            this.tbOwnerAddress.Size = new System.Drawing.Size(173, 29);
            this.tbOwnerAddress.TabIndex = 9;
            // 
            // tbOwnerSuburb
            // 
            this.tbOwnerSuburb.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tbOwnerSuburb.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbOwnerSuburb.Location = new System.Drawing.Point(168, 258);
            this.tbOwnerSuburb.Name = "tbOwnerSuburb";
            this.tbOwnerSuburb.ReadOnly = true;
            this.tbOwnerSuburb.Size = new System.Drawing.Size(173, 29);
            this.tbOwnerSuburb.TabIndex = 10;
            // 
            // lblOwnerSuburb
            // 
            this.lblOwnerSuburb.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblOwnerSuburb.BackColor = System.Drawing.SystemColors.Control;
            this.lblOwnerSuburb.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblOwnerSuburb.ForeColor = System.Drawing.Color.Black;
            this.lblOwnerSuburb.Location = new System.Drawing.Point(25, 260);
            this.lblOwnerSuburb.Name = "lblOwnerSuburb";
            this.lblOwnerSuburb.Size = new System.Drawing.Size(100, 20);
            this.lblOwnerSuburb.TabIndex = 11;
            this.lblOwnerSuburb.Text = "Suburb";
            // 
            // btnPreviousOwner
            // 
            this.btnPreviousOwner.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnPreviousOwner.Location = new System.Drawing.Point(17, 153);
            this.btnPreviousOwner.Name = "btnPreviousOwner";
            this.btnPreviousOwner.Size = new System.Drawing.Size(176, 37);
            this.btnPreviousOwner.TabIndex = 2;
            this.btnPreviousOwner.Text = "Previous Owner";
            this.btnPreviousOwner.UseVisualStyleBackColor = true;
            this.btnPreviousOwner.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // btnNextOwner
            // 
            this.btnNextOwner.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnNextOwner.Location = new System.Drawing.Point(199, 153);
            this.btnNextOwner.Name = "btnNextOwner";
            this.btnNextOwner.Size = new System.Drawing.Size(178, 37);
            this.btnNextOwner.TabIndex = 3;
            this.btnNextOwner.Text = "Next Owner";
            this.btnNextOwner.UseVisualStyleBackColor = true;
            this.btnNextOwner.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnOwnerReturn
            // 
            this.btnOwnerReturn.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOwnerReturn.Location = new System.Drawing.Point(23, 331);
            this.btnOwnerReturn.Name = "btnOwnerReturn";
            this.btnOwnerReturn.Size = new System.Drawing.Size(354, 50);
            this.btnOwnerReturn.TabIndex = 6;
            this.btnOwnerReturn.Text = "Return to Main Menu";
            this.btnOwnerReturn.UseVisualStyleBackColor = true;
            this.btnOwnerReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // btnModifyOwner
            // 
            this.btnModifyOwner.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnModifyOwner.Location = new System.Drawing.Point(35, 295);
            this.btnModifyOwner.Name = "btnModifyOwner";
            this.btnModifyOwner.Size = new System.Drawing.Size(354, 42);
            this.btnModifyOwner.TabIndex = 5;
            this.btnModifyOwner.Text = "Modify Owner";
            this.btnModifyOwner.UseVisualStyleBackColor = true;
            this.btnModifyOwner.Click += new System.EventHandler(this.btnModifyOwner_Click);
            // 
            // btnDeleteOwner
            // 
            this.btnDeleteOwner.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnDeleteOwner.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnDeleteOwner.Location = new System.Drawing.Point(35, 481);
            this.btnDeleteOwner.Name = "btnDeleteOwner";
            this.btnDeleteOwner.Size = new System.Drawing.Size(354, 49);
            this.btnDeleteOwner.TabIndex = 7;
            this.btnDeleteOwner.Text = "Delete Owner";
            this.btnDeleteOwner.UseVisualStyleBackColor = true;
            this.btnDeleteOwner.Click += new System.EventHandler(this.btnDeleteOwner_Click);
            // 
            // lblOwnerId
            // 
            this.lblOwnerId.AutoSize = true;
            this.lblOwnerId.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblOwnerId.Location = new System.Drawing.Point(164, 27);
            this.lblOwnerId.Name = "lblOwnerId";
            this.lblOwnerId.Size = new System.Drawing.Size(29, 23);
            this.lblOwnerId.TabIndex = 20;
            this.lblOwnerId.Text = "ID";
            // 
            // pnlAddOwner
            // 
            this.pnlAddOwner.BackColor = System.Drawing.Color.Silver;
            this.pnlAddOwner.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlAddOwner.Controls.Add(this.maskTbOwnerNumber);
            this.pnlAddOwner.Controls.Add(this.lblOwnhint1);
            this.pnlAddOwner.Controls.Add(this.btnUpdateOwner);
            this.pnlAddOwner.Controls.Add(this.btnReturnToOwnerF);
            this.pnlAddOwner.Controls.Add(this.btnSaveOwner);
            this.pnlAddOwner.Controls.Add(this.tbOwnerAddSuburb);
            this.pnlAddOwner.Controls.Add(this.tbOwnerAddAddress);
            this.pnlAddOwner.Controls.Add(this.tbOwnerAddLastN);
            this.pnlAddOwner.Controls.Add(this.tbOwnerAddFirstN);
            this.pnlAddOwner.Controls.Add(this.lblOwnerAddSuburb);
            this.pnlAddOwner.Controls.Add(this.lblOwnerAddAddress);
            this.pnlAddOwner.Controls.Add(this.lblOwnerAddPhone);
            this.pnlAddOwner.Controls.Add(this.lblOwnerAddLastN);
            this.pnlAddOwner.Controls.Add(this.lblOwnerAddFirstN);
            this.pnlAddOwner.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.pnlAddOwner.Location = new System.Drawing.Point(194, 12);
            this.pnlAddOwner.MaximumSize = new System.Drawing.Size(762, 370);
            this.pnlAddOwner.MinimumSize = new System.Drawing.Size(762, 370);
            this.pnlAddOwner.Name = "pnlAddOwner";
            this.pnlAddOwner.Size = new System.Drawing.Size(762, 370);
            this.pnlAddOwner.TabIndex = 21;
            // 
            // maskTbOwnerNumber
            // 
            this.maskTbOwnerNumber.Location = new System.Drawing.Point(232, 86);
            this.maskTbOwnerNumber.Mask = "(99) 000-0000";
            this.maskTbOwnerNumber.Name = "maskTbOwnerNumber";
            this.maskTbOwnerNumber.Size = new System.Drawing.Size(242, 26);
            this.maskTbOwnerNumber.TabIndex = 10;
            // 
            // lblOwnhint1
            // 
            this.lblOwnhint1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblOwnhint1.ForeColor = System.Drawing.Color.Navy;
            this.lblOwnhint1.Location = new System.Drawing.Point(491, 84);
            this.lblOwnhint1.Name = "lblOwnhint1";
            this.lblOwnhint1.Size = new System.Drawing.Size(246, 41);
            this.lblOwnhint1.TabIndex = 23;
            this.lblOwnhint1.Text = "Enter number with town code. Example: (09)1012345";
            // 
            // btnUpdateOwner
            // 
            this.btnUpdateOwner.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnUpdateOwner.ForeColor = System.Drawing.Color.Green;
            this.btnUpdateOwner.Location = new System.Drawing.Point(232, 196);
            this.btnUpdateOwner.Name = "btnUpdateOwner";
            this.btnUpdateOwner.Size = new System.Drawing.Size(242, 47);
            this.btnUpdateOwner.TabIndex = 13;
            this.btnUpdateOwner.Text = "Update Owner";
            this.btnUpdateOwner.UseVisualStyleBackColor = true;
            this.btnUpdateOwner.Click += new System.EventHandler(this.btnUpdateOwner_Click);
            // 
            // btnReturnToOwnerF
            // 
            this.btnReturnToOwnerF.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnReturnToOwnerF.Location = new System.Drawing.Point(232, 294);
            this.btnReturnToOwnerF.Name = "btnReturnToOwnerF";
            this.btnReturnToOwnerF.Size = new System.Drawing.Size(242, 47);
            this.btnReturnToOwnerF.TabIndex = 14;
            this.btnReturnToOwnerF.Text = "Cancel";
            this.btnReturnToOwnerF.UseVisualStyleBackColor = true;
            this.btnReturnToOwnerF.Click += new System.EventHandler(this.btnReturnToOwnerF_Click);
            // 
            // btnSaveOwner
            // 
            this.btnSaveOwner.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnSaveOwner.ForeColor = System.Drawing.Color.DarkGreen;
            this.btnSaveOwner.Location = new System.Drawing.Point(232, 196);
            this.btnSaveOwner.Name = "btnSaveOwner";
            this.btnSaveOwner.Size = new System.Drawing.Size(242, 48);
            this.btnSaveOwner.TabIndex = 13;
            this.btnSaveOwner.Text = "Save Owner";
            this.btnSaveOwner.UseVisualStyleBackColor = true;
            this.btnSaveOwner.Click += new System.EventHandler(this.btnSaveOwner_Click);
            // 
            // tbOwnerAddSuburb
            // 
            this.tbOwnerAddSuburb.Location = new System.Drawing.Point(232, 145);
            this.tbOwnerAddSuburb.MaxLength = 12;
            this.tbOwnerAddSuburb.Name = "tbOwnerAddSuburb";
            this.tbOwnerAddSuburb.Size = new System.Drawing.Size(242, 26);
            this.tbOwnerAddSuburb.TabIndex = 12;
            // 
            // tbOwnerAddAddress
            // 
            this.tbOwnerAddAddress.Location = new System.Drawing.Point(232, 116);
            this.tbOwnerAddAddress.MaxLength = 30;
            this.tbOwnerAddAddress.Name = "tbOwnerAddAddress";
            this.tbOwnerAddAddress.Size = new System.Drawing.Size(242, 26);
            this.tbOwnerAddAddress.TabIndex = 11;
            // 
            // tbOwnerAddLastN
            // 
            this.tbOwnerAddLastN.Location = new System.Drawing.Point(232, 57);
            this.tbOwnerAddLastN.MaxLength = 25;
            this.tbOwnerAddLastN.Name = "tbOwnerAddLastN";
            this.tbOwnerAddLastN.Size = new System.Drawing.Size(242, 26);
            this.tbOwnerAddLastN.TabIndex = 9;
            // 
            // tbOwnerAddFirstN
            // 
            this.tbOwnerAddFirstN.Location = new System.Drawing.Point(232, 27);
            this.tbOwnerAddFirstN.MaxLength = 25;
            this.tbOwnerAddFirstN.Name = "tbOwnerAddFirstN";
            this.tbOwnerAddFirstN.Size = new System.Drawing.Size(242, 26);
            this.tbOwnerAddFirstN.TabIndex = 8;
            // 
            // lblOwnerAddSuburb
            // 
            this.lblOwnerAddSuburb.AutoSize = true;
            this.lblOwnerAddSuburb.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblOwnerAddSuburb.Location = new System.Drawing.Point(101, 149);
            this.lblOwnerAddSuburb.Name = "lblOwnerAddSuburb";
            this.lblOwnerAddSuburb.Size = new System.Drawing.Size(55, 17);
            this.lblOwnerAddSuburb.TabIndex = 4;
            this.lblOwnerAddSuburb.Text = "Suburb";
            // 
            // lblOwnerAddAddress
            // 
            this.lblOwnerAddAddress.AutoSize = true;
            this.lblOwnerAddAddress.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblOwnerAddAddress.Location = new System.Drawing.Point(93, 120);
            this.lblOwnerAddAddress.Name = "lblOwnerAddAddress";
            this.lblOwnerAddAddress.Size = new System.Drawing.Size(63, 17);
            this.lblOwnerAddAddress.TabIndex = 3;
            this.lblOwnerAddAddress.Text = "Address";
            // 
            // lblOwnerAddPhone
            // 
            this.lblOwnerAddPhone.AutoSize = true;
            this.lblOwnerAddPhone.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblOwnerAddPhone.Location = new System.Drawing.Point(84, 90);
            this.lblOwnerAddPhone.Name = "lblOwnerAddPhone";
            this.lblOwnerAddPhone.Size = new System.Drawing.Size(107, 17);
            this.lblOwnerAddPhone.TabIndex = 2;
            this.lblOwnerAddPhone.Text = "Phone Number";
            // 
            // lblOwnerAddLastN
            // 
            this.lblOwnerAddLastN.AutoSize = true;
            this.lblOwnerAddLastN.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblOwnerAddLastN.Location = new System.Drawing.Point(90, 60);
            this.lblOwnerAddLastN.Name = "lblOwnerAddLastN";
            this.lblOwnerAddLastN.Size = new System.Drawing.Size(80, 17);
            this.lblOwnerAddLastN.TabIndex = 1;
            this.lblOwnerAddLastN.Text = "Last Name";
            // 
            // lblOwnerAddFirstN
            // 
            this.lblOwnerAddFirstN.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblOwnerAddFirstN.Location = new System.Drawing.Point(90, 30);
            this.lblOwnerAddFirstN.Name = "lblOwnerAddFirstN";
            this.lblOwnerAddFirstN.Size = new System.Drawing.Size(101, 17);
            this.lblOwnerAddFirstN.TabIndex = 0;
            this.lblOwnerAddFirstN.Text = "First Name";
            // 
            // grpOwnerMaintenance
            // 
            this.grpOwnerMaintenance.Controls.Add(this.lstOwners);
            this.grpOwnerMaintenance.Controls.Add(this.btnOwnerReturn);
            this.grpOwnerMaintenance.Controls.Add(this.btnPreviousOwner);
            this.grpOwnerMaintenance.Controls.Add(this.btnNextOwner);
            this.grpOwnerMaintenance.Font = new System.Drawing.Font("Vivaldi", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpOwnerMaintenance.Location = new System.Drawing.Point(12, 26);
            this.grpOwnerMaintenance.Name = "grpOwnerMaintenance";
            this.grpOwnerMaintenance.Size = new System.Drawing.Size(485, 517);
            this.grpOwnerMaintenance.TabIndex = 22;
            this.grpOwnerMaintenance.TabStop = false;
            this.grpOwnerMaintenance.Text = "Owner Maintenance";
            // 
            // grpOwnersDetails
            // 
            this.grpOwnersDetails.Controls.Add(this.lblOwnerIdname);
            this.grpOwnersDetails.Controls.Add(this.tbOwnerSuburb);
            this.grpOwnersDetails.Controls.Add(this.lblOwnerId);
            this.grpOwnersDetails.Controls.Add(this.tbOwnerAddress);
            this.grpOwnersDetails.Controls.Add(this.tbOwnerPhoneNum);
            this.grpOwnersDetails.Controls.Add(this.lblOwnerSuburb);
            this.grpOwnersDetails.Controls.Add(this.lblOwnerAddress);
            this.grpOwnersDetails.Controls.Add(this.tbOwnerLastName);
            this.grpOwnersDetails.Controls.Add(this.lblOwnerPhoneNum);
            this.grpOwnersDetails.Controls.Add(this.tbOwnerFirstName);
            this.grpOwnersDetails.Controls.Add(this.lblOwnerFirstName);
            this.grpOwnersDetails.Controls.Add(this.lblOwnerLastName);
            this.grpOwnersDetails.Location = new System.Drawing.Point(529, 26);
            this.grpOwnersDetails.Name = "grpOwnersDetails";
            this.grpOwnersDetails.Size = new System.Drawing.Size(372, 504);
            this.grpOwnersDetails.TabIndex = 23;
            this.grpOwnersDetails.TabStop = false;
            // 
            // lblOwnerIdname
            // 
            this.lblOwnerIdname.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblOwnerIdname.BackColor = System.Drawing.SystemColors.Control;
            this.lblOwnerIdname.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblOwnerIdname.ForeColor = System.Drawing.Color.Black;
            this.lblOwnerIdname.Location = new System.Drawing.Point(25, 27);
            this.lblOwnerIdname.Name = "lblOwnerIdname";
            this.lblOwnerIdname.Size = new System.Drawing.Size(106, 23);
            this.lblOwnerIdname.TabIndex = 21;
            this.lblOwnerIdname.Text = "Owner ID";
            // 
            // OwnerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(990, 542);
            this.Controls.Add(this.pnlAddOwner);
            this.Controls.Add(this.btnDeleteOwner);
            this.Controls.Add(this.btnModifyOwner);
            this.Controls.Add(this.btnAddOwner);
            this.Controls.Add(this.grpOwnerMaintenance);
            this.Controls.Add(this.grpOwnersDetails);
            this.Name = "OwnerForm";
            this.Text = "Owner_Maintenance";
            this.pnlAddOwner.ResumeLayout(false);
            this.pnlAddOwner.PerformLayout();
            this.grpOwnerMaintenance.ResumeLayout(false);
            this.grpOwnersDetails.ResumeLayout(false);
            this.grpOwnersDetails.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblOwnerFirstName;
        private System.Windows.Forms.TextBox tbOwnerFirstName;
        private System.Windows.Forms.Label lblOwnerLastName;
        private System.Windows.Forms.ListBox lstOwners;
        private System.Windows.Forms.Button btnAddOwner;
        private System.Windows.Forms.TextBox tbOwnerLastName;
        private System.Windows.Forms.TextBox tbOwnerPhoneNum;
        private System.Windows.Forms.Label lblOwnerPhoneNum;
        private System.Windows.Forms.Label lblOwnerAddress;
        private System.Windows.Forms.TextBox tbOwnerAddress;
        private System.Windows.Forms.TextBox tbOwnerSuburb;
        private System.Windows.Forms.Label lblOwnerSuburb;
        private System.Windows.Forms.Button btnPreviousOwner;
        private System.Windows.Forms.Button btnNextOwner;
        private System.Windows.Forms.Button btnOwnerReturn;
        private System.Windows.Forms.Button btnModifyOwner;
        private System.Windows.Forms.Button btnDeleteOwner;
        private System.Windows.Forms.Label lblOwnerId;
        private System.Windows.Forms.Panel pnlAddOwner;
        private System.Windows.Forms.Label lblOwnerAddLastN;
        private System.Windows.Forms.Label lblOwnerAddFirstN;
        private System.Windows.Forms.TextBox tbOwnerAddSuburb;
        private System.Windows.Forms.TextBox tbOwnerAddAddress;
        private System.Windows.Forms.TextBox tbOwnerAddLastN;
        private System.Windows.Forms.TextBox tbOwnerAddFirstN;
        private System.Windows.Forms.Label lblOwnerAddSuburb;
        private System.Windows.Forms.Label lblOwnerAddAddress;
        private System.Windows.Forms.Label lblOwnerAddPhone;
        private System.Windows.Forms.Button btnSaveOwner;
        private System.Windows.Forms.GroupBox grpOwnerMaintenance;
        private System.Windows.Forms.GroupBox grpOwnersDetails;
        private System.Windows.Forms.Button btnReturnToOwnerF;
        private System.Windows.Forms.Button btnUpdateOwner;
        private System.Windows.Forms.Label lblOwnerIdname;
        private System.Windows.Forms.Label lblOwnhint1;
        private System.Windows.Forms.MaskedTextBox maskTbOwnerNumber;
    }
}