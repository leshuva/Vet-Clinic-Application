﻿namespace ShuvaevaAssignment1
{
    partial class VisitForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.grpVisitDetails = new System.Windows.Forms.GroupBox();
            this.tbVisitVetName = new System.Windows.Forms.TextBox();
            this.tbVisitOwnerName = new System.Windows.Forms.TextBox();
            this.tbVisitCatName = new System.Windows.Forms.TextBox();
            this.tbVisitDate = new System.Windows.Forms.TextBox();
            this.lblVisitVetName = new System.Windows.Forms.Label();
            this.lblVisitOwnerName = new System.Windows.Forms.Label();
            this.lblVisitCatName = new System.Windows.Forms.Label();
            this.tbVisitStatus = new System.Windows.Forms.TextBox();
            this.lblVisitIdname = new System.Windows.Forms.Label();
            this.lblVisitId = new System.Windows.Forms.Label();
            this.lblVisitStatus = new System.Windows.Forms.Label();
            this.lblVisitDate = new System.Windows.Forms.Label();
            this.lblVisitAddVetName = new System.Windows.Forms.Label();
            this.lblVisitAddCatName = new System.Windows.Forms.Label();
            this.btnReturnToVisitF = new System.Windows.Forms.Button();
            this.btnUpdateVisit = new System.Windows.Forms.Button();
            this.btnSaveVisit = new System.Windows.Forms.Button();
            this.btnVisitReturn = new System.Windows.Forms.Button();
            this.btnPreviousVisit = new System.Windows.Forms.Button();
            this.btnDeleteVisit = new System.Windows.Forms.Button();
            this.btnNextVisit = new System.Windows.Forms.Button();
            this.pnlAddVisit = new System.Windows.Forms.Panel();
            this.lblVisithint4 = new System.Windows.Forms.Label();
            this.lblVisithint3 = new System.Windows.Forms.Label();
            this.lblVisithint2 = new System.Windows.Forms.Label();
            this.lblVisithint1 = new System.Windows.Forms.Label();
            this.cmbVisitAddStatus = new System.Windows.Forms.ComboBox();
            this.lblVisitAddStatus = new System.Windows.Forms.Label();
            this.dtpVisitAddDate = new System.Windows.Forms.DateTimePicker();
            this.lblVisitAddDate = new System.Windows.Forms.Label();
            this.cmbVisitAddVetName = new System.Windows.Forms.ComboBox();
            this.cmbVisitAddCatName = new System.Windows.Forms.ComboBox();
            this.grpVisitMaintenance = new System.Windows.Forms.GroupBox();
            this.btnMarkVisitAsPaid = new System.Windows.Forms.Button();
            this.btnModifyVisit = new System.Windows.Forms.Button();
            this.btnAddVisit = new System.Windows.Forms.Button();
            this.lstVisits = new System.Windows.Forms.ListBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.grpVisitDetails.SuspendLayout();
            this.pnlAddVisit.SuspendLayout();
            this.grpVisitMaintenance.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpVisitDetails
            // 
            this.grpVisitDetails.Controls.Add(this.tbVisitVetName);
            this.grpVisitDetails.Controls.Add(this.tbVisitOwnerName);
            this.grpVisitDetails.Controls.Add(this.tbVisitCatName);
            this.grpVisitDetails.Controls.Add(this.tbVisitDate);
            this.grpVisitDetails.Controls.Add(this.lblVisitVetName);
            this.grpVisitDetails.Controls.Add(this.lblVisitOwnerName);
            this.grpVisitDetails.Controls.Add(this.lblVisitCatName);
            this.grpVisitDetails.Controls.Add(this.tbVisitStatus);
            this.grpVisitDetails.Controls.Add(this.lblVisitIdname);
            this.grpVisitDetails.Controls.Add(this.lblVisitId);
            this.grpVisitDetails.Controls.Add(this.lblVisitStatus);
            this.grpVisitDetails.Controls.Add(this.lblVisitDate);
            this.grpVisitDetails.Location = new System.Drawing.Point(456, 22);
            this.grpVisitDetails.Name = "grpVisitDetails";
            this.grpVisitDetails.Size = new System.Drawing.Size(434, 474);
            this.grpVisitDetails.TabIndex = 37;
            this.grpVisitDetails.TabStop = false;
            // 
            // tbVisitVetName
            // 
            this.tbVisitVetName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tbVisitVetName.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbVisitVetName.Location = new System.Drawing.Point(228, 232);
            this.tbVisitVetName.Name = "tbVisitVetName";
            this.tbVisitVetName.ReadOnly = true;
            this.tbVisitVetName.Size = new System.Drawing.Size(173, 29);
            this.tbVisitVetName.TabIndex = 32;
            // 
            // tbVisitOwnerName
            // 
            this.tbVisitOwnerName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tbVisitOwnerName.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbVisitOwnerName.Location = new System.Drawing.Point(228, 192);
            this.tbVisitOwnerName.Name = "tbVisitOwnerName";
            this.tbVisitOwnerName.ReadOnly = true;
            this.tbVisitOwnerName.Size = new System.Drawing.Size(173, 29);
            this.tbVisitOwnerName.TabIndex = 31;
            // 
            // tbVisitCatName
            // 
            this.tbVisitCatName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tbVisitCatName.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbVisitCatName.Location = new System.Drawing.Point(228, 157);
            this.tbVisitCatName.Name = "tbVisitCatName";
            this.tbVisitCatName.ReadOnly = true;
            this.tbVisitCatName.Size = new System.Drawing.Size(173, 29);
            this.tbVisitCatName.TabIndex = 30;
            // 
            // tbVisitDate
            // 
            this.tbVisitDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tbVisitDate.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbVisitDate.Location = new System.Drawing.Point(228, 73);
            this.tbVisitDate.Name = "tbVisitDate";
            this.tbVisitDate.ReadOnly = true;
            this.tbVisitDate.Size = new System.Drawing.Size(173, 29);
            this.tbVisitDate.TabIndex = 29;
            // 
            // lblVisitVetName
            // 
            this.lblVisitVetName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblVisitVetName.BackColor = System.Drawing.SystemColors.Control;
            this.lblVisitVetName.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVisitVetName.ForeColor = System.Drawing.Color.Black;
            this.lblVisitVetName.Location = new System.Drawing.Point(32, 227);
            this.lblVisitVetName.Name = "lblVisitVetName";
            this.lblVisitVetName.Size = new System.Drawing.Size(190, 28);
            this.lblVisitVetName.TabIndex = 25;
            this.lblVisitVetName.Text = "Veterinarian Name";
            // 
            // lblVisitOwnerName
            // 
            this.lblVisitOwnerName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblVisitOwnerName.BackColor = System.Drawing.SystemColors.Control;
            this.lblVisitOwnerName.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVisitOwnerName.ForeColor = System.Drawing.Color.Black;
            this.lblVisitOwnerName.Location = new System.Drawing.Point(34, 187);
            this.lblVisitOwnerName.Name = "lblVisitOwnerName";
            this.lblVisitOwnerName.Size = new System.Drawing.Size(146, 28);
            this.lblVisitOwnerName.TabIndex = 24;
            this.lblVisitOwnerName.Text = "Owner Name";
            // 
            // lblVisitCatName
            // 
            this.lblVisitCatName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblVisitCatName.BackColor = System.Drawing.SystemColors.Control;
            this.lblVisitCatName.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVisitCatName.ForeColor = System.Drawing.Color.Black;
            this.lblVisitCatName.Location = new System.Drawing.Point(30, 152);
            this.lblVisitCatName.Name = "lblVisitCatName";
            this.lblVisitCatName.Size = new System.Drawing.Size(110, 28);
            this.lblVisitCatName.TabIndex = 23;
            this.lblVisitCatName.Text = "Cat Name";
            // 
            // tbVisitStatus
            // 
            this.tbVisitStatus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tbVisitStatus.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbVisitStatus.Location = new System.Drawing.Point(228, 114);
            this.tbVisitStatus.Name = "tbVisitStatus";
            this.tbVisitStatus.ReadOnly = true;
            this.tbVisitStatus.Size = new System.Drawing.Size(173, 29);
            this.tbVisitStatus.TabIndex = 22;
            // 
            // lblVisitIdname
            // 
            this.lblVisitIdname.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblVisitIdname.BackColor = System.Drawing.SystemColors.Control;
            this.lblVisitIdname.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVisitIdname.ForeColor = System.Drawing.Color.Black;
            this.lblVisitIdname.Location = new System.Drawing.Point(34, 32);
            this.lblVisitIdname.Name = "lblVisitIdname";
            this.lblVisitIdname.Size = new System.Drawing.Size(106, 23);
            this.lblVisitIdname.TabIndex = 21;
            this.lblVisitIdname.Text = "Visit ID";
            // 
            // lblVisitId
            // 
            this.lblVisitId.AutoSize = true;
            this.lblVisitId.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVisitId.Location = new System.Drawing.Point(222, 30);
            this.lblVisitId.Name = "lblVisitId";
            this.lblVisitId.Size = new System.Drawing.Size(29, 23);
            this.lblVisitId.TabIndex = 20;
            this.lblVisitId.Text = "ID";
            // 
            // lblVisitStatus
            // 
            this.lblVisitStatus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblVisitStatus.BackColor = System.Drawing.SystemColors.Control;
            this.lblVisitStatus.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVisitStatus.ForeColor = System.Drawing.Color.Black;
            this.lblVisitStatus.Location = new System.Drawing.Point(32, 114);
            this.lblVisitStatus.Name = "lblVisitStatus";
            this.lblVisitStatus.Size = new System.Drawing.Size(110, 28);
            this.lblVisitStatus.TabIndex = 7;
            this.lblVisitStatus.Text = "Visit Status";
            // 
            // lblVisitDate
            // 
            this.lblVisitDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblVisitDate.BackColor = System.Drawing.SystemColors.Control;
            this.lblVisitDate.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVisitDate.ForeColor = System.Drawing.Color.Black;
            this.lblVisitDate.Location = new System.Drawing.Point(32, 74);
            this.lblVisitDate.Name = "lblVisitDate";
            this.lblVisitDate.Size = new System.Drawing.Size(171, 22);
            this.lblVisitDate.TabIndex = 2;
            this.lblVisitDate.Text = "Visit Date";
            // 
            // lblVisitAddVetName
            // 
            this.lblVisitAddVetName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblVisitAddVetName.BackColor = System.Drawing.Color.Silver;
            this.lblVisitAddVetName.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVisitAddVetName.ForeColor = System.Drawing.Color.Black;
            this.lblVisitAddVetName.Location = new System.Drawing.Point(15, 118);
            this.lblVisitAddVetName.Name = "lblVisitAddVetName";
            this.lblVisitAddVetName.Size = new System.Drawing.Size(154, 28);
            this.lblVisitAddVetName.TabIndex = 27;
            this.lblVisitAddVetName.Text = "Veterinarian Name";
            this.lblVisitAddVetName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblVisitAddCatName
            // 
            this.lblVisitAddCatName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblVisitAddCatName.BackColor = System.Drawing.Color.Silver;
            this.lblVisitAddCatName.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVisitAddCatName.ForeColor = System.Drawing.Color.Black;
            this.lblVisitAddCatName.Location = new System.Drawing.Point(54, 78);
            this.lblVisitAddCatName.Name = "lblVisitAddCatName";
            this.lblVisitAddCatName.Size = new System.Drawing.Size(115, 22);
            this.lblVisitAddCatName.TabIndex = 25;
            this.lblVisitAddCatName.Text = "Cat Name";
            this.lblVisitAddCatName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnReturnToVisitF
            // 
            this.btnReturnToVisitF.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnReturnToVisitF.Location = new System.Drawing.Point(183, 306);
            this.btnReturnToVisitF.Name = "btnReturnToVisitF";
            this.btnReturnToVisitF.Size = new System.Drawing.Size(242, 47);
            this.btnReturnToVisitF.TabIndex = 13;
            this.btnReturnToVisitF.Text = "Cancel";
            this.btnReturnToVisitF.UseVisualStyleBackColor = true;
            this.btnReturnToVisitF.Click += new System.EventHandler(this.btnReturnToVisitF_Click);
            // 
            // btnUpdateVisit
            // 
            this.btnUpdateVisit.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnUpdateVisit.ForeColor = System.Drawing.Color.Green;
            this.btnUpdateVisit.Location = new System.Drawing.Point(185, 250);
            this.btnUpdateVisit.Name = "btnUpdateVisit";
            this.btnUpdateVisit.Size = new System.Drawing.Size(242, 47);
            this.btnUpdateVisit.TabIndex = 11;
            this.btnUpdateVisit.Text = "Update Visit";
            this.btnUpdateVisit.UseVisualStyleBackColor = true;
            this.btnUpdateVisit.Click += new System.EventHandler(this.btnUpdateVisit_Click);
            // 
            // btnSaveVisit
            // 
            this.btnSaveVisit.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnSaveVisit.ForeColor = System.Drawing.Color.DarkGreen;
            this.btnSaveVisit.Location = new System.Drawing.Point(183, 250);
            this.btnSaveVisit.Name = "btnSaveVisit";
            this.btnSaveVisit.Size = new System.Drawing.Size(242, 48);
            this.btnSaveVisit.TabIndex = 12;
            this.btnSaveVisit.Text = "Save Visit";
            this.btnSaveVisit.UseVisualStyleBackColor = true;
            this.btnSaveVisit.Click += new System.EventHandler(this.btnSaveVisit_Click);
            // 
            // btnVisitReturn
            // 
            this.btnVisitReturn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnVisitReturn.Location = new System.Drawing.Point(17, 352);
            this.btnVisitReturn.Name = "btnVisitReturn";
            this.btnVisitReturn.Size = new System.Drawing.Size(354, 50);
            this.btnVisitReturn.TabIndex = 5;
            this.btnVisitReturn.Text = "Return to Main Menu";
            this.btnVisitReturn.UseVisualStyleBackColor = true;
            this.btnVisitReturn.Click += new System.EventHandler(this.btnVisitReturn_Click);
            // 
            // btnPreviousVisit
            // 
            this.btnPreviousVisit.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnPreviousVisit.Location = new System.Drawing.Point(17, 153);
            this.btnPreviousVisit.Name = "btnPreviousVisit";
            this.btnPreviousVisit.Size = new System.Drawing.Size(176, 37);
            this.btnPreviousVisit.TabIndex = 2;
            this.btnPreviousVisit.Text = "Previous Visit";
            this.btnPreviousVisit.UseVisualStyleBackColor = true;
            this.btnPreviousVisit.Click += new System.EventHandler(this.btnPreviousVisit_Click);
            // 
            // btnDeleteVisit
            // 
            this.btnDeleteVisit.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnDeleteVisit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnDeleteVisit.Location = new System.Drawing.Point(17, 408);
            this.btnDeleteVisit.Name = "btnDeleteVisit";
            this.btnDeleteVisit.Size = new System.Drawing.Size(354, 49);
            this.btnDeleteVisit.TabIndex = 6;
            this.btnDeleteVisit.Text = "Delete Visit";
            this.btnDeleteVisit.UseVisualStyleBackColor = true;
            this.btnDeleteVisit.Click += new System.EventHandler(this.btnDeleteVisit_Click);
            // 
            // btnNextVisit
            // 
            this.btnNextVisit.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnNextVisit.Location = new System.Drawing.Point(199, 153);
            this.btnNextVisit.Name = "btnNextVisit";
            this.btnNextVisit.Size = new System.Drawing.Size(178, 37);
            this.btnNextVisit.TabIndex = 3;
            this.btnNextVisit.Text = "Next Visit";
            this.btnNextVisit.UseVisualStyleBackColor = true;
            this.btnNextVisit.Click += new System.EventHandler(this.btnNextVisit_Click);
            // 
            // pnlAddVisit
            // 
            this.pnlAddVisit.BackColor = System.Drawing.Color.Silver;
            this.pnlAddVisit.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlAddVisit.Controls.Add(this.lblVisithint4);
            this.pnlAddVisit.Controls.Add(this.lblVisithint3);
            this.pnlAddVisit.Controls.Add(this.lblVisithint2);
            this.pnlAddVisit.Controls.Add(this.lblVisithint1);
            this.pnlAddVisit.Controls.Add(this.cmbVisitAddStatus);
            this.pnlAddVisit.Controls.Add(this.lblVisitAddStatus);
            this.pnlAddVisit.Controls.Add(this.dtpVisitAddDate);
            this.pnlAddVisit.Controls.Add(this.lblVisitAddDate);
            this.pnlAddVisit.Controls.Add(this.cmbVisitAddVetName);
            this.pnlAddVisit.Controls.Add(this.cmbVisitAddCatName);
            this.pnlAddVisit.Controls.Add(this.lblVisitAddVetName);
            this.pnlAddVisit.Controls.Add(this.lblVisitAddCatName);
            this.pnlAddVisit.Controls.Add(this.btnUpdateVisit);
            this.pnlAddVisit.Controls.Add(this.btnReturnToVisitF);
            this.pnlAddVisit.Controls.Add(this.btnSaveVisit);
            this.pnlAddVisit.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.pnlAddVisit.Location = new System.Drawing.Point(236, 12);
            this.pnlAddVisit.MaximumSize = new System.Drawing.Size(621, 408);
            this.pnlAddVisit.MinimumSize = new System.Drawing.Size(621, 408);
            this.pnlAddVisit.Name = "pnlAddVisit";
            this.pnlAddVisit.Size = new System.Drawing.Size(621, 408);
            this.pnlAddVisit.TabIndex = 35;
            // 
            // lblVisithint4
            // 
            this.lblVisithint4.AutoSize = true;
            this.lblVisithint4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVisithint4.ForeColor = System.Drawing.Color.Navy;
            this.lblVisithint4.Location = new System.Drawing.Point(441, 203);
            this.lblVisithint4.Name = "lblVisithint4";
            this.lblVisithint4.Size = new System.Drawing.Size(86, 19);
            this.lblVisithint4.TabIndex = 41;
            this.lblVisithint4.Text = "Show status";
            // 
            // lblVisithint3
            // 
            this.lblVisithint3.AutoSize = true;
            this.lblVisithint3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVisithint3.ForeColor = System.Drawing.Color.Navy;
            this.lblVisithint3.Location = new System.Drawing.Point(437, 169);
            this.lblVisithint3.Name = "lblVisithint3";
            this.lblVisithint3.Size = new System.Drawing.Size(89, 19);
            this.lblVisithint3.TabIndex = 40;
            this.lblVisithint3.Text = "Choose date";
            // 
            // lblVisithint2
            // 
            this.lblVisithint2.AutoSize = true;
            this.lblVisithint2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVisithint2.ForeColor = System.Drawing.Color.Navy;
            this.lblVisithint2.Location = new System.Drawing.Point(437, 121);
            this.lblVisithint2.Name = "lblVisithint2";
            this.lblVisithint2.Size = new System.Drawing.Size(179, 19);
            this.lblVisithint2.TabIndex = 39;
            this.lblVisithint2.Text = "Choose veterinarian name";
            // 
            // lblVisithint1
            // 
            this.lblVisithint1.AutoSize = true;
            this.lblVisithint1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVisithint1.ForeColor = System.Drawing.Color.Navy;
            this.lblVisithint1.Location = new System.Drawing.Point(437, 83);
            this.lblVisithint1.Name = "lblVisithint1";
            this.lblVisithint1.Size = new System.Drawing.Size(120, 19);
            this.lblVisithint1.TabIndex = 38;
            this.lblVisithint1.Text = "Choose cat name";
            // 
            // cmbVisitAddStatus
            // 
            this.cmbVisitAddStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbVisitAddStatus.FormattingEnabled = true;
            this.cmbVisitAddStatus.Location = new System.Drawing.Point(186, 200);
            this.cmbVisitAddStatus.Name = "cmbVisitAddStatus";
            this.cmbVisitAddStatus.Size = new System.Drawing.Size(221, 27);
            this.cmbVisitAddStatus.TabIndex = 10;
            // 
            // lblVisitAddStatus
            // 
            this.lblVisitAddStatus.AutoSize = true;
            this.lblVisitAddStatus.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVisitAddStatus.Location = new System.Drawing.Point(67, 200);
            this.lblVisitAddStatus.Name = "lblVisitAddStatus";
            this.lblVisitAddStatus.Size = new System.Drawing.Size(54, 19);
            this.lblVisitAddStatus.TabIndex = 36;
            this.lblVisitAddStatus.Text = "Status";
            // 
            // dtpVisitAddDate
            // 
            this.dtpVisitAddDate.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.dtpVisitAddDate.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dtpVisitAddDate.Location = new System.Drawing.Point(186, 163);
            this.dtpVisitAddDate.Name = "dtpVisitAddDate";
            this.dtpVisitAddDate.Size = new System.Drawing.Size(221, 25);
            this.dtpVisitAddDate.TabIndex = 9;
            // 
            // lblVisitAddDate
            // 
            this.lblVisitAddDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblVisitAddDate.BackColor = System.Drawing.Color.Silver;
            this.lblVisitAddDate.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVisitAddDate.ForeColor = System.Drawing.Color.Black;
            this.lblVisitAddDate.Location = new System.Drawing.Point(15, 162);
            this.lblVisitAddDate.Name = "lblVisitAddDate";
            this.lblVisitAddDate.Size = new System.Drawing.Size(154, 26);
            this.lblVisitAddDate.TabIndex = 34;
            this.lblVisitAddDate.Text = "Date";
            this.lblVisitAddDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cmbVisitAddVetName
            // 
            this.cmbVisitAddVetName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbVisitAddVetName.FormattingEnabled = true;
            this.cmbVisitAddVetName.Location = new System.Drawing.Point(185, 118);
            this.cmbVisitAddVetName.Name = "cmbVisitAddVetName";
            this.cmbVisitAddVetName.Size = new System.Drawing.Size(222, 27);
            this.cmbVisitAddVetName.TabIndex = 8;
            // 
            // cmbVisitAddCatName
            // 
            this.cmbVisitAddCatName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbVisitAddCatName.FormattingEnabled = true;
            this.cmbVisitAddCatName.Location = new System.Drawing.Point(183, 78);
            this.cmbVisitAddCatName.Name = "cmbVisitAddCatName";
            this.cmbVisitAddCatName.Size = new System.Drawing.Size(224, 27);
            this.cmbVisitAddCatName.TabIndex = 7;
            // 
            // grpVisitMaintenance
            // 
            this.grpVisitMaintenance.Controls.Add(this.btnMarkVisitAsPaid);
            this.grpVisitMaintenance.Controls.Add(this.btnVisitReturn);
            this.grpVisitMaintenance.Controls.Add(this.btnDeleteVisit);
            this.grpVisitMaintenance.Controls.Add(this.btnPreviousVisit);
            this.grpVisitMaintenance.Controls.Add(this.btnNextVisit);
            this.grpVisitMaintenance.Controls.Add(this.btnModifyVisit);
            this.grpVisitMaintenance.Controls.Add(this.btnAddVisit);
            this.grpVisitMaintenance.Controls.Add(this.lstVisits);
            this.grpVisitMaintenance.Font = new System.Drawing.Font("Vivaldi", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpVisitMaintenance.Location = new System.Drawing.Point(14, 18);
            this.grpVisitMaintenance.Name = "grpVisitMaintenance";
            this.grpVisitMaintenance.Size = new System.Drawing.Size(426, 478);
            this.grpVisitMaintenance.TabIndex = 36;
            this.grpVisitMaintenance.TabStop = false;
            this.grpVisitMaintenance.Text = "Visit Maintenance";
            // 
            // btnMarkVisitAsPaid
            // 
            this.btnMarkVisitAsPaid.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnMarkVisitAsPaid.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnMarkVisitAsPaid.Location = new System.Drawing.Point(17, 301);
            this.btnMarkVisitAsPaid.Name = "btnMarkVisitAsPaid";
            this.btnMarkVisitAsPaid.Size = new System.Drawing.Size(354, 42);
            this.btnMarkVisitAsPaid.TabIndex = 39;
            this.btnMarkVisitAsPaid.Text = "Mark visit as paid";
            this.btnMarkVisitAsPaid.UseVisualStyleBackColor = true;
            this.btnMarkVisitAsPaid.Click += new System.EventHandler(this.btnMarkVisitAsPaid_Click);
            // 
            // btnModifyVisit
            // 
            this.btnModifyVisit.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnModifyVisit.Location = new System.Drawing.Point(17, 253);
            this.btnModifyVisit.Name = "btnModifyVisit";
            this.btnModifyVisit.Size = new System.Drawing.Size(354, 42);
            this.btnModifyVisit.TabIndex = 25;
            this.btnModifyVisit.Text = "Modify Visit";
            this.btnModifyVisit.UseVisualStyleBackColor = true;
            this.btnModifyVisit.Click += new System.EventHandler(this.btnModifyVisit_Click);
            // 
            // btnAddVisit
            // 
            this.btnAddVisit.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnAddVisit.ForeColor = System.Drawing.Color.Green;
            this.btnAddVisit.Location = new System.Drawing.Point(17, 206);
            this.btnAddVisit.Name = "btnAddVisit";
            this.btnAddVisit.Size = new System.Drawing.Size(354, 41);
            this.btnAddVisit.TabIndex = 4;
            this.btnAddVisit.Text = "Add Visit";
            this.btnAddVisit.UseVisualStyleBackColor = true;
            this.btnAddVisit.Click += new System.EventHandler(this.btnAddVisit_Click);
            // 
            // lstVisits
            // 
            this.lstVisits.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lstVisits.FormattingEnabled = true;
            this.lstVisits.ItemHeight = 21;
            this.lstVisits.Location = new System.Drawing.Point(23, 46);
            this.lstVisits.Name = "lstVisits";
            this.lstVisits.Size = new System.Drawing.Size(354, 88);
            this.lstVisits.TabIndex = 1;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // VisitForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(902, 540);
            this.Controls.Add(this.pnlAddVisit);
            this.Controls.Add(this.grpVisitDetails);
            this.Controls.Add(this.grpVisitMaintenance);
            this.Name = "VisitForm";
            this.Text = "Visit_Maintenance";
            this.grpVisitDetails.ResumeLayout(false);
            this.grpVisitDetails.PerformLayout();
            this.pnlAddVisit.ResumeLayout(false);
            this.pnlAddVisit.PerformLayout();
            this.grpVisitMaintenance.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpVisitDetails;
        private System.Windows.Forms.TextBox tbVisitStatus;
        private System.Windows.Forms.Label lblVisitIdname;
        private System.Windows.Forms.Label lblVisitId;
        private System.Windows.Forms.Label lblVisitStatus;
        private System.Windows.Forms.Label lblVisitDate;
        private System.Windows.Forms.Label lblVisitAddVetName;
        private System.Windows.Forms.Label lblVisitAddCatName;
        private System.Windows.Forms.Button btnReturnToVisitF;
        private System.Windows.Forms.Button btnUpdateVisit;
        private System.Windows.Forms.Button btnSaveVisit;
        private System.Windows.Forms.Button btnVisitReturn;
        private System.Windows.Forms.Button btnPreviousVisit;
        private System.Windows.Forms.Button btnDeleteVisit;
        private System.Windows.Forms.Button btnNextVisit;
        private System.Windows.Forms.Panel pnlAddVisit;
        private System.Windows.Forms.GroupBox grpVisitMaintenance;
        private System.Windows.Forms.Button btnModifyVisit;
        private System.Windows.Forms.Button btnAddVisit;
        private System.Windows.Forms.ListBox lstVisits;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Label lblVisitVetName;
        private System.Windows.Forms.Label lblVisitOwnerName;
        private System.Windows.Forms.Label lblVisitCatName;
        private System.Windows.Forms.ComboBox cmbVisitAddCatName;
        private System.Windows.Forms.ComboBox cmbVisitAddVetName;
        private System.Windows.Forms.DateTimePicker dtpVisitAddDate;
        private System.Windows.Forms.Label lblVisitAddDate;
        private System.Windows.Forms.TextBox tbVisitDate;
        private System.Windows.Forms.TextBox tbVisitVetName;
        private System.Windows.Forms.TextBox tbVisitOwnerName;
        private System.Windows.Forms.TextBox tbVisitCatName;
        private System.Windows.Forms.Label lblVisitAddStatus;
        private System.Windows.Forms.ComboBox cmbVisitAddStatus;
        private System.Windows.Forms.Button btnMarkVisitAsPaid;
        private System.Windows.Forms.Label lblVisithint4;
        private System.Windows.Forms.Label lblVisithint3;
        private System.Windows.Forms.Label lblVisithint2;
        private System.Windows.Forms.Label lblVisithint1;
    }
}