﻿
/*
 * Description: Cat maintenance form. Allows to read, add, modify ,delete cats.
 * Author: Elena Shuvaeva
 * Date: 26.08.2014
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ShuvaevaAssignment1
{
    public partial class CatForm : Form

    {

        /// <summary>
        /// Declare a shared data source 
        /// add reference to DataModul
        /// </summary>
        private DataModule _dm;
        /// <summary>
        /// add reference to MainMenu object
        /// </summary>
        private MainMenu _mmenu;
        /// <summary>
        /// add reference to CurrencyManager object
        /// </summary>
        private CurrencyManager _currencyManager;

    
        /// <summary>
        /// Changing the constructor to accept Datamodul and MainMenu references
        /// </summary>
        /// <param name="dm"></param>
        /// <param name="mmenu"></param>
        public CatForm(DataModule dm, MainMenu mmenu)
        {
            // Create and set values for the controls
            InitializeComponent();

            //Store the location of the data modul
           _dm = dm;

           // Store the location of the menu form
           _mmenu = mmenu;

           //Run the code for binding the controls on the form
           BindControls();

            //Adding panel hidden
           pnlAddCat.Enabled = false;
           pnlAddCat.Visible = false;
        }

        /// <summary>
        /// Binds controls to the data source (bind the data to listbox and textboxes)
        /// </summary>


        public void BindControls()
        {
            //fill CatGender Combobox with data
            cmbCatGender.Items.Add(DataModule.GENDER_MALE);
            cmbCatGender.Items.Add(DataModule.GENDER_FEMALE);

            //datasourse for CatOwner combobox
            cmbCatOwner.DataSource = _dm.datasetGlendene.OWNER;
            cmbCatOwner.DisplayMember = "Details";
            cmbCatOwner.ValueMember = "OwnerId";
            
            
            //bind controls to actual data in current row
            lblCatId.DataBindings.Add("Text", _dm.datasetGlendene, "Cat.CatID");
            tbCatName.DataBindings.Add("Text", _dm.datasetGlendene, "Cat.Name");
            tbCatBreed.DataBindings.Add("Text", _dm.datasetGlendene, "Cat.Breed");

            tbCatDateOfBirth.DataBindings.Add("Text", _dm.datasetGlendene, "Cat.DateOfBirth");
            chbCatNeutered.DataBindings.Add("Checked", _dm.datasetGlendene, "Cat.Neutered");
            cmbCatOwner.DataBindings.Add("SelectedValue", _dm.datasetGlendene, "Cat.OwnerID");

            //bind control to actual cat gender 
            cmbCatGender.DataBindings.Add("Text", _dm.datasetGlendene, "Cat.Gender");
            
             //datasource for listbox

            lstCats.DataSource = _dm.datasetGlendene;
            lstCats.DisplayMember = "Cat.Name";
            lstCats.ValueMember = "Cat.Name";

            //define current position in the datatable "Cat"

            _currencyManager = (CurrencyManager)this.BindingContext[_dm.datasetGlendene, "CAT"];
            lstCats.SelectedIndexChanged += new EventHandler(CatsIndexChanged);

            //fill CatGender Combobox on the panel with data
            cmbAddCatGender.Items.Add(DataModule.GENDER_MALE);
            cmbAddCatGender.Items.Add(DataModule.GENDER_FEMALE);

            //datasourse for CatOwner combobox on the panel
            cmbCatAddOwnerId.DataSource = _dm.datasetGlendene.OWNER;
            cmbCatAddOwnerId.DisplayMember = "Details";
            cmbCatAddOwnerId.ValueMember = "OwnerId";

        }


        /// <summary>
        /// Event handler for  navigating between cats in the listbox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// 

        private void CatsIndexChanged(object sender, EventArgs e)
        {
            if (lstCats.SelectedIndex >= 0 && lstCats.SelectedIndex < _currencyManager.Count)
            {
                _currencyManager.Position = lstCats.SelectedIndex;
            }
        }


        /// <summary>
        /// Event Handler for 'Previous Cat' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void btnPreviousCat_Click(object sender, EventArgs e)
        {
            if (_currencyManager.Position > 0)
            {
                --_currencyManager.Position;
                lstCats.SelectedIndex = _currencyManager.Position;
            }

        }


        /// <summary>
        /// Event Handler for 'Next Cat' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void btnNextCat_Click(object sender, EventArgs e)
        {
            if (_currencyManager.Position < _currencyManager.Count - 1)
            {
                ++_currencyManager.Position;
                lstCats.SelectedIndex = _currencyManager.Position;
            }

        }

        /// <summary>
        /// Event Handler for 'Add Cat' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void btnAddCat_Click(object sender, EventArgs e)
        {
            //textboxes are empty
                tbCatAddName.Text = "";
                tbCatAddBreed.Text = "";
                    
            //Disable unneeded buttons

                btnDeleteCat.Enabled = false;
                btnModifyCat.Enabled = false;
                
                btnUpdateCat.Enabled = false;
                btnUpdateCat.Visible = false;
               

            // AddCat Panel and 'Save Cat' button are visible and enabled
                pnlAddCat.Visible = true;
                pnlAddCat.Enabled = true;
                btnSaveCat.Enabled = true;
                btnSaveCat.Visible = true;
            
        
        }

        /// <summary>
        /// Event Handler for 'Save' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void btnSaveCat_Click(object sender, EventArgs e)
        {
            //Create a new row that the variables will be added into
            DataRow newCatRow = _dm._dtCat.NewRow();
            
            //If any of the text areas for required fields are empty then do not write data (breed is not required)

            if ((tbCatAddName.Text == "") || (cmbAddCatGender.SelectedItem == null) )
                   
            {
                MessageBox.Show("You must enter a value for each of the text fields. However breed is not required", "Error");
                return;
            }
            else
            {
                newCatRow["Name"] = tbCatAddName.Text;
                newCatRow["Breed"] = tbCatAddBreed.Text;
                newCatRow["Gender"] = cmbAddCatGender.SelectedItem;
                newCatRow["DateOfBirth"] = dtpCatAddDateOfBirth.Value;
                newCatRow["Neutered"] = chxCatAddNeutered.Checked;
                newCatRow["OwnerID"] = cmbCatAddOwnerId.SelectedValue;

                //Add the new row to the Table
                _dm._dtCat.Rows.Add(newCatRow);
                _dm.UpdateCat();
                //Give the user a success message
                MessageBox.Show("Cat added successfully","Success");
            }

            this.btnReturnToCatF_Click(this,new EventArgs());

            return;
        }
        

        /// <summary>
        /// Event handler for "Cancel" button on the adding Panel
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnReturnToCatF_Click(object sender, EventArgs e)
        {
            pnlAddCat.Hide();
            btnDeleteCat.Enabled = true;
            btnModifyCat.Enabled = true;
            btnAddCat.Enabled = true;
        }


        /// <summary>
        /// Event handler for Modify Cat button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnModifyCat_Click(object sender, EventArgs e)
        {
          //panel is shown
            pnlAddCat.Visible = true;
            pnlAddCat.Enabled = true;
            //hide unneeded buttons
            btnAddCat.Enabled = false;
            btnDeleteCat.Enabled = false;
            btnSaveCat.Visible = false;
            btnSaveCat.Enabled = false;
            //update button shown
            btnUpdateCat.Visible = true;
            btnUpdateCat.Enabled = true;

            //show data of the chosen cat in the textboxes 
            tbCatAddName.Text = _dm.datasetGlendene.CAT.Rows[_currencyManager.Position]["Name"].ToString();
            tbCatAddBreed.Text = _dm.datasetGlendene.CAT.Rows[_currencyManager.Position]["Breed"].ToString();
            
            return;

        }


        /// <summary>
        /// Event handler for "Update Cat" button on the Add Cat Panel
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void btnUpdateCat_Click(object sender, EventArgs e)
        {
            // The row of the chosen cat
            DataRow updateCatRow = _dm._dtCat.Rows[_currencyManager.Position];
            // Condition, if text boxes are empty- error
            if ((tbCatAddName.Text == "")  ||
               (cmbAddCatGender.SelectedItem == null))
            {
                MessageBox.Show("You must enter a value for each of the text fields. However breed is not required", "Success");
                return;
            }
            else
            {
                //Add the text areas
                updateCatRow["Name"] = tbCatAddName.Text;
                updateCatRow["Breed"] = tbCatAddBreed.Text;
                updateCatRow["Gender"] = cmbAddCatGender.SelectedItem;
                updateCatRow["Neutered"] = chbCatNeutered.Checked;
                updateCatRow["OwnerID"] = cmbCatAddOwnerId.SelectedValue;
                //Update the database
                _currencyManager.EndCurrentEdit();
                _dm.UpdateCat();
                //Give the user a success message

                MessageBox.Show("Cat updated successfully","Success");
            }
            return;
        }


        /// <summary>
        /// Event handler for Delete button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void btnDeleteCat_Click(object sender, EventArgs e)
        {
            DataRow DeleteCatRow = _dm._dtCat.Rows[_currencyManager.Position];


            DataRow[] CatRow = _dm._dtVisit.Select("CatID = " + lblCatId.Text);
            if (CatRow.Length != 0)
            {
                
                MessageBox.Show( "You may only delete cats who are not assigned visits. Error!");
                
                return;
            }
            else
            {
                if (MessageBox.Show("Are you sure you want to delete this record?", "Warning",
                                    MessageBoxButtons.OKCancel) == DialogResult.OK)
                {
                    DeleteCatRow.Delete();
                    _dm.UpdateCat();
                }
            }
            return;


        }

        /// <summary>
        /// Event handler for "Return to MainForm" button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCatReturn_Click(object sender, EventArgs e)
        {
            Close();
        }


        
        



      


        


    }
}
