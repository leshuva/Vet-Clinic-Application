﻿/*
 * Description: Veterinarian maintenance form. Allows to read, add, modify ,delete veterinarians.
 * Author: Elena Shuvaeva
 * Date: 26.08.2014
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ShuvaevaAssignment1
{
    public partial class VeterinarianForm : Form
    {
        /// <summary>
        /// Declare a shared data source (add references to DataModul ,MainMenu and CurrencyManager objects)
        /// </summary>
        private DataModule _dm;
        private MainMenu _mmenu;
        private CurrencyManager _currencyManager;

        //Error message provider (here for the textbox "Rate")
        private ErrorProvider _ep = new ErrorProvider();


        /// <summary>
        ///  Changing the constructor to accept Datamodul and Main menu references
        /// </summary>
        /// <param name="dm"></param>
        /// <param name="mmenu"></param>
        public VeterinarianForm(DataModule dm, MainMenu mmenu)
        {
            // Create and set values for the controls
            InitializeComponent();


            //Store the location of the data modul
            _dm = dm;
            // Store the location of the menu form
            _mmenu = mmenu;

            //Run the code for binding the controls on the form
            BindControls();

            //Adding panel hidden

            pnlAddVet.Visible = false;
            pnlAddVet.Enabled = false;

        }


        /// <summary>
        /// Binds controls to the data source (bind the data to listbox and textboxes)
        /// </summary>
        public void BindControls()
        {
            lstVeterinarians.DataSource = _dm.datasetGlendene.VETERINARIAN;

            lstVeterinarians.DisplayMember = "Details";
            lstVeterinarians.ValueMember = "VeterinarianID";

            lblVetId.DataBindings.Add("Text", _dm.datasetGlendene, "VETERINARIAN.VeterinarianID");
            tbVetFirstName.DataBindings.Add("Text", _dm.datasetGlendene, "VETERINARIAN.FirstName");
            tbVetLastName.DataBindings.Add("Text", _dm.datasetGlendene, "VETERINARIAN.LastName");
            tbVetRate.DataBindings.Add("Text", _dm.datasetGlendene, "VETERINARIAN.Rate");


            _currencyManager = (CurrencyManager)this.BindingContext[_dm.datasetGlendene, "VETERINARIAN"];

            lstVeterinarians.SelectedIndexChanged += new EventHandler(VeterinariansIndexChanged);

        }


        /// <summary>
        ///  Event handler for  navigating between veterinarians in the listbox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void VeterinariansIndexChanged(Object sender, EventArgs e)
        {
            if (lstVeterinarians.SelectedIndex >= 0 && lstVeterinarians.SelectedIndex < _currencyManager.Count)
            {
                _currencyManager.Position = lstVeterinarians.SelectedIndex;
            }
        }


        /// <summary>
        /// Event Handler for 'Previous Veterinarian' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnPreviousVet_Click(object sender, EventArgs e)
        {
            if (_currencyManager.Position > 0)
            {
                --_currencyManager.Position;
                lstVeterinarians.SelectedIndex = _currencyManager.Position;
            }


        }

        /// <summary>
        /// Event Handler for 'Next Veterinarian' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnNextVet_Click(object sender, EventArgs e)
        {
            if (_currencyManager.Position < _currencyManager.Count - 1)
            {
                ++_currencyManager.Position;
                lstVeterinarians.SelectedIndex = _currencyManager.Position;
            }

        }



        /// <summary>
        /// Event handler for Add New Veterinarian (buttons 'Modify Veterinarian' and 'Delete Veterinarian' are disabled
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAddVet_Click(object sender, EventArgs e)
        {
            // Empty textboxes in the AddVeterinarian panel

            tbVetAddFirstN.Text = "";
            tbVetAddLastN.Text = "";
            tbVetAddRate.Text = "";



            //Disable unneeded buttons

            btnDeleteVet.Enabled = false;
            btnModifyVet.Enabled = false;

            //hide Update Veterinarian button
            btnUpdateVet.Enabled = false;
            btnUpdateVet.Visible = false;


            // AddVet Panel and 'Save' button are visible and enabled
            pnlAddVet.Visible = true;
            pnlAddVet.Enabled = true;
            btnSaveVet.Enabled = true;
            btnSaveVet.Visible = true;


        }


        /// <summary>
        /// Event handler for 'Save Veterinarian' button on the  panel
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSaveVet_Click(object sender, EventArgs e)
        {

            //Create a new row that the variables will be added into
            DataRow newVetRow = _dm._dtVeterinarian.NewRow();

            //If any of the text areas are empty then do not write data and return

            if ((tbVetAddLastN.Text == "") || (tbVetAddFirstN.Text == "") ||
               (tbVetAddRate.Text == ""))
            {
                MessageBox.Show("You must enter a value for each of the text fields", "Error");
                return;
            }

            else
            {
                newVetRow["LastName"] = tbVetAddLastN.Text;
                newVetRow["FirstName"] = tbVetAddFirstN.Text;
                newVetRow["Rate"] = Convert.ToDouble(tbVetAddRate.Text);



                //Add the new row to the Table

                _dm._dtVeterinarian.Rows.Add(newVetRow);
                _dm.UpdateVet();

                //Give the user a success message
                MessageBox.Show("Veterinarian added successfully", "Success");

            }

            // Going back to Veterinarian Maintenance form (close the panel)

            this.btnReturnToVetF_Click(this, new EventArgs());
            return;
        }



        /// <summary>
        /// Event Handler for Modifying Veterinarian
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnModifyVet_Click(object sender, EventArgs e)
        {
            // disable unneeded buttons
            pnlAddVet.Visible = true;
            pnlAddVet.Enabled = true;
            btnAddVet.Enabled = false;
            btnDeleteVet.Enabled = false;
            btnSaveVet.Visible = false;
            btnSaveVet.Enabled = false;
            btnUpdateVet.Visible = true;
            btnUpdateVet.Enabled = true;

            //show textdata of the chosen veterinarian  in textboxes 
            tbVetAddFirstN.Text = _dm.datasetGlendene.VETERINARIAN.Rows[_currencyManager.Position]["FirstName"].ToString();
            tbVetAddLastN.Text = _dm.datasetGlendene.VETERINARIAN.Rows[_currencyManager.Position]["LastName"].ToString();
            tbVetAddRate.Text = _dm.datasetGlendene.VETERINARIAN.Rows[_currencyManager.Position]["Rate"].ToString();
            return;

        }

        /// <summary>
        ///  Event handler for "Cancel" button on the panel
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void btnReturnToVetF_Click(object sender, EventArgs e)
        {
            pnlAddVet.Hide();

            btnDeleteVet.Enabled = true;
            btnModifyVet.Enabled = true;
            btnVetReturn.Enabled = true;
            btnAddVet.Enabled = true;
        }




        /// <summary>
        /// Event handler for 'Delete Veterinarian' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// 
        private void btnDeleteVet_Click(object sender, EventArgs e)
        {
            DataRow DeleteVetRow = _dm._dtVeterinarian.Rows[_currencyManager.Position];
            DataRow[] VisitRow = _dm._dtVisit.Select("VeterinarianID = " + lblVetId.Text);

            if (VisitRow.Length != 0)
            {
                MessageBox.Show("You may only delete Veterinarians who are not assigned visits", "Error");
                return;
            }

            else
            {
                if (MessageBox.Show("Are you sure you want to delete this record?", "Warning!",
                           MessageBoxButtons.OKCancel) == DialogResult.OK)
                {
                    DeleteVetRow.Delete();

                }
                _dm.UpdateVet();

            }

            return;
        }

        /// <summary>
        /// Event handler for "Update Veterinarian" button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void btnUpdateVeterinarian_Click(object sender, EventArgs e)
        {
            // The row of the chosen veterinarian
            DataRow updateVetRow = _dm._dtVeterinarian.Rows[_currencyManager.Position];
            // Condition, if text boxes are empty- error
            if ((tbVetAddLastN.Text == "") || (tbVetAddFirstN.Text == "") ||
               (tbVetAddRate.Text == ""))
            {
                MessageBox.Show("You must enter a value for each of the text fields", "Error");
                return;
            }
            else
            {
                //Add the text areas
                updateVetRow["LastName"] = tbVetAddLastN.Text;
                updateVetRow["FirstName"] = tbVetAddFirstN.Text;
                updateVetRow["Rate"] = Convert.ToDouble(tbVetAddRate.Text);

                //Update the database
                _currencyManager.EndCurrentEdit();
                _dm.UpdateVet();
                //Give the user a success message

                MessageBox.Show("Veterinarian updated successfully", "Success");
            }
            return;
        }

        /// <summary>
        /// Close 'Veterinarian Maintenance Form' and return to the MainMenu form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void btnVetReturn_Click(object sender, EventArgs e)
        {
            Close();
        }

        /// <summary>
        /// Check if the user enters valid data in the textbox "cost" on the panel
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AddRateTextChange(object sender, EventArgs e)
        {
            double rate;
            if (double.TryParse(tbVetAddRate.Text, out rate) && rate >= 0)
            {
                btnUpdateVet.Enabled = true;
                btnSaveVet.Enabled = true;

                _ep.SetError(tbVetAddRate, "");

            }
            else
            {
                btnUpdateVet.Enabled = false;
                btnSaveVet.Enabled = false;

                _ep.SetError(tbVetAddRate, "Please provide a positive number here");

            }

        }
    }
}
